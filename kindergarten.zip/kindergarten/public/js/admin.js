function readURL(input, img) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('img[data-image="' + img + '"]').attr('src', e.target.result);
            if ($('img[data-image="' + img + '"]').hasClass('display_none')) {
                $('img[data-image="' + img + '"]').fadeIn();
            }
        }

        reader.readAsDataURL(input.files[0]);

    }

}

$(document).on('change', '.oneImageFile', function () {
    var img = $(this).data('image');
    readURL(this, img);
});

$(document).on('click', 'aboutHeader', function () {
    var img = $(this).data('image');
    readURL(this, img);
});