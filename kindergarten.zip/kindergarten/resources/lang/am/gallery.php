<?php

return[
    'gallery' => 'Gallery',
    'kindergarten' => 'Kindergarten',
    'smart' => 'Smart Call to Action Title',
    'can' => 'You can add a subtitle as well',
    'dont' => 'Dont Miss Out',
    '' => '',
];