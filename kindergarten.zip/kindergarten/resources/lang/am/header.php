<?php

return[
  'home' => 'ԳԼԽԱՎՈՐ',
  'services' => 'ԾԱՌԱՅՈՒԹՅՈՒՆՆԵՐ',
  'gallery' => 'ՏԵՍԱԴԱՐԱՆ',
  'about' => 'ՄԵՐ ՄԱՍԻՆ',
  'contact' => 'ԿԱՊ',
];