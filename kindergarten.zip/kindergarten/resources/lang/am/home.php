<?php
/**
 * Created by PhpStorm.
 * User: YourbusinessIT
 * Date: 26.06.2017
 * Time: 14:59
 */
return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'here' => 'Here is What We Offer!',
    'photo' => 'Photo Gallery',
    'find' => 'Find Out More',
    'league' => 'Ivy League Educators',
    'best' => 'THE BEST POSSIBLE START',
    'healthy' => 'Healthy Snacks',
    'praesent' => 'Praesent id metus massa, ut blandit odio. Proin quis tortor orciet
                                                    iam at risus et justo dignis.',
    'restock' => 'Daily Restock',
    'etiam' => 'Etiam at risus et justo dignissim congue. Donec congue lacinia dui a
                                                    porttitor lectus condimentum.',
    'sugarfree' => 'Sugarfree Sweets',
    'porttitor' => 'A porttitor lectus condimentum laoreet. Nunc eu ullamcorper orci
                                                    Quisque eget odio ac lectus vestib.',

];