<?php

    return[
        'address' => ' ք.Երևան Գուլակյան փող. 6ա',
        'email' => ' www.avetismankapartez.com',
        'services' => 'Services',
        'smart' => 'Smart Call to Action Title',
        'can' => 'You can add a subtitle as well',
        'read' => 'Read More',
        'view' => 'View Prices	',

    ];
