<?php

    return[
        'about' => 'Some Things About Us',
        'address' => ' ք.Երևան Գուլակյան փող. 6ա',
        'email' => ' www.avetismankapartez.com',
        'find' => 'Find Out More',
        '' => '',
        '' => '',
    ];