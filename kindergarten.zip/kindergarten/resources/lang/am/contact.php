<?php

    return[
        'contact' => 'Drop Us A Line',
        'address' => ' ք.Երևան Գուլակյան փող. 6ա',
        'email' => ' www.avetismankapartez.com',
        'can' => 'How Can We Help You?',
        'your' => 'Your goal? To give your child the best
                                                possible start in life. Ours? To bring you the best possible baby gear
                                                and toys, all thoughtfully designed to help you nurture your child’s
                                                development. Because isn’t that the most important job in the world?',
        'firstname' => 'Firstname',
        'lastname' => 'Lastname',
        'mail' => 'Email Address',
        'phone' => 'Phone Number',
        'subject' => 'Subject',
        'message' => 'Your Message',
        'send' => 'Send Message',
        'contact_email' => 'Ձեր հաղորդագրությունը հաջողությամբ ուղարկվեց',
        'error_all' => 'Լրացրեք բոլոր դաշտերը',
        'error_email' => 'Մուտքագրեք գոյություն ունեցող էլ․հասցե',
        'error_phone' => 'Հեռախոսահամարը պետք է կազմված լինի միայն թվերից',
    ];