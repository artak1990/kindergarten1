<?php

    return[
        'address' => 'City Yerevan District Gyulakyan str. 6 a',
        'email' => 'www.avetismankapartez.com',
        'services' => 'Services',
        'smart' => 'Smart Call to Action Title',
        'can' => 'You can add a subtitle as well',
        'read' => 'Read More',
        'view' => 'View Prices	',

    ];
