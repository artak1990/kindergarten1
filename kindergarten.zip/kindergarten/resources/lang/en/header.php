<?php

return[
  'home' => 'HOME',
  'services' => 'SERVICES',
  'gallery' => 'GALLERY',
  'about' => 'ABOUT',
  'contact' => 'CONTACT',
];