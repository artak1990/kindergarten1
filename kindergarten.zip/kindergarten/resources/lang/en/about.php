<?php

    return[
        'about' => 'Some Things About Us',
        'address' => 'City Yerevan District Gyulakyan str. 6 a',
        'email' => 'www.avetismankapartez.com',
        'find' => 'Find Out More',
        '' => '',
        '' => '',
    ];