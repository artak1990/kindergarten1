<?php

    return[
        'about' => 'Some Things About Us',
        'address' => 'г,Ереван Гулакян 6а',
        'email' => 'www.avetismankapartez.com',
        'find' => 'Find Out More',
        '' => '',
        '' => '',
    ];