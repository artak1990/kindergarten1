<?php

return[
  'home' => 'ГЛАВНАЯ',
  'services' => 'СЕРВИСЫ',
  'gallery' => 'ГАЛЕРЕЯ',
  'about' => 'О НАС',
  'contact' => 'КОНТАКТЫ',
];