<?php

    return[
        'address' => 'г,Ереван Гулакян 6а',
        'email' => 'www.avetismankapartez.com',
        'services' => 'Services',
        'smart' => 'Smart Call to Action Title',
        'can' => 'You can add a subtitle as well',
        'read' => 'Read More',
        'view' => 'View Prices	',

    ];
