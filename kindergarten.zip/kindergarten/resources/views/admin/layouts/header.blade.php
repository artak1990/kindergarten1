<header class="fw-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
    <div class="fw-header-main">
        <div class="fw-container">
            <div class="fw-wrap-logo">

                <a href="/" class="fw-site-logo">
                    <img src="{{asset('wp-content/uploads/2016/07/Logo-2.png')}}"
                         alt="Kindergarten WordPress Theme Demo"/>
                </a>

            </div>
            <div class="fw-nav-wrap" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement"
                 role="navigation">
                <nav id="fw-menu-primary" class="fw-site-navigation primary-navigation">
                    <ul id="menu-header-menu" class="fw-nav-menu">
                        <li id="menu-item-438"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-438"><a
                                    href="/admin">ԳԼԽԱՎՈՐ</a></li>
                        <li id="menu-item-442"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442 drop-down"><a
                                    href="#0">ԾԱՌԱՅՈՒԹՅՈՒՆՆԵՐ</a>
                            <ul class="mega-menu">
                                @php($i=0)
                                @foreach($ses_services as $val)
                                    <li><a href="/admin/services/{{$url_ser[$i]}}">{{$val->name_am}}</a></li>
                                    @php($i++)
                                @endforeach
                            </ul>
                        </li>
                        <li id="menu-item-440"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-440"><a
                                    href="/admin/gallery">ՏԵՍԱԴԱՐԱՆ</a></li>
                        <li id="menu-item-441"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-441"><a
                                    href="/admin/about">ՄԵՐ ՄԱՍԻՆ</a></li>
                        <li id="menu-item-439"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-439">
                            <a href="#0">Փոխել գաղտնաբառը</a>
                            <ul class="dropdown-menu">
                                <form action="/admin/resetpassword/{{ Auth::user()->id}}" method="post">
                                    {{ csrf_field() }}

                                        <li><label for="login">Մուտքանուն:</label><input
                                                    value='{{ Auth::user()->email }}' name="email" class="form-control">
                                        </li>
                                        <li><label for="login">Նոր գաղտնաբառ:</label><input type="password"
                                                                                            name="password"
                                                                                            class="form-control"></li>
                                        <li><label for="login">Կրկնել գաղտնաբառը:</label><input
                                                    name="password_confirmation" type="password" class="form-control">
                                        </li>
                                        <li><input class="form-control" type="submit" name="submit" value="Փոխել"></li>

                                </form>
                            </ul>
                        </li>
                        <li id="menu-item-439"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-439">
                            @if (!Auth::guest())
                                <a href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                                    Ելք
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            @endif
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<style>
    .header-1 .primary-navigation > ul > li > a{
        margin-left: 20px !important;
    }
    .my-menu{
        text-transform: uppercase;
    }
    .my-dropdown{
        position: absolute !important;
        left: 0% !important;
        top: 55% !important;
        margin-top: 10px;
        width: 0px !important;
    }
</style>
