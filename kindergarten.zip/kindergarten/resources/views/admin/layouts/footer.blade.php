<!-- Footer -->
<footer id="colophon" class="site-footer fw-footer fw-footer-logo-retina" itemscope="itemscope" itemtype="http://schema.org/WPFooter">

    <div class="fw-footer-middle fw-footer-menu-right ">
        <div class="fw-container">
            <div class="fw-footer-logo">
                <a href="/"><img data-src="//demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/07/Logo-2.png" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" alt="Kindergarten WordPress Theme Demo" /></a>
            </div>
            <nav id="fw-footer-menu" class="fw-footer-menu"><ul id="menu-footer-menu" class=""><li id="menu-item-443" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-443"><a href="/admin" >ԳԼԽԱՎՈՐ</a></li>
                    <li id="menu-item-446" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-446"><a href="/admin/gallery" >ՏԵՍԱԴԱՐԱՆ</a></li>
                    <li id="menu-item-447" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-447"><a href="/admin/about" >ՄԵՐ ՄԱՍԻՆ</a></li>
                </ul></nav>		</div>
    </div>

    <div class="fw-footer-bar fw-copyright-right">
        <div class="fw-container">
            <div class="fw-footer-social"><a target="_blank" href="https://web.facebook.com/Avetismankapartez/"><i class="fa fa-facebook"></i></a><a target="_blank" href="#"><i class="fa fa-twitter"></i></a><a target="_blank" href="#"><i class="fa fa-vimeo"></i></a><a target="_blank" href="#"><i class="fa fa-skype"></i></a></div>				<div class="fw-copyright">© Play Kindergarden 2017. All Rights Reserved</div>
        </div>
    </div>
</footer>