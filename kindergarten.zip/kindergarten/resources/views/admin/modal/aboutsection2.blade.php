<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="section2Modal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Երրորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/about/update_section2/1" method="post"  id="service_update">
                                {{csrf_field()}}
                                <div class="my_div_parent">
                                <div class="col-md-12 my_div">
                                    <div class="col-md-4">
                                        <label for="title_am">Վերնագիր Հայ*</label>
                                        <input type="text" name="title_am" value='{{$section2_1->title_am}}' class="form-control" id="title_am">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="title_en">Վերնագիր Անգ*</label>
                                        <input type="text" name="title_en" value='{{$section2_1->title_en}}' class="form-control" id="title_en">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="title_ru">Վերնագիր Ռուս*</label>
                                         <input type="text" name="title_ru" value='{{$section2_1->title_ru}}' class="form-control" id="title_ru" >
                                    </div>
                            </div>
                                <div class="col-md-12 my_div">
                                    <div class="col-md-4">
                                        <label for="">Անուն Հայ</label>
                                         <input type="text" name="name_am[]" id="" class="form-control my_name_div_am appending_input" onkeyup="keyUp(this)">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="name_en">Անուն Անգ</label>
                                         <input type="text" name="name_en[]" id="" class="form-control my_name_div_en appending_input" onkeyup="keyUp(this)">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="name_ru">Անուն Ռուս</label>
                                         <input type="text" name="name_ru[]" id="" class="form-control my_name_div_ru appending_input" onkeyup="keyUp(this)">
                                    </div>

                            </div>
                                </div>

                                <div class="col-md-12">
                                    <input type="submit" value="Թարմացնել" class="form-control">
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
