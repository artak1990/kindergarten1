<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Առաջին բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <div class="">
                            <form action="/admin/home/update" method="post"
                                  enctype="multipart/form-data" id="service_update">
                                {{csrf_field()}}

                                @foreach($section as $val)
                                    <div class="col-md-4">

                                        <input type="file" name="image{{$val->id}}" id="file{{$val->id}}" class="input-file oneImageFile"
                                               data-image="image{{$val->id}}">
                                        <label for="file{{$val->id}}" class="btn btn-tertiary js-labelFile">
                                            <i class="icon fa fa-check"></i>
                                            <span class="js-fileName">Choose a Image</span>
                                        </label>
                                        <img id="" src="{{asset('img/home/section1/'.$val->img_name)}}" alt="avetis" class="img-rounded display_none" width="100px" data-image="image{{$val->id}}"/>

                                    </div>
                                @endforeach
                                @foreach($section as $val)
                                    <div class="col-md-4">
                                        <label for="">Անուն Հայ*</label>
                                        <input type="text" name="name_am[]" id="name_am{{$val->id}}" value="{{$val->name_am}}"
                                               class="form-control" >
                                    </div>
                                @endforeach
                                @foreach($section as $val)
                                    <div class="col-md-4">
                                        <label for="">Անուն Անգ*</label>
                                        <input type="text" name="name_en[]" id="update_name_en"
                                               value="{{$val->name_en}}"
                                               class="form-control" >
                                    </div>
                                @endforeach
                                @foreach($section as $val)
                                    <div class="col-md-4">
                                        <label for="">Անուն Ռուս*</label>
                                        <input type="text" name="name_ru[]" id="update_name_ru"
                                               value="{{$val->name_ru}}"
                                               class="form-control" >
                                    </div>
                                @endforeach
                                @foreach($section as $val)
                                    <div class="col-md-4">
                                        <label for="">Նկարագրություն Հայ*</label>
                                        <textarea type="text" name="description_am[]" id="update_description_am"
                                                  class="form-control" rows="10">{!! $val->description_am !!}</textarea>
                                    </div>
                                @endforeach
                                @foreach($section as $val)
                                    <div class="col-md-4">
                                        <label for="">Նկարագրություն Անգ*</label>
                                        <textarea type="text" name="description_en[]" id="update_description_en"
                                                  class="form-control" rows="10">{!! $val->description_en !!}</textarea>
                                    </div>
                                @endforeach
                                @foreach($section as $val)
                                    <div class="col-md-4">
                                        <label for="">Նկարագրություն Ռուս*</label>
                                        <textarea type="text" name="description_ru[]" id="update_description_ru"
                                                  class="form-control" rows="10">{!! $val->description_ru !!}</textarea>
                                    </div>
                                @endforeach
                                {{--@endforeach--}}
                                <div class="col-md-12">
                                    <input type="submit" class="form-control" value="Թարմացնել">
                                </div>

                            </form>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
<style>
    .section1-div-update {
        border: 2px solid;
        padding: 5px;
        margin: 5px;
        border-radius: 5px;
    }
</style>
