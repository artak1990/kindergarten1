<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="hedermodal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Առաջին բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <form action="/admin/galleryheader/update" method="post" enctype="multipart/form-data"
                          id="">
                        {{csrf_field()}}
                        <div class="col-md-12">
                            <input type="file" name="image" id="img_1" class="input-file oneImageFile"
                                   data-image="image">
                            <label for="img_1" class="btn btn-tertiary js-labelFile">
                                <i class="icon fa fa-check"></i>
                                <span class="js-fileName">Choose a Image</span>
                            </label>
                            <img id="blah" src="{{asset('/img/gallaryimage/header/gallery-kid-1.png' )}}" alt="avetis" class="img-rounded display_none" width="300px"
                                 data-image="image"/>
                        </div>
                        <div class="col-md-12">
                            <input type="submit" class="form-control" value="Թարմացնել">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>