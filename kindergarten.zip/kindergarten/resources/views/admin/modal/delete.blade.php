<div id="Modal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <p>Վստա՞հ եք, որ ցանկանում եք ջնջել</p>
                    </div>
                    <div class="panel-body">
                        <a href="" class=".btn-primary" id="delete_yes">Այո</a>
                        <a href="#" id="no" class=".btn-primary" data-dismiss="modal">Ոչ</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>