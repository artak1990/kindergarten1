<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Նկարների Ստեղծում</h4>
                </div>
                <div class="modal-body">
                    <form action="/admin/gallery/create" method="post" enctype="multipart/form-data"
                          id="service_update">
                        {{csrf_field()}}
                        <div class="col-md-12">
                            <input type="file" name="image" id="file" class="input-file oneImageFile"
                                   data-image="image2">
                            <label for="file" class="btn btn-tertiary js-labelFile">
                                <i class="icon fa fa-check"></i>
                                <span class="js-fileName">Choose a Image</span>
                            </label>
                            <img id="gallery_img" src="#" alt="avetis" class="img-rounded display_none" width="100px"
                                 data-image="image2"/>
                        </div>
                        <div class="col-md-12">
                            <label for="">Անուն Հայ*</label>
                            <input type="text" name="name_am" id="update_name_am">
                        </div>

                        <div class="col-md-12">
                            <label for="">Անուն Անգ*</label>
                            <input type="text" name="name_en" id="update_name_en">
                        </div>
                        <div class="col-md-12">
                            <label for="">Անուն Ռուս*</label>
                            <input type="text" name="name_ru" id="update_name_ru">
                        </div>
                        <div class="col-md-12">
                            <label for="">Նկարագրություն Հայ*</label>
                            <textarea type="text" name="description_am" id="update_description_am"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="">Նկարագրություն Անգ*</label>
                            <textarea type="text" name="description_en" id="update_description_en"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="">Նկարագրություն Ռուս*</label>
                            <textarea type="text" name="description_ru" id="update_description_ru"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="">Ընտրել Բաժինը*</label>
                            <select name="categiry" id="my_sel" class="form-control">
                                @foreach($category as $val)
                                    <option value="{{$val->id}}" class="category_class">{{$val->name_am}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-12">
                            <input type="submit" class="form-control my-submit" value="Ավելացնել">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
