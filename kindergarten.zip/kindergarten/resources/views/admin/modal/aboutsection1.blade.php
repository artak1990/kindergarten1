<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Երկրորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/about/update_section1/1" method="post" enctype="multipart/form-data"
                                  id="service_update">
                                {{csrf_field()}}
                                <div class="col-md-12">
                                    <input type="file" name="image" id="file" class="input-file oneImageFile"
                                           data-image="image2">
                                    <label for="file" class="btn btn-tertiary js-labelFile">
                                        <i class="icon fa fa-check"></i>
                                        <span class="js-fileName">Choose a Image</span>
                                    </label>
                                    <img id="blah" src="{{asset('img/about/section1/'.$section1->img_name)}}" alt="avetis" class="img-rounded display_none" width="100px"
                                         data-image="image2"/>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Անուն Հայ*</label>
                                    <input type="text" name="name_am" id="name_am" value="{{$section1->name_am}}"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Անուն Անգ*</label>
                                    <input type="text" name="name_en" id="update_name_en" value="{{$section1->name_en}}"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Անուն Ռուս*</label>
                                    <input type="text" name="name_ru" id="update_name_ru" value="{{$section1->name_ru}}"
                                           class="form-control">
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Նկարագրություն Հայ*</label>
                                    <textarea type="text" name="description_am" id="update_description_am"
                                              class="form-control">{!! $section1->description_am !!}</textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Նկարագրություն Անգ*</label>
                                    <textarea type="text" name="description_en" id="update_description_en"
                                              class="form-control">{!! $section1->description_en !!}</textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Նկարագրություն Ռուս*</label>
                                    <textarea type="text" name="description_ru" id="update_description_ru"
                                              class="form-control">{!! $section1->description_ru !!}</textarea>
                                </div>
                                <div class="col-md-12">
                                    <input type="submit" class="form-control" value="Թարմացնել">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
