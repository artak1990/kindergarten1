@extends('layouts.servicesapp')

@section('content')
    <div id="page" class="hfeed site">
        @include('admin.layouts.header')
        @if ($errors->has('image3') || $errors->has('image'))
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Խնդրում ենք բեռնել նկարը հետևյալ ֆորմատներից մեկով
                        jpeg,JPEG,png,PNG,jpg,JPG,gif,svg</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        @endif
        @if ($errors->has('title_am') || $errors->has('title_ru') || $errors->has('title_en'))
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Խնդրում ենք անունը լրացնել երեք լեզուներով</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        @endif
        @if ($errors->has('email'))
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Մուտքանուն դաշտը պարտադիր է լրացման համար</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        @endif
        @if ($errors->has('password'))
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Խնդրում են երկու դաշտում ել մուտքագրել նույն գաղտնաբառը</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        @endif
        @if ($errors->has('description_en') || $errors->has('description_am') || $errors->has('description_ru'))
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Լրացրեք պարտադիր դաշտերը</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        @endif
        @if(session()->has('message'))
            <div class="my-all">
                <div class="alert alert-success">
                    <a href="#0" class="close" data-dismiss="alert" aria-label="close">×</a>
                    {{ session()->get('message') }}<br>
                    <i class="fa fa-smile-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        @endif
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d1c2d6c1"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-63e2f434e417f32e866fca33a3d071ed header-animation-speed"
                         style="  background-image:url(../../wp-content/uploads/2016/07/page-background.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-2d172d9318c24a51d826b52791797776"
                                 class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element"
                                 data-animation-type="fadeInUp" data-animation-delay="400">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:180px;"></div>
                                    <span class="my-update update-rigth">
                                            <i class="fa fa-pencil-square-o fa-3x"
                                               aria-hidden="true"
                                               data-toggle="modal"
                                               data-target="#hedermodal" data-id=""></i>
                                        </span>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"
                                         data-animation-type="bounceInDown" data-animation-delay="400">
                                        <h2 class="fw-special-title">{{$services_category->name_am}}</h2>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:240px;"></div>

                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1c2ecd0"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  fw-mobile-hide-element tf-sh-fa9d5c11c5261e36dd236afec6aa2ac1 "
                         style="  background-image:url(../../wp-content/uploads/2016/06/healthy-background.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-dd4110937ca34c70203a283cfe3290d4"
                                 class="fw-col-sm-6 fw-col-md-3 tf-sh-dd4110937ca34c70203a283cfe3290d4">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="anchor" href="#afterschool" target="_self">
							{{--<img src="{{asset('wp-content/uploads/2016/06/clock-icon-yellow.png')}}" alt=""/>						--}}
                                            </a>
									</span>

                                            <h6 class="fw-icon-title-text">
                                                <a class="anchor" href="" target="_self" data-toggle="modal"
                                                   data-target="#myModal"><i class="fa fa-plus"
                                                                             aria-hidden="true"></i> {{$services_category->name_am}}
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-tablet-hide-element clearfix"
                                         style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-6875f8d3a2893bfc866bf42f23fc65cc"
                                 class="fw-col-sm-6 fw-col-md-3 tf-sh-6875f8d3a2893bfc866bf42f23fc65cc">
                                <div class="fw-main-row-overlay"></div>
                                {{--<div class="fw-col-inner">--}}
                                {{--<div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>--}}
                                {{--<div class="fw-icon-title fw-icon-title-left clearfix tf-sh-6d33d10d20d0df761a7555eadc9b9a34  fw-content-align-center">--}}
                                {{--<div class="fw-icon-title-name">--}}
                                {{--<span class="fw-icon-title-icon fw-custom-icon-image">--}}
                                {{--<a class="anchor" href="#kindergarten" target="_self">--}}
                                {{--							<img src="{{asset('wp-content/uploads/2016/06/plane-icon-yellow.png')}}" alt=""/>	--}}
                                {{--</a>--}}
                                {{--</span>--}}

                                {{--<h6 class="fw-icon-title-text">--}}
                                {{--<a class="anchor" href="" target="_self" data-toggle="modal"--}}
                                {{--data-target="#ServiceCategoryModal">AddServiceCategory</a>--}}
                                {{--</h6>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="fw-divider-space  fw-custom-space  fw-tablet-hide-element clearfix"--}}
                                {{--style="height:55px;"></div>--}}
                                {{--</div>--}}
                            </div>
                            <div id="column-d58472aa7c5dd66cf1c8faf42755eccb"
                                 class="fw-col-sm-6 fw-col-md-3 tf-sh-d58472aa7c5dd66cf1c8faf42755eccb">
                                <div class="fw-main-row-overlay"></div>
                                {{--<div class="fw-col-inner">--}}
                                {{--<div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>--}}
                                {{--<div class="fw-icon-title fw-icon-title-left clearfix tf-sh-78e8669f6752f2fd02ef70707a9a8630  fw-content-align-center">--}}
                                {{--<div class="fw-icon-title-name">--}}
                                {{--<span class="fw-icon-title-icon fw-custom-icon-image">--}}
                                {{--<a class="anchor" href="#toddlercare" target="_self">--}}
                                {{--<img src="{{asset('wp-content/uploads/2016/06/toddler-icon-yellow.png')}}" alt=""/>						</a>--}}
                                {{--</span>--}}

                                {{--<h6 class="fw-icon-title-text">--}}
                                {{--<a class="anchor" href="#toddlercare" target="_self">Toddler Care</a>--}}
                                {{--</h6>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>--}}
                                {{--</div>--}}
                            </div>
                            <div id="column-52ab08806e8670224e46a34b24da472f"
                                 class="fw-col-sm-6 fw-col-md-3 tf-sh-52ab08806e8670224e46a34b24da472f">
                                <div class="fw-main-row-overlay"></div>
                                {{--<div class="fw-col-inner">--}}
                                {{--<div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>--}}
                                {{--<div class="fw-icon-title fw-icon-title-left clearfix tf-sh-60db5ea8816ddda26c75e85b31c9e362  fw-content-align-center">--}}
                                {{--<div class="fw-icon-title-name">--}}
                                {{--<span class="fw-icon-title-icon fw-custom-icon-image">--}}
                                {{--<a class="anchor" href="#kidparties" target="_self">--}}
                                {{--<img src="{{asset('wp-content/uploads/2016/06/tent-icon-yellow.png')}}" alt=""/>						</a>--}}
                                {{--</span>--}}

                                {{--<h6 class="fw-icon-title-text">--}}
                                {{--<a class="anchor" href="#kidparties" target="_self">Kids Parties</a>--}}
                                {{--</h6>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                                {{--<div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>--}}
                                {{--</div>--}}
                            </div>
                        </div>

                    </div>
                </section>
                @foreach($services as $val)
                    @if($x%2 != 0)
                        <section id="{{$val->title_am}}"
                                 class=" fw-main-row-custom fw-section-no-padding fw-content-overlay-custom fw_theme_bg_fw-custom fw-section-image auto  tf-sh-d0073d6033be11a3a89872b885f85414 "
                                 style="  background-image:url(../../wp-content/uploads/2016/06/clock-background.png); background-repeat: no-repeat; background-position: center top; background-size: auto; margin-bottom:-40px; ">
                            <div class="fw-container">
                                <div class="fw-row">
                                    <i class="fa fa-pencil-square-o fa-3x my-update" aria-hidden="true"
                                       data-toggle="modal"
                                       data-target="#myModal" data-id="{{$val->id}}"></i>
                                    <span class="delete_update_image delete_section3"
                                          href='/admin/services/delete/{{$val->id}}'
                                          data-toggle="modal" data-target="#Modal">
                                                    <i class="fa fa-trash-o fa-3x"
                                                       aria-hidden="true"></i>
                                                    </span>
                                    <div id="column-e2756c36a681f1d487527e3c54397127"
                                         class="fw-col-sm-12 fw-mobile-hide-element tf-sh-e2756c36a681f1d487527e3c54397127">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:100px;"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="fw-row">
                                    <div id="column-4913e21794c318781dfcbdc122893e83"
                                         class="fw-col-sm-8 tf-sh-4913e21794c318781dfcbdc122893e83  fw-animated-element fw-col-no-padding"
                                         data-animation-type="fadeInLeft" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:10px;"></div>
                                            <div class="fw-heading fw-heading-left  tf-sh-8b50891d89f5b2a827167faad435c161">
                                                <h3 class="fw-special-title">{{$val->title_am}}
                                                    @if($val->title_am && $val->title_ru && $val->title_en)
                                                        <img src="{{asset('wp-content/uploads/2016/06/arrow.png')}}">
                                                    @endif
                                                </h3>


                                            </div>
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:25px;"></div>
                                            <div class="fw-text-box tf-sh-0e39766cb8b7ecfcb94a851ba1d97683 ">
                                                <div class="fw-text-inner">
                                                    <p>{{$val->description_am}} </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="column-6f9e00862602620bc77d9cb796f60971"
                                         class="fw-col-sm-4 tf-sh-6f9e00862602620bc77d9cb796f60971  fw-animated-element"
                                         data-animation-type="fadeInRight" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">


                                            <div class="fw-block-image-parent image-shadow fw-block-image-right"
                                                 style="width: 360px; border-style: solid; border-width: 12px; border-color: #ffffff;">
			<span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image">
                    <img src="{{asset('/img/serviceimage/'.$val->img_name)}}" alt="afterschool-img"
                         data-maxdpr="1.7" width="360" class="lazyload"/>
                    <meta itemprop="url"
                          content=""><meta
                            itemprop="width" content="360"><meta itemprop="height" content="270"></noscript>
                <img
                        src="{{asset('/img/serviceimage/'.$val->img_name)}}"
                        alt="afterschool-img" width="360" class="lazyload"/>
            </span>
                                            </div>


                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:10px;"></div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </section>
                        @if($x != $count)
                            <section id="section-59268d1c38680"
                                     class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-9ca01a766c042023d7f9a97ea87ca096 "
                                     style="   ">
                                <div class="fw-container">
                                    <div class="fw-row">
                                        <div id="column-6e2f9e569f003377dbb520ec9f4472c4"
                                             class="fw-col-sm-6 fw-col-md-8 fw-mobile-hide-element tf-sh-6e2f9e569f003377dbb520ec9f4472c4">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                            </div>
                                        </div>
                                        <div id="column-0328ab2681847568d7ead35b2ef52f10"
                                             class="fw-col-sm-6 fw-col-md-4 tf-sh-0328ab2681847568d7ead35b2ef52f10  fw-animated-element"
                                             data-animation-type="bounceInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="text-center">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="fw-row">
                                        <div id="column-0eae44a465347ef8489a90e66f767f17"
                                             class="fw-col-sm-12 tf-sh-0eae44a465347ef8489a90e66f767f17  fw-animated-element"
                                             data-animation-type="fadeInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                                     style="height:60px;"></div>

                                                <div class="fw-block-image-parent  fw-block-image-center"
                                                     style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                            src="{{asset('wp-content/uploads/2016/06/separator.png')}}" alt="separator"
                            data-maxdpr="1.7" width="800" class="lazyload"/><meta itemprop="url"
                                                                                  content="{{asset('wp-content/uploads/2016/06/separator.png')}}"><meta
                            itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img
                        src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-sizes="auto"
                        data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"
                        alt="separator" data-maxdpr="1.7" width="800" class="lazyload"/>
                <span class="fw-after-no-ratio"
                      style="padding-bottom: 3%"></span>
            </span>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </section>
                        @endif
                    @else
                        <section id="{{$val->title_am}}"
                                 class=" fw-main-row-custom fw-section-no-padding fw-content-overlay-custom auto  tf-sh-14c3141fd7f353254ff053895f2fdd4a "
                                 style="  margin-bottom:-40px; ">
                            <div class="fw-container">
                                <div class="fw-row">
                                    <span class="my-update">
                                        <i class="fa fa-pencil-square-o fa-3x my-update" aria-hidden="true"
                                           data-toggle="modal"
                                           data-target="#myModal" data-id="{{$val->id}}"></i>
                                    </span>
                                    <span class="delete_update_image delete_section3"
                                          href='/admin/services/delete/{{$val->id}}'
                                          data-toggle="modal" data-target="#Modal">
                                                    <i class="fa fa-trash-o fa-3x"
                                                       aria-hidden="true"></i>
                                                    </span>
                                    <div id="column-6c9ce23aefe49c4df2cd8ac6384b59b6"
                                         class="fw-col-sm-4 tf-sh-6c9ce23aefe49c4df2cd8ac6384b59b6  fw-animated-element"
                                         data-animation-type="fadeInLeft" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:90px;"></div>

                                            <div class="fw-block-image-parent image-shadow fw-block-image-left"
                                                 style="width: 360px; border-style: solid; border-width: 12px; border-color: #ffffff;">
			<span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image">
                    <img
                            src="{{asset('/img/serviceimage/'.$val->img_name)}}" alt="kindergarten-img"
                            data-maxdpr="1.7" width="360" class="lazyload"/>
                    <meta itemprop="url"
                          content=""><meta
                            itemprop="width" content="360"><meta itemprop="height" content="270"></noscript>
                <img
                        src="{{asset('/img/serviceimage/'.$val->img_name)}}"
                        data-sizes="auto"
                        data-srcset=""
                        alt="kindergarten-img" data-maxdpr="1.7" width="360" class="lazyload"/>
            </span>
                                            </div>


                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:10px;"></div>
                                        </div>
                                    </div>
                                    <div id="column-5f1e16bb35311bbe36c77a451d3448ab"
                                         class="fw-col-sm-8 tf-sh-5f1e16bb35311bbe36c77a451d3448ab  fw-animated-element fw-col-no-padding"
                                         data-animation-type="fadeInRight" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                                 style="height:70px;"></div>
                                            <div class="fw-heading fw-heading-left  tf-sh-94c3cf3bee3c034f051b0740bf17b8f9">
                                                <h3 class="fw-special-title">{{$val->title_am}}
                                                    @if($val->title_am && $val->title_ru && $val->title_en)
                                                        <img src="{{asset('wp-content/uploads/2016/06/arrow.png')}}">
                                                    @endif
                                                </h3>


                                            </div>
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:25px;"></div>
                                            <div class="fw-text-box tf-sh-a83ef73ad2c4838c1ab539c8245b4aac ">
                                                <div class="fw-text-inner">
                                                    <p>{{$val->description_am}} </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </section>
                        @if($x != $count)
                            <section id="section-59268d1c3d4a2"
                                     class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-95a68af7291429b4a4a265a43c3cc006 "
                                     style="   ">
                                <div class="fw-container">
                                    <div class="fw-row">
                                        <div id="column-22b8b344984b5522f029bed9ff0592a7"
                                             class="fw-col-sm-6 fw-col-md-4 tf-sh-22b8b344984b5522f029bed9ff0592a7  fw-animated-element"
                                             data-animation-type="bounceInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="text-center">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="column-e97bc0b6fdb195cd94406c374d36bd7c"
                                         class="fw-col-sm-6 fw-col-md-8 fw-mobile-hide-element tf-sh-e97bc0b6fdb195cd94406c374d36bd7c">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                        </div>
                                    </div>
                                </div>

                                <div class="fw-row">
                                    <div id="column-47d6be7bad68946de5ed6a3a0273d066"
                                         class="fw-col-sm-12 tf-sh-47d6be7bad68946de5ed6a3a0273d066  fw-animated-element"
                                         data-animation-type="fadeInUp" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                                 style="height:60px;"></div>

                                            <div class="fw-block-image-parent  fw-block-image-center"
                                                 style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                            src="{{asset('wp-content/uploads/2016/06/separator.png')}}" alt="separator"
                            data-maxdpr="1.7" width="800" class="lazyload"/><meta itemprop="url"
                                                                                  content="{{asset('wp-content/uploads/2016/06/separator.png')}}"><meta
                            itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img
                        src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-sizes="auto"
                        data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"
                        alt="separator" data-maxdpr="1.7" width="800" class="lazyload"/><span class="fw-after-no-ratio"
                                                                                              style="padding-bottom: 3%"></span>							</span>
                                            </div>


                                        </div>
                                    </div>
                                </div>

            </div>
            </section>
            @endif
            @endif
            @php($x++)
            @endforeach
            <section id="section-59268d1c49c15"
                     class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-12472276d0a5edefd315a4dbe0caddac "
                     style="   ">
                <div class="fw-container">
                    <div class="fw-row">
                        <div id="column-69747ed839123cb03effce5fcf7dbf6d"
                             class="fw-col-sm-6 fw-col-md-4 tf-sh-69747ed839123cb03effce5fcf7dbf6d  fw-animated-element"
                             data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="text-center">
                                </div>
                            </div>
                        </div>
                        <div id="column-c663beca6ecf1234868f7137ab57b854"
                             class="fw-col-sm-6 fw-col-md-8 fw-mobile-hide-element tf-sh-c663beca6ecf1234868f7137ab57b854">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="token" value="{{csrf_token()}}" id="token">
                    <div class="fw-row">
                        <div id="column-472779d98d8ea24562ed95a6e870a3da"
                             class="fw-col-sm-12 fw-mobile-hide-element tf-sh-472779d98d8ea24562ed95a6e870a3da">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix"
                                     style="height:140px;"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
            {{--<section id="section-59268d1c4d579"--}}
                     {{--class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom fw-content-vertical-align-middle tf-sh-f304bad86b4d537e5da805a8c4bbadea "--}}
                     {{--style="  background-image:url(../../wp-content/uploads/2016/06/team-background.jpg); background-repeat: no-repeat; background-position: left top; background-size: auto;  height: 280px;">--}}
                {{--<div class="fw-container">--}}
                    {{--<div class="fw-row">--}}
                        {{--<div id="column-efbdbe37c0b7b90af8ede6bcf5e57023"--}}
                             {{--class="fw-col-sm-9 tf-sh-efbdbe37c0b7b90af8ede6bcf5e57023  fw-animated-element"--}}
                             {{--data-animation-type="bounceInUp" data-animation-delay="300">--}}
                            {{--<div class="fw-main-row-overlay"></div>--}}
                            {{--<div class="fw-col-inner">--}}
                                {{--<div class="fw-heading fw-heading-left  fw-heading-with-subtitle tf-sh-826086d450887f165de1eec3f9819135">--}}
                                    {{--<h3 class="fw-special-title">Smart Call to Action Title</h3>--}}


                                    {{--<div class="fw-special-subtitle">You can add a subtitle as well</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<div id="column-639a9c802864c3232d2545961e80ef30"--}}
                             {{--class="fw-col-sm-3 tf-sh-639a9c802864c3232d2545961e80ef30  fw-animated-element"--}}
                             {{--data-animation-type="bounceInUp" data-animation-delay="500">--}}
                            {{--<div class="fw-main-row-overlay"></div>--}}
                            {{--<div class="fw-col-inner">--}}
                                {{--<div class="text-right"><a href="/admin/about" target="_self"--}}
                                                           {{--class="fw-btn tf-sh-05ca927d3e1ff7faf5172da26129f61d    button-with-bg fw-btn-4"--}}
                                                           {{--style="width:178px; height:71px; line-height:71px;">--}}
		{{--<span style="top:0;">--}}
			{{--Read More		</span>--}}
                                    {{--</a>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}

                {{--</div>--}}
            {{--</section>--}}
        </div>


    </div><!-- /.site-main -->
    <!-- Footer -->
    @include('admin.layouts.footer')
    @include('admin.modal.servicesUpdate')
    @include('admin.modal.serviceheader')
    @include('admin.modal.delete')
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#page"><img
                src="{{asset('wp-content/uploads/2016/07/to-top.png')}}" alt="to top button"/></a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>
        $('.my-update').click(function () {
            var id = $(this).attr('data-id')
            var token = $('#token').val()
            $('.my-sevice').text('Թարմացնել Ծառայությունը')
            $.ajax
            ({
                url: '/admin/services/edit',
                data: {
                    "id": id,
                    '_token': token,
                },
                type: 'post',
                success: function (result) {
                    console.log(result['cat_id'])
                    var url = '/admin/service/update/' + result['id']
                    var src = "{{asset('img/serviceimage/')}}" + "/" + result['img_name'];
                    $('.my-submit').val('Թարմացնել')
                    $('#service_update').attr('action', url)
                    $('#update_title_am').val(result['title_am'])
                    $('#update_title_en').val(result['title_en'])
                    $('#update_title_ru').val(result['title_ru'])
                    $('#update_description_am').val(result['description_am'])
                    $('#update_description_en').val(result['description_en'])
                    $('#update_description_ru').val(result['description_ru'])

                    $('.category_class').each(function (e) {
                        if ($(this).val() == result['cat_id']) {
                            $(this).attr('selected', true)
                        }
                    })
                    $('#service_img').attr('src', src)
                }
            });
        })

        $('.anchor').click(function () {
            $('#service_update').attr('action', '/admin/service/create');
        })
    </script>
    <style>
        .delete_section3 {
            color: red;
            cursor: pointer;
            position: absolute;
            left: 5%;
            background: #ffffff;
            z-index: 99999;
        }

        .my-update {
            z-index: 99999 !important;
            cursor: pointer !important;
            position: absolute !important;
            color: #ffffff !important;
            background: red;
            text-align: center;
        }

        .alert {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            margin: auto;
            z-index: 9999999999999;
            width: 50%;
            height: 150px;
            text-align: center;
        }

        .my-all {
            position: fixed;
            width: 100%;
            height: 100%;
            z-index: 999999999999999999999999999999999999999999999999999999999;
            background: rgba(0,0,0,0.5);
        }
    </style>
    <script>
        $(document).ready(function () {
            $('.delete_update_image').click(function () {
                var href = $(this).attr('href');
                $('#delete_yes').attr('href', href);
            })
            $('.close').click(function () {
                $('.my-all').hide()
            })
        });
    </script>
    <script src="{{asset('js/admin.js')}}"></script>
    <link rel="stylesheet" href="{{asset('css/admin.css')}}">
@endsection
