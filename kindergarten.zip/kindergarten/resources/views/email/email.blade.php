<h4>FirstName : {{$data->firstname}}</h4>
<h4>LastName : {{$data->lastname}}</h4>
<h4>Email Address : {{$data->email}}</h4>
<h4>Phone Number : {{$data->phone}}</h4>
<h4>Message : {{$data->message}}</h4>