<!doctype html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" >

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/pages/pricing/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:53:26 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="../../xmlrpc.php">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PRICING | Kindergarten WordPress Theme Demo</title>

    <!-- This site is optimized with the Yoast SEO plugin v4.5 - https://yoast.com/wordpress/plugins/seo/ -->
    <link rel="canonical" href="index.html" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="PRICING | Kindergarten WordPress Theme Demo" />
    <meta property="og:url" content="index.html" />
    <meta property="og:site_name" content="Kindergarten WordPress Theme Demo" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="PRICING | Kindergarten WordPress Theme Demo" />
    <!-- / Yoast SEO plugin. -->

    <link rel='dns-prefetch' href='http://use.typekit.net/' />
    <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Feed" href="../../feed/index.html" />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Comments Feed" href="../../comments/feed/index.html" />
    <link rel='stylesheet' id='layerslider-css'  href='../../wp-content/plugins/LayerSlider/static/css/layerslider6fda.css?ver=5.6.9' type='text/css' media='all' />
    <link rel='stylesheet' id='ls-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css'  href='../../wp-content/plugins/revslider/public/assets/css/settings5223.css?ver=5.2.6' type='text/css' media='all' />
    <style id='rs-plugin-settings-inline-css' type='text/css'>
        #rs-demo-id {}
    </style>
    <link rel='stylesheet' id='woocommerce-layout-css'  href='../../wp-content/plugins/woocommerce/assets/css/woocommerce-layout32bb.css?ver=2.6.14' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='../../wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen32bb.css?ver=2.6.14' type='text/css' media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' id='woocommerce-general-css'  href='../../wp-content/plugins/woocommerce/assets/css/woocommerce32bb.css?ver=2.6.14' type='text/css' media='all' />
    <link rel='stylesheet' id='parent-style-css'  href='../../wp-content/themes/kids-play-parent/style66f2.css?ver=4.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css'  href='../../wp-content/plugins/unyson/framework/static/libs/font-awesome/css/font-awesome.min9450.css?ver=2.6.15' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css'  href='../../wp-content/themes/kids-play-parent/css/bootstrap4b68.css?ver=1.0.4' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-mmenu-css'  href='../../wp-content/themes/kids-play-parent/css/jquery.mmenu.all4b68.css?ver=1.0.4' type='text/css' media='all' />
    <link rel='stylesheet' id='kids-play-style-css'  href='../../wp-content/uploads/kids-play-style3494.css?ver=1490365741' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-theme-style-css'  href='../../wp-content/themes/kids-play-child/style4b68.css?ver=1.0.4' type='text/css' media='all' />
    <style id='fw-theme-style-inline-css' type='text/css'>
        .tf-sh-2d172d9318c24a51d826b52791797776{background-image:url(../../wp-content/uploads/2016/07/pricing-kid-1.png); background-repeat: no-repeat; background-position: center bottom; background-size: auto;}.tf-sh-2d172d9318c24a51d826b52791797776 { box-shadow: none; }@media only screen and (max-width: 767px) { .tf-sh-2d172d9318c24a51d826b52791797776 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-f5bee444c0ced6516d9f98afb301ef10 .fw-special-title {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:100px;font-size:90px;letter-spacing:0px;color:#ed3f27;}@media(max-width:767px){.tf-sh-f5bee444c0ced6516d9f98afb301ef10 .fw-special-title{font-size: 36px ; line-height: 40px ;}}
        .tf-sh-dd4110937ca34c70203a283cfe3290d4 .fw-col-inner{padding: 0px 0px 0px 10px;}.tf-sh-dd4110937ca34c70203a283cfe3290d4 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-dd4110937ca34c70203a283cfe3290d4 .fw-col-inner{padding: 0px 0px 0px 10px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-dd4110937ca34c70203a283cfe3290d4 .fw-col-inner{padding: 0px 0px 0px 10px;} }@media only screen and (max-width: 767px) { .tf-sh-dd4110937ca34c70203a283cfe3290d4 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 h6.fw-icon-title-text, .tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 h6.fw-icon-title-text a {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:42px;font-size:40px;letter-spacing:0px;color:#ffffff;}.tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 .fw-icon-title-name:hover a{opacity: 0.8;}@media(max-width:767px){.tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 h6.fw-icon-title-text, .tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 h6.fw-icon-title-text a{font-size: 28px ; line-height: 29px ;}}.tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 .fw-icon-title-icon img{width:52px;height:52px;}.tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40 .fw-icon-title-name .fw-icon-title-text{ margin-top: 5px;}
        .tf-sh-d58472aa7c5dd66cf1c8faf42755eccb .fw-col-inner{padding: 0px 60px 0px 0px;}.tf-sh-d58472aa7c5dd66cf1c8faf42755eccb .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-d58472aa7c5dd66cf1c8faf42755eccb .fw-col-inner{padding: 0px 25px 0px 0px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-d58472aa7c5dd66cf1c8faf42755eccb .fw-col-inner{padding: 0px 35px 0px 0px;} }@media only screen and (max-width: 767px) { .tf-sh-d58472aa7c5dd66cf1c8faf42755eccb .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-78e8669f6752f2fd02ef70707a9a8630 h6.fw-icon-title-text, .tf-sh-78e8669f6752f2fd02ef70707a9a8630 h6.fw-icon-title-text a {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:42px;font-size:40px;letter-spacing:0px;color:#ffffff;}.tf-sh-78e8669f6752f2fd02ef70707a9a8630 .fw-icon-title-name:hover a{opacity: 0.8;}@media(max-width:767px){.tf-sh-78e8669f6752f2fd02ef70707a9a8630 h6.fw-icon-title-text, .tf-sh-78e8669f6752f2fd02ef70707a9a8630 h6.fw-icon-title-text a{font-size: 28px ; line-height: 29px ;}}.tf-sh-78e8669f6752f2fd02ef70707a9a8630 .fw-icon-title-icon img{width:52px;height:52px;}.tf-sh-78e8669f6752f2fd02ef70707a9a8630 .fw-icon-title-name .fw-icon-title-text{ margin-top: 5px;}
        .tf-sh-52ab08806e8670224e46a34b24da472f .fw-col-inner{padding: 0px 10px 0px 0px;}.tf-sh-52ab08806e8670224e46a34b24da472f .fw-col-inner{ box-shadow: none; }@media only screen and (max-width: 767px) { .tf-sh-52ab08806e8670224e46a34b24da472f .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-60db5ea8816ddda26c75e85b31c9e362 h6.fw-icon-title-text, .tf-sh-60db5ea8816ddda26c75e85b31c9e362 h6.fw-icon-title-text a {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:42px;font-size:40px;letter-spacing:0px;color:#ffffff;}.tf-sh-60db5ea8816ddda26c75e85b31c9e362 .fw-icon-title-name:hover a{opacity: 0.8;}@media(max-width:767px){.tf-sh-60db5ea8816ddda26c75e85b31c9e362 h6.fw-icon-title-text, .tf-sh-60db5ea8816ddda26c75e85b31c9e362 h6.fw-icon-title-text a{font-size: 28px ; line-height: 29px ;}}.tf-sh-60db5ea8816ddda26c75e85b31c9e362 .fw-icon-title-icon img{width:52px;height:52px;}.tf-sh-60db5ea8816ddda26c75e85b31c9e362 .fw-icon-title-name .fw-icon-title-text{ margin-top: 5px;}
        .tf-sh-e2756c36a681f1d487527e3c54397127 .fw-col-inner{ box-shadow: none; }
        .tf-sh-4913e21794c318781dfcbdc122893e83 .fw-col-inner{padding: 0px 15px 0px 95px;}.tf-sh-4913e21794c318781dfcbdc122893e83 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-4913e21794c318781dfcbdc122893e83 .fw-col-inner{padding: 0px 15px 0px 0px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-4913e21794c318781dfcbdc122893e83 .fw-col-inner{padding: 0px 15px 0px 15px;} }@media only screen and (max-width: 767px) { .tf-sh-4913e21794c318781dfcbdc122893e83 .fw-col-inner{padding: 0px 15px 0px 15px;} }
        .tf-sh-8b50891d89f5b2a827167faad435c161 .fw-special-title {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:80px;font-size:70px;letter-spacing:0px;color:#622a14;}@media(max-width:767px){.tf-sh-8b50891d89f5b2a827167faad435c161 .fw-special-title{font-size: 35px ; line-height: 40px ;}}
        .tf-sh-c951cd3b7f19082b1e56848cac97c3dc .fw-col-inner{padding: 0px 95px 0px 30px;}.tf-sh-c951cd3b7f19082b1e56848cac97c3dc .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-c951cd3b7f19082b1e56848cac97c3dc .fw-col-inner{padding: 0px 15px 0px 10px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-c951cd3b7f19082b1e56848cac97c3dc .fw-col-inner{padding: 51px 15px 0px 30px;} }@media only screen and (max-width: 767px) { .tf-sh-c951cd3b7f19082b1e56848cac97c3dc .fw-col-inner{padding: 0px 15px 0px 15px;} }
        .tf-sh-82e7d97c08f503a997c0ad82cb159425, .tf-sh-82e7d97c08f503a997c0ad82cb159425:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-82e7d97c08f503a997c0ad82cb159425{font-size: 22px ; line-height: 23px ;}}.tf-sh-82e7d97c08f503a997c0ad82cb159425:hover { color: #552715 }
        .tf-sh-1afbd7005c5eb0e373926e5a4659343b .fw-col-inner{ box-shadow: none; }
        .tf-sh-ea63151805057ca8160dd5eb3f5829e4 .fw-col-inner{padding: 50px 60px 0px 60px;}.tf-sh-ea63151805057ca8160dd5eb3f5829e4{background-image:url(../../wp-content/uploads/2016/07/pricing-bg.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;}.tf-sh-ea63151805057ca8160dd5eb3f5829e4 { box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-ea63151805057ca8160dd5eb3f5829e4 .fw-col-inner{padding: 50px 40px 0px 40px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-ea63151805057ca8160dd5eb3f5829e4 .fw-col-inner{padding: 50px 235px 40px 235px;} }@media only screen and (max-width: 767px) { .tf-sh-ea63151805057ca8160dd5eb3f5829e4 .fw-col-inner{padding: 28px 33px 30px 33px;} }
        .tf-sh-18a6dc26c80d6e32eff80cf39ac476c4 .fw-special-title {font-family:Noto Serif;font-style: normal;font-weight:700;line-height:48px;font-size:72px;letter-spacing:-1px;color:#622a14;}@media(max-width:767px){.tf-sh-18a6dc26c80d6e32eff80cf39ac476c4 .fw-special-title{font-size: 36px ; line-height: 24px ;}}.tf-sh-18a6dc26c80d6e32eff80cf39ac476c4 .fw-special-subtitle {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:40px;font-size:43px;letter-spacing:0.5px;color:#622a14;}@media(max-width:767px){.tf-sh-18a6dc26c80d6e32eff80cf39ac476c4 .fw-special-subtitle{font-size: 30px ; line-height: 28px ;}}
        .tf-sh-c0f8ec740060c0ef80623d21e5c589fe .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-624025f0852e602d10f9f9649ce38532.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-624025f0852e602d10f9f9649ce38532.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-79682a1987ff9b74d8d8181fc012017c .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-4096cd39a810cd56bad669b5893e1e84.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-4096cd39a810cd56bad669b5893e1e84.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-83a7eed67351086a4aff830d895d3f28 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-3637013c398a8ccab96bc72a8a22ab52.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-3637013c398a8ccab96bc72a8a22ab52.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-da85a0085a1dddeed430c2fde9d19a47 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-8783645e862262faec8cd78b2d73ae1c, .tf-sh-8783645e862262faec8cd78b2d73ae1c:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-8783645e862262faec8cd78b2d73ae1c{font-size: 22px ; line-height: 23px ;}}.tf-sh-8783645e862262faec8cd78b2d73ae1c:hover { color: #552715 }
        .tf-sh-4a607993179ed09c89f2138a96553b89 .fw-col-inner{padding: 50px 60px 0px 60px;}.tf-sh-4a607993179ed09c89f2138a96553b89{background-image:url(../../wp-content/uploads/2016/07/pricing-bg.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;}.tf-sh-4a607993179ed09c89f2138a96553b89 { box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-4a607993179ed09c89f2138a96553b89 .fw-col-inner{padding: 50px 40px 0px 40px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-4a607993179ed09c89f2138a96553b89 .fw-col-inner{padding: 50px 235px 40px 235px;} }@media only screen and (max-width: 767px) { .tf-sh-4a607993179ed09c89f2138a96553b89 .fw-col-inner{padding: 28px 33px 30px 33px;} }
        .tf-sh-abe9766afe9f9ab5d514aa6d9455f661 .fw-special-title {font-family:Noto Serif;font-style: normal;font-weight:700;line-height:48px;font-size:72px;letter-spacing:-1px;color:#622a14;}@media(max-width:767px){.tf-sh-abe9766afe9f9ab5d514aa6d9455f661 .fw-special-title{font-size: 36px ; line-height: 24px ;}}.tf-sh-abe9766afe9f9ab5d514aa6d9455f661 .fw-special-subtitle {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:40px;font-size:43px;letter-spacing:0.5px;color:#622a14;}@media(max-width:767px){.tf-sh-abe9766afe9f9ab5d514aa6d9455f661 .fw-special-subtitle{font-size: 30px ; line-height: 28px ;}}
        .tf-sh-d0307123f7aa9e2ac94b26b60d156e64 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-e5eada2a168a927b374a3603b2162de2.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-e5eada2a168a927b374a3603b2162de2.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-732b72a3fa7874f72d9d8f6a0155308b .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-86a25cca257c42bf73069ef857559959.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-86a25cca257c42bf73069ef857559959.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-4d2633f756514db1fe51176b97d6d85c .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-44357d6a566837d640b8e375ab3acc2e.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-44357d6a566837d640b8e375ab3acc2e.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-9803b7f7306ba62d9435fd5c3d626f59 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-483f9b7091275cbd6afaf561cf925c05, .tf-sh-483f9b7091275cbd6afaf561cf925c05:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-483f9b7091275cbd6afaf561cf925c05{font-size: 22px ; line-height: 23px ;}}.tf-sh-483f9b7091275cbd6afaf561cf925c05:hover { color: #552715 }
        .tf-sh-5223f09e727b77024e8810dded61382e .fw-col-inner{padding: 50px 60px 0px 60px;}.tf-sh-5223f09e727b77024e8810dded61382e{background-image:url(../../wp-content/uploads/2016/07/pricing-bg.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;}.tf-sh-5223f09e727b77024e8810dded61382e { box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-5223f09e727b77024e8810dded61382e .fw-col-inner{padding: 50px 40px 0px 40px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-5223f09e727b77024e8810dded61382e .fw-col-inner{padding: 50px 235px 40px 235px;} }@media only screen and (max-width: 767px) { .tf-sh-5223f09e727b77024e8810dded61382e .fw-col-inner{padding: 28px 33px 30px 33px;} }
        .tf-sh-fc3fcf37989d06e7dc5aa52db3313a8f .fw-special-title {font-family:Noto Serif;font-style: normal;font-weight:700;line-height:48px;font-size:72px;letter-spacing:-1px;color:#622a14;}@media(max-width:767px){.tf-sh-fc3fcf37989d06e7dc5aa52db3313a8f .fw-special-title{font-size: 36px ; line-height: 24px ;}}.tf-sh-fc3fcf37989d06e7dc5aa52db3313a8f .fw-special-subtitle {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:40px;font-size:43px;letter-spacing:0.5px;color:#622a14;}@media(max-width:767px){.tf-sh-fc3fcf37989d06e7dc5aa52db3313a8f .fw-special-subtitle{font-size: 30px ; line-height: 28px ;}}
        .tf-sh-270826f1fd8f559d9560461701883cc2 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-7f548dcc1f5e5135ec144a97638c5f05.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-7f548dcc1f5e5135ec144a97638c5f05.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-068d69aa890f91d89fc771d68bda489e .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-651e2515b632786a8f4786106ba8aa48.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-651e2515b632786a8f4786106ba8aa48.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-420b03ba3030a31500fa803da1c30f92 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-13cbfdd1d59449cb3f5c45ab2ab2715c.fw-divider-line {border-bottom-width: 1px; margin-top:-0.5px;}.tf-sh-13cbfdd1d59449cb3f5c45ab2ab2715c.fw-divider-special .fw-divider-holder {border-top-width: 1px; margin-top:-0.5px;}
        .tf-sh-a0556650e88b4364fa2c66d21cdaab35 .fw-text-inner {font-family:Noto Serif;font-style:italic;font-weight:400;line-height:28px;font-size:17px;letter-spacing:-1px;color:#322019;}
        .tf-sh-9e8adafb2820628c14f4e57f6331d6e9, .tf-sh-9e8adafb2820628c14f4e57f6331d6e9:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-9e8adafb2820628c14f4e57f6331d6e9{font-size: 22px ; line-height: 23px ;}}.tf-sh-9e8adafb2820628c14f4e57f6331d6e9:hover { color: #552715 }
        .tf-sh-b557d7f5f23fcefa43d3bba1896bd643 .fw-col-inner{ box-shadow: none; }
        .tf-sh-1467bfe085c8aa203df325a8bdb51775 .fw-col-inner{padding: 0px 85px 10px 85px;}.tf-sh-1467bfe085c8aa203df325a8bdb51775 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-1467bfe085c8aa203df325a8bdb51775 .fw-col-inner{padding: 0px 85px 10px 85px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-1467bfe085c8aa203df325a8bdb51775 .fw-col-inner{padding: 0px 60px 10px 15px;} }@media only screen and (max-width: 767px) { .tf-sh-1467bfe085c8aa203df325a8bdb51775 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-ee9bffb084b942147dd1bc253beaba9e .fw-special-title {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:60px;font-size:50px;letter-spacing:0px;color:#622a14;}@media(max-width:767px){.tf-sh-ee9bffb084b942147dd1bc253beaba9e .fw-special-title{font-size: 30px ; line-height: 36px ;}}
        .tf-sh-73b314656828e205e649fd12a3f65aec .fw-col-inner{padding: 0px 0px 0px 100px;}.tf-sh-73b314656828e205e649fd12a3f65aec .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-73b314656828e205e649fd12a3f65aec .fw-col-inner{padding: 0px 0px 0px 100px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-73b314656828e205e649fd12a3f65aec .fw-col-inner{padding: 0px 0px 0px 30px;} }@media only screen and (max-width: 767px) { .tf-sh-73b314656828e205e649fd12a3f65aec .fw-col-inner{padding: 0px 15px 0px 15px;} }
        .tf-sh-8da2bb1c94cfcfc4ce0b00db63385e5e .fw-col-inner{padding: 0px 20px 0px 0px;}.tf-sh-8da2bb1c94cfcfc4ce0b00db63385e5e .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-8da2bb1c94cfcfc4ce0b00db63385e5e .fw-col-inner{padding: 0px 20px 0px 0px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-8da2bb1c94cfcfc4ce0b00db63385e5e .fw-col-inner{padding: 0px 0px 0px 0px;} }@media only screen and (max-width: 767px) { .tf-sh-8da2bb1c94cfcfc4ce0b00db63385e5e .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-e9727d1d0033d6b09783e125ce3c0cee, .tf-sh-e9727d1d0033d6b09783e125ce3c0cee:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-e9727d1d0033d6b09783e125ce3c0cee{font-size: 22px ; line-height: 23px ;}}.tf-sh-e9727d1d0033d6b09783e125ce3c0cee:hover { color: #552715 }
        .tf-sh-0eae44a465347ef8489a90e66f767f17 .fw-col-inner{ box-shadow: none; }@media only screen and (max-width: 767px) { .tf-sh-0eae44a465347ef8489a90e66f767f17 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-9bfbf831f1024e873c559a0319a1210e .fw-col-inner{padding: 0px 85px 10px 85px;}.tf-sh-9bfbf831f1024e873c559a0319a1210e .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-9bfbf831f1024e873c559a0319a1210e .fw-col-inner{padding: 0px 85px 10px 85px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-9bfbf831f1024e873c559a0319a1210e .fw-col-inner{padding: 0px 60px 10px 15px;} }@media only screen and (max-width: 767px) { .tf-sh-9bfbf831f1024e873c559a0319a1210e .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-7850c44d07f5790feadbcd8234527ca9 .fw-special-title {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:60px;font-size:50px;letter-spacing:0px;color:#622a14;}@media(max-width:767px){.tf-sh-7850c44d07f5790feadbcd8234527ca9 .fw-special-title{font-size: 30px ; line-height: 36px ;}}
        .tf-sh-02e848aa7d9c9644575fac9a633c844f .fw-col-inner{padding: 0px 0px 0px 100px;}.tf-sh-02e848aa7d9c9644575fac9a633c844f .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-02e848aa7d9c9644575fac9a633c844f .fw-col-inner{padding: 0px 0px 0px 100px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-02e848aa7d9c9644575fac9a633c844f .fw-col-inner{padding: 0px 0px 0px 30px;} }@media only screen and (max-width: 767px) { .tf-sh-02e848aa7d9c9644575fac9a633c844f .fw-col-inner{padding: 0px 15px 0px 15px;} }
        .tf-sh-df6ef081014e8fbec8863d35a6c5c506 .fw-col-inner{padding: 0px 20px 0px 0px;}.tf-sh-df6ef081014e8fbec8863d35a6c5c506 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-df6ef081014e8fbec8863d35a6c5c506 .fw-col-inner{padding: 0px 20px 0px 0px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-df6ef081014e8fbec8863d35a6c5c506 .fw-col-inner{padding: 0px 0px 0px 0px;} }@media only screen and (max-width: 767px) { .tf-sh-df6ef081014e8fbec8863d35a6c5c506 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-da943cb8a69d9b6abf923b86bca55b66, .tf-sh-da943cb8a69d9b6abf923b86bca55b66:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-da943cb8a69d9b6abf923b86bca55b66{font-size: 22px ; line-height: 23px ;}}.tf-sh-da943cb8a69d9b6abf923b86bca55b66:hover { color: #552715 }
        .tf-sh-5120521b0c911fdf946b1ab54919780b .fw-col-inner{ box-shadow: none; }@media only screen and (max-width: 767px) { .tf-sh-5120521b0c911fdf946b1ab54919780b .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-027f4dac64c2d3c40d63987bd28f4d58 .fw-col-inner{padding: 0px 85px 10px 85px;}.tf-sh-027f4dac64c2d3c40d63987bd28f4d58 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-027f4dac64c2d3c40d63987bd28f4d58 .fw-col-inner{padding: 0px 85px 10px 85px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-027f4dac64c2d3c40d63987bd28f4d58 .fw-col-inner{padding: 0px 60px 10px 15px;} }@media only screen and (max-width: 767px) { .tf-sh-027f4dac64c2d3c40d63987bd28f4d58 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-ba7236b36612514d84b3ef71d7003cec .fw-special-title {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:60px;font-size:50px;letter-spacing:0px;color:#622a14;}@media(max-width:767px){.tf-sh-ba7236b36612514d84b3ef71d7003cec .fw-special-title{font-size: 30px ; line-height: 36px ;}}
        .tf-sh-a7d37a5081a00fa881aedc84b2506a71 .fw-col-inner{padding: 0px 0px 0px 100px;}.tf-sh-a7d37a5081a00fa881aedc84b2506a71 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-a7d37a5081a00fa881aedc84b2506a71 .fw-col-inner{padding: 0px 0px 0px 100px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-a7d37a5081a00fa881aedc84b2506a71 .fw-col-inner{padding: 0px 0px 0px 30px;} }@media only screen and (max-width: 767px) { .tf-sh-a7d37a5081a00fa881aedc84b2506a71 .fw-col-inner{padding: 0px 15px 0px 15px;} }
        .tf-sh-702f0d97c46acc984ea7edc13280aaf3 .fw-col-inner{padding: 0px 20px 0px 0px;}.tf-sh-702f0d97c46acc984ea7edc13280aaf3 .fw-col-inner{ box-shadow: none; }@media only screen and (min-width: 992px) and (max-width: 1199px) { .tf-sh-702f0d97c46acc984ea7edc13280aaf3 .fw-col-inner{padding: 0px 20px 0px 0px;} }@media only screen and (min-width: 768px) and (max-width: 991px) { .tf-sh-702f0d97c46acc984ea7edc13280aaf3 .fw-col-inner{padding: 0px 0px 0px 0px;} }@media only screen and (max-width: 767px) { .tf-sh-702f0d97c46acc984ea7edc13280aaf3 .fw-col-inner{padding: 0px 0px 0px 0px;} }
        .tf-sh-00c8779a3b7681a223b3d7bde6fa8fb6, .tf-sh-00c8779a3b7681a223b3d7bde6fa8fb6:focus {font-family:Amatic SC;font-style: normal;font-weight:700;line-height:29px;font-size:28px;letter-spacing:0px;color:#ffffff;}@media(max-width:767px){.tf-sh-00c8779a3b7681a223b3d7bde6fa8fb6{font-size: 22px ; line-height: 23px ;}}.tf-sh-00c8779a3b7681a223b3d7bde6fa8fb6:hover { color: #552715 }
        .tf-sh-374748a921bc8188da39edf67782379b .fw-col-inner{ box-shadow: none; }
        .tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093{background-color:#ffaf1c;}.tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093 { box-shadow: none; }@media only screen and (max-width: 767px) { .tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093 .fw-col-inner{padding: 0px 0px 0px 0px;} }
    </style>
    <link rel='stylesheet' id='prettyPhoto-css'  href='../../wp-content/themes/kids-play-parent/css/prettyPhoto4b68.css?ver=1.0.4' type='text/css' media='all' />
    <link rel='stylesheet' id='animate-css'  href='../../wp-content/themes/kids-play-parent/css/animate4b68.css?ver=1.0.4' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='../../wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/background66f2.css?ver=4.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='select-box-css'  href='../../../themefuse_ribbon_static/themefuse_ribon/css/jquery.selectBoxIt9811.css?ver=1.0.22' type='text/css' media='all' />
    <link rel='stylesheet' id='ribbon-demo-css'  href='../../../themefuse_ribbon_static/themefuse_ribon/demo9811.css?ver=1.0.22' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-googleFonts-css'  href='https://fonts.googleapis.com/css?family=Amatic+SC%3A700%7CNoto+Serif%3A700%2Cregular%2Citalic%2C700italic%7CNTR%3Aregular%7CNoto+Sans%3A700%7CMontserrat%3A700%2Cregular%7CQuattrocento+Sans%3A700%7CMerriweather%3A700&amp;subset=latin%2Clatin-ext&amp;ver=4.7.5' type='text/css' media='all' />
    <script type='text/javascript' src='../../wp-content/plugins/LayerSlider/static/js/greensockcd11.js?ver=1.11.8'></script>
    <script type='text/javascript' src='../../wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
    <script type='text/javascript' src='../../wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var LS_Meta = {"v":"5.6.9"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='../../wp-content/plugins/LayerSlider/static/js/layerslider.kreaturamedia.jquery6fda.js?ver=5.6.9'></script>
    <script type='text/javascript' src='../../wp-content/plugins/LayerSlider/static/js/layerslider.transitions6fda.js?ver=5.6.9'></script>
    <script type='text/javascript' src='../../wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min5223.js?ver=5.2.6'></script>
    <script type='text/javascript' src='../../wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min5223.js?ver=5.2.6'></script>
    <script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/lib/bootstrap.min4b68.js?ver=1.0.4'></script>
    <script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/jquery.touchSwipe.min4b68.js?ver=1.0.4'></script>
    <script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/lib/html5shiv4b68.js?ver=1.0.4'></script>
    <script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/lib/respond.min4b68.js?ver=1.0.4'></script>
    <meta name="generator" content="Powered by LayerSlider 5.6.9 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
    <!-- LayerSlider updates and docs at: https://kreaturamedia.com/layerslider-responsive-wordpress-slider-plugin/ -->
    <link rel='https://api.w.org/' href='../../wp-json/index.html' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="../../xmlrpc0db0.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../../wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 4.7.5" />
    <meta name="generator" content="WooCommerce 2.6.14" />
    <link rel='shortlink' href='../../index0345.html?p=22' />
    <link rel="alternate" type="application/json+oembed" href="../../wp-json/oembed/1.0/embed77ef.json?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2Fpages%2Fpricing%2F" />
    <link rel="alternate" type="text/xml+oembed" href="../../wp-json/oembed/1.0/embed3152?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2Fpages%2Fpricing%2F&amp;format=xml" />
    <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
    <meta name="generator" content="Powered by Slider Revolution 5.2.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
</head>
<body class="page-template page-template-visual-builder-template page-template-visual-builder-template-php page page-id-22 page-child parent-pageid-16 fw-full fw-website-align-center fw-section-space-md header-1 fw-top-bar-off fw-absolute-header fw-top-social-right  fw-top-logo-left fw-logo-image fw-logo-retina fw-animation-mobile-off tf-static-ribbon-bar" itemscope="itemscope" itemtype="http://schema.org/WebPage">
@yield('content')
<script>if (top.location != location) {
        // detect if location differ and redirect to original link (for exclude a external iframe)
        if( jQuery.isEmptyObject(top.location) ) {
            top.location.href = document.location.href;
        }
    }</script>

<script type='text/javascript'>
    /* <![CDATA[ */
    var TFvar = {"theme": "kindergarten-wordpress-theme"};
    /* ]]> */
</script>

<!-- Fonts -->
<script type="text/javascript">
    try {
        Typekit.load();
    }
    catch (e) {
    }
</script>

<script type="text/javascript">
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
        a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '../../../../www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-57682328-1', 'themefuse.com');
    ga('require', 'displayfeatures');
    ga('send', 'pageview');

    // Load the plugin.
    ga('require', 'linker');

    // Define which domains to autoLink.
    ga('linker:autoLink', ['fastspring.com','gumroad.com','gum.co','themeforest.net','mojomarketplace.com']);
</script>

<div class="paymant-google-iframe">
    <script type="text/javascript">
        /* <![CDATA[ */
        var google_conversion_id = 957922173;
        var google_custom_params = window.google_tag_params;
        var google_remarketing_only = true;
        /* ]]> */
    </script>
    <script type="text/javascript" src="../../../../www.googleadservices.com/pagead/f.txt">
    </script>
    <noscript>
        <div style="display:inline;">
            <img height="1" width="1" style="border-style:none;" alt="" src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/957922173/?value=0&amp;guid=ON&amp;script=0"/>
        </div>
    </noscript>
</div>

<script type="text/javascript" id='am-ctcs-v1'>
    (function () {
        var url = (("https:" == document.location.protocol) ?
                "https://account.themefuse.com" : "https://account.themefuse.com");
        var d = document, s = d.createElement('script'), src = d.getElementsByTagName('script')[0];
        var w = window;
        var lo = w.location;
        var hr = lo.href;
        var ho = lo.host;
        var se = lo.search;
        var m = RegExp('[?&]r=([^&]*)').exec(se);
        var ref = m && decodeURIComponent(m[1].replace(/\+/g, ' '));
        s.type = 'text/javascript';
        s.async = true;
        s.src = url + '/aff/click-js/?r=' + ref + '&s=' + encodeURIComponent(document.referrer);
        if (ref) {
            src.parentNode.insertBefore(s, src);
            var uri = hr.toString().split(ho)[1];
            w.history.replaceState('Object', 'Title', uri.replace(m[0], ""));
        }
    })();
</script>

<script>
    window.intercomSettings = {
        app_id: "j11sgamw"
    };
</script>

<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
            document,'script','../../../../connect.facebook.net/en_US/fbevents.js');
    fbq('init', '138632519954398');
    fbq('track', 'PageView');
    fbq('track', 'ViewContent', {
        value: 59,
        currency: 'USD'
    });
</script>
<noscript><img alt="" height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=138632519954398&amp;ev=PageView&amp;noscript=1"/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->

<script>(function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',intercomSettings);}else{var d=document;var i=function(){i.c(arguments)};i.q=[];i.c=function(args){i.q.push(args)};w.Intercom=i;function l(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/j11sgamw';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);}if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})()</script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var wc_add_to_cart_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/pages\/pricing\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme","is_cart":"","cart_redirect_after_add":"no"};
    /* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min32bb.js?ver=2.6.14'></script>
<script type='text/javascript' src='../../wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var woocommerce_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/pages\/pricing\/?wc-ajax=%%endpoint%%"};
    /* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min32bb.js?ver=2.6.14'></script>
<script type='text/javascript' src='../../wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js?ver=1.4.1'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var wc_cart_fragments_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/pages\/pricing\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
    /* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min32bb.js?ver=2.6.14'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/lib/modernizr.min4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/jquery.carouFredSel-6.2.1-packed4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/jquery.prettyPhoto4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/jquery.customInput4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/scrollTo.min4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/jquery.mmenu.min.all4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/selectize.min4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/jquery.parallax4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/effect.mine899.js?ver=1.11.4'></script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/lazysizes.min4b68.js?ver=1.0.4'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var FwPhpVars = {"ajax_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","template_directory":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-content\/themes\/kids-play-parent","previous":"Previous","next":"Next","smartphone_animations":"no","header_5_position":"left","header_6_position":"left","effect_panels":"","effect_listitems_slide":"","fail_form_error":"Sorry you are an error in ajax, please contact the administrator of the website","socials":""};
    /* ]]> */
</script>
<script type='text/javascript' src='../../wp-content/themes/kids-play-parent/js/general4b68.js?ver=1.0.4'></script>
<script type='text/javascript' src='../../wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core66f2.js?ver=4.7.5'></script>
<script type='text/javascript' src='../../wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition66f2.js?ver=4.7.5'></script>
<script type='text/javascript' src='../../wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background66f2.js?ver=4.7.5'></script>
<script type='text/javascript' src='../../wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init66f2.js?ver=4.7.5'></script>
<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/libs/jquery-ui9811.js?ver=1.0.22'></script>
<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/jquery.selectBoxIt9811.js?ver=1.0.22'></script>
<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/jquery.nicescroll.min9811.js?ver=1.0.22'></script>
<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/general9811.js?ver=1.0.22'></script>
<script type='text/javascript' src='../../../../use.typekit.net/dmy3vly9811.js?ver=1.0.22'></script>
<script type='text/javascript' src='../../wp-includes/js/wp-embed.min66f2.js?ver=4.7.5'></script>
</body>

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/pages/pricing/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:53:30 GMT -->
</html>