<header class="fw-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
    <div class="fw-header-main">
        <div class="fw-container">
            <div class="fw-wrap-logo">

                <a href="/" class="fw-site-logo">
                    <img src="{{asset('wp-content/uploads/2016/07/Logo-2.png')}}"
                         alt="Kindergarten WordPress Theme Demo"/>
                </a>

            </div>
            <div class="fw-nav-wrap" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement"
                 role="navigation">
                <nav id="fw-menu-primary" class="fw-site-navigation primary-navigation">
                    <ul id="menu-header-menu" class="fw-nav-menu">
                        <li id="menu-item-438"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-438"><a
                                    href="/">{{__('header.home')}}</a></li>
                        <li id="menu-item-442"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442"><a
                                    href="#0">{{__('header.services')}}</a>
                            <ul class="mega-menu">
                                @php($i=0)
                                @foreach($ses_services as $val)
                                    <li>
                                        <a href="/services/{{$url_ser[$i]}}">@if(session('locale') =='en'){{$val->name_en}}@elseif(session('locale') =='ru'){{$val->name_ru}}@else{{$val->name_am}}@endif</a>
                                    </li>
                                    @php($i++)
                                @endforeach
                            </ul>
                        </li>
                        <li id="menu-item-440"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-440"><a
                                    href="/gallery">{{__('header.gallery')}}</a></li>
                        <li id="menu-item-441"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-441"><a
                                    href="/about">{{__('header.about')}}</a></li>
                        <li id="menu-item-439"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-439"><a
                                    href="/contact">{{__('header.contact')}}</a>
                        </li>
                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442">
                            <a href="#0" class=" my-menu">{{$locale}}</a>
                            <ul class="dropdown-menu my-dropdown">

                                @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442">
                                        <a rel="alternate" hreflang="{{ $localeCode }}"
                                           href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">
                                            {{ $properties['native'] }}
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </li>
                    </ul>

                </nav>


            </div>
        </div>
    </div>
</header>
<style>
    .header-1 .primary-navigation > ul > li > a{
        margin-left: 25px !important;
    }
    .my-menu{
        text-transform: uppercase;
    }
    .my-dropdown{
        position: absolute !important;
        left: 40% !important;
        top: 55% !important;
        margin-top: 10px;
        width: 0px !important;
    }
</style>