<!doctype html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" >

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/pages/gallery/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:53:15 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="{{asset("xmlrpc.php")}}">
    <meta name="" content="">
    <title>GALLERY | Kindergarten</title>

    <!-- This site is optimized with the Yoast SEO plugin v4.5 - https://yoast.com/wordpress/plugins/seo/ -->
    <link rel="canonical" href="index.html" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="o" />
    <meta name="" content="" />
    <meta name="" content="GALLERY | Kindergarten" />
    <!-- / Yoast SEO plugin. -->

    <link rel='dns-prefetch' href='http://use.typekit.net/' />
    <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Feed" href="{{asset("feed/index.html")}}" />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Comments Feed" href="{{asset("comments/feed/index.html")}}" />
    <link rel='stylesheet' id='layerslider-css'  href='{{asset("wp-content/plugins/LayerSlider/static/css/layerslider6fda.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='ls-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css'  href='{{asset("wp-content/plugins/revslider/public/assets/css/settings5223.css")}}' type='text/css' media='all' />
    <style id='rs-plugin-settings-inline-css' type='text/css'>
        #rs-demo-id {}
    </style>
    <link rel='stylesheet' id='woocommerce-layout-css'  href='{{asset("wp-content/plugins/woocommerce/assets/css/woocommerce-layout32bb.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='{{asset("wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen32bb.css")}}' type='text/css' media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' id='woocommerce-general-css'  href='{{asset("wp-content/plugins/woocommerce/assets/css/woocommerce32bb.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='parent-style-css'  href='{{asset("wp-content/themes/kids-play-parent/style66f2.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css'  href='{{asset("wp-content/plugins/unyson/framework/static/libs/font-awesome/css/font-awesome.min9450.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css'  href='{{asset("wp-content/themes/kids-play-parent/css/bootstrap4b68.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-mmenu-css'  href='{{asset("wp-content/themes/kids-play-parent/css/jquery.mmenu.all4b68.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='kids-play-style-css'  href='{{asset("wp-content/uploads/kids-play-style3494.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-theme-style-css'  href='{{asset("wp-content/themes/kids-play-child/style4b68.css")}}' type='text/css' media='all' />




    <link rel="stylesheet" href="{{asset('css/gallerystyle.css')}}">



    <link rel='stylesheet' id='prettyPhoto-css'  href='{{asset("wp-content/themes/kids-play-parent/css/prettyPhoto4b68.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='animate-css'  href='{{asset("wp-content/themes/kids-play-parent/css/animate4b68.css")}}' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='{{asset("wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/background66f2.css")}}' type='text/css' media='all' />
    {{--<link rel='stylesheet' id='select-box-css'  href='../../../themefuse_ribbon_static/themefuse_ribon/css/jquery.selectBoxIt9811.css?ver=1.0.22' type='text/css' media='all' />--}}
    {{--<link rel='stylesheet' id='ribbon-demo-css'  href='../../../themefuse_ribbon_static/themefuse_ribon/demo9811.css?ver=1.0.22' type='text/css' media='all' />--}}
    <link rel='stylesheet' id='fw-googleFonts-css'  href='https://fonts.googleapis.com/css?family=Amatic+SC%3A700%7CNoto+Serif%3A700%2Cregular%2Citalic%7CNTR%3Aregular%7CNoto+Sans%3A700%7CMontserrat%3A700%2Cregular%7CQuattrocento+Sans%3A700%7CMerriweather%3A700&amp;subset=latin&amp;ver=4.7.5' type='text/css' media='all' />
    <script type='text/javascript' src='{{asset("wp-content/plugins/LayerSlider/static/js/greensockcd11.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-includes/js/jquery/jqueryb8ff.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-includes/js/jquery/jquery-migrate.min330a.js")}}'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var LS_Meta = {"v":"5.6.9"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='{{asset("wp-content/plugins/LayerSlider/static/js/layerslider.kreaturamedia.jquery6fda.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/plugins/LayerSlider/static/js/layerslider.transitions6fda.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min5223.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min5223.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/themes/kids-play-parent/js/lib/bootstrap.min4b68.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/themes/kids-play-parent/js/jquery.touchSwipe.min4b68.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/themes/kids-play-parent/js/lib/html5shiv4b68.js")}}'></script>
    <script type='text/javascript' src='{{asset("wp-content/themes/kids-play-parent/js/lib/respond.min4b68.js")}}'></script>
    <meta name="generator" content="Powered by LayerSlider 5.6.9 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
    <!-- LayerSlider updates and docs at: https://kreaturamedia.com/layerslider-responsive-wordpress-slider-plugin/ -->
    <link rel='https://api.w.org/' href='{{asset("wp-json/index.html")}}' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="{{asset("xmlrpc0db0.php?rsd")}}" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="{{asset("wp-includes/wlwmanifest.xml")}}" />
    <meta name="" content="" />
    <meta name="" content="" />
    <link rel='shortlink' href='{{asset("index970c.html?p=25")}}' />
    <link rel="alternate" type="application/json+oembed" href="{{asset("wp-json/oembed/1.0/embed50b0.json?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2Fpages%2Fgallery%2F")}}" />
    <link rel="alternate" type="text/xml+oembed" href="{{asset("wp-json/oembed/1.0/embeda5a5?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2Fpages%2Fgallery%2F&amp;format=xml")}}" />
    <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
    <meta name="generator" content="Powered by Slider Revolution 5.2.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
</head>
<body class="page-template page-template-visual-builder-template page-template-visual-builder-template-php page page-id-25 page-child parent-pageid-16 fw-full fw-website-align-center fw-section-space-md header-1 fw-top-bar-off fw-absolute-header fw-top-social-right  fw-top-logo-left fw-logo-image fw-logo-retina fw-animation-mobile-off tf-static-ribbon-bar" itemscope="itemscope" itemtype="http://schema.org/WebPage">





    @yield('content')





    {{--<script>if (top.location != location) {--}}
            {{--// detect if location differ and redirect to original link (for exclude a external iframe)--}}
            {{--if( jQuery.isEmptyObject(top.location) ) {--}}
                {{--top.location.href = document.location.href;--}}
            {{--}--}}
        {{--}</script>--}}

    {{--<script type='text/javascript'>--}}
        {{--/* <![CDATA[ */--}}
        {{--var TFvar = {"theme": "kindergarten-wordpress-theme"};--}}
        {{--/* ]]> */--}}
    {{--</script>--}}

    {{--<!-- Fonts -->--}}
    {{--<script type="text/javascript">--}}
        {{--try {--}}
            {{--Typekit.load();--}}
        {{--}--}}
        {{--catch (e) {--}}
        {{--}--}}
    {{--</script>--}}

    {{--<script type="text/javascript">--}}
        {{--(function (i, s, o, g, r, a, m) {--}}
            {{--i['GoogleAnalyticsObject'] = r;--}}
            {{--i[r] = i[r] || function () {--}}
                        {{--(i[r].q = i[r].q || []).push(arguments)--}}
                    {{--}, i[r].l = 1 * new Date();--}}
            {{--a = s.createElement(o),--}}
                    {{--m = s.getElementsByTagName(o)[0];--}}
            {{--a.async = 1;--}}
            {{--a.src = g;--}}
            {{--m.parentNode.insertBefore(a, m)--}}
        {{--})(window, document, 'script', '../../../../www.google-analytics.com/analytics.js', 'ga');--}}

        {{--ga('create', 'UA-57682328-1', 'themefuse.com');--}}
        {{--ga('require', 'displayfeatures');--}}
        {{--ga('send', 'pageview');--}}

        {{--// Load the plugin.--}}
        {{--ga('require', 'linker');--}}

        {{--// Define which domains to autoLink.--}}
        {{--ga('linker:autoLink', ['fastspring.com','gumroad.com','gum.co','themeforest.net','mojomarketplace.com']);--}}
    {{--</script>--}}

    {{--<div class="paymant-google-iframe">--}}
        {{--<script type="text/javascript">--}}
            {{--/* <![CDATA[ */--}}
            {{--var google_conversion_id = 957922173;--}}
            {{--var google_custom_params = window.google_tag_params;--}}
            {{--var google_remarketing_only = true;--}}
            {{--/* ]]> */--}}
        {{--</script>--}}
        {{--<script type="text/javascript" src="../../../../www.googleadservices.com/pagead/f.txt">--}}
        {{--</script>--}}
        {{--<noscript>--}}
            {{--<div style="display:inline;">--}}
                {{--<img height="1" width="1" style="border-style:none;" alt="" src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/957922173/?value=0&amp;guid=ON&amp;script=0"/>--}}
            {{--</div>--}}
        {{--</noscript>--}}
    {{--</div>--}}

    {{--<script type="text/javascript" id='am-ctcs-v1'>--}}
        {{--(function () {--}}
            {{--var url = (("https:" == document.location.protocol) ?--}}
                    {{--"https://account.themefuse.com" : "https://account.themefuse.com");--}}
            {{--var d = document, s = d.createElement('script'), src = d.getElementsByTagName('script')[0];--}}
            {{--var w = window;--}}
            {{--var lo = w.location;--}}
            {{--var hr = lo.href;--}}
            {{--var ho = lo.host;--}}
            {{--var se = lo.search;--}}
            {{--var m = RegExp('[?&]r=([^&]*)').exec(se);--}}
            {{--var ref = m && decodeURIComponent(m[1].replace(/\+/g, ' '));--}}
            {{--s.type = 'text/javascript';--}}
            {{--s.async = true;--}}
            {{--s.src = url + '/aff/click-js/?r=' + ref + '&s=' + encodeURIComponent(document.referrer);--}}
            {{--if (ref) {--}}
                {{--src.parentNode.insertBefore(s, src);--}}
                {{--var uri = hr.toString().split(ho)[1];--}}
                {{--w.history.replaceState('Object', 'Title', uri.replace(m[0], ""));--}}
            {{--}--}}
        {{--})();--}}
    {{--</script>--}}

    {{--<script>--}}
        {{--window.intercomSettings = {--}}
            {{--app_id: "j11sgamw"--}}
        {{--};--}}
    {{--</script>--}}

    {{--<!-- Facebook Pixel Code -->--}}
    {{--<script>--}}
        {{--!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?--}}
                {{--n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;--}}
            {{--n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;--}}
            {{--t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,--}}
                {{--document,'script','../../../../connect.facebook.net/en_US/fbevents.js');--}}
        {{--fbq('init', '138632519954398');--}}
        {{--fbq('track', 'PageView');--}}
        {{--fbq('track', 'ViewContent', {--}}
            {{--value: 59,--}}
            {{--currency: 'USD'--}}
        {{--});--}}
    {{--</script>--}}
    {{--<noscript><img alt="" height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=138632519954398&amp;ev=PageView&amp;noscript=1"/></noscript>--}}
    {{--<!-- DO NOT MODIFY -->--}}
    {{--<!-- End Facebook Pixel Code -->--}}

    {{--<script>(function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',intercomSettings);}else{var d=document;var i=function(){i.c(arguments)};i.q=[];i.c=function(args){i.q.push(args)};w.Intercom=i;function l(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/j11sgamw';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);}if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})()</script>--}}
    {{--<script type='text/javascript'>--}}
        {{--/* <![CDATA[ */--}}
        {{--var wc_add_to_cart_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/pages\/gallery\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme","is_cart":"","cart_redirect_after_add":"no"};--}}
        {{--/* ]]> */--}}
    {{--</script>--}}
    <script type='text/javascript' src='{{asset('wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min32bb.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js')}}'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var woocommerce_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/pages\/gallery\/?wc-ajax=%%endpoint%%"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min32bb.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js')}}'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wc_cart_fragments_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/pages\/gallery\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min32bb.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/lib/modernizr.min4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/jquery.carouFredSel-6.2.1-packed4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/jquery.prettyPhoto4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/jquery.customInput4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/scrollTo.min4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/jquery.mmenu.min.all4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/selectize.min4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/jquery.parallax4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-includes/js/jquery/ui/effect.mine899.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/lazysizes.min4b68.js')}}'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var FwPhpVars = {"ajax_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","template_directory":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-content\/themes\/kids-play-parent","previous":"Previous","next":"Next","smartphone_animations":"no","header_5_position":"left","header_6_position":"left","effect_panels":"","effect_listitems_slide":"","fail_form_error":"Sorry you are an error in ajax, please contact the administrator of the website","socials":""};
        /* ]]> */
    </script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/general4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core66f2.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition66f2.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background66f2.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init66f2.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/isotope.pkgd.min4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/js/modulo-columns4b68.js')}}'></script>
    <script type='text/javascript' src='{{asset('wp-content/themes/kids-play-parent/framework-customizations/extensions/shortcodes/shortcodes/portfolio/static/js/portfolio-script4b68.js')}}'></script>
    {{--<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/libs/jquery-ui9811.js?ver=1.0.22'></script>--}}
    {{--<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/jquery.selectBoxIt9811.js?ver=1.0.22'></script>--}}
    {{--<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/jquery.nicescroll.min9811.js?ver=1.0.22'></script>--}}
    {{--<script type='text/javascript' src='../../../themefuse_ribbon_static/themefuse_ribon/js/general9811.js?ver=1.0.22'></script>--}}
    {{--<script type='text/javascript' src='../../../../use.typekit.net/dmy3vly9811.js?ver=1.0.22'></script>--}}
    <script type='text/javascript' src='{{asset('wp-includes/js/wp-embed.min66f2.js')}}'></script>
</body>

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/pages/gallery/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:53:26 GMT -->
</html>