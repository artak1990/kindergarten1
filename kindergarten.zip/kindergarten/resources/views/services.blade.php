@extends('layouts.servicesapp')

@section('content')
    <div id="page" class="hfeed site">
        @include('layouts.header')
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d1c2d6c1"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-63e2f434e417f32e866fca33a3d071ed header-animation-speed"
                         style="  background-image:url({{asset('wp-content/uploads/2016/07/page-background.jpg')}}); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-2d172d9318c24a51d826b52791797776"
                                 class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element"
                                 data-animation-type="fadeInUp" data-animation-delay="400">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:180px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"
                                         data-animation-type="bounceInDown" data-animation-delay="400">
                                        <h2 class="fw-special-title">@if(session('locale') == 'en'){{$services_category->name_en}}@elseif(session('locale') == 'ru'){{$services_category->name_ru}}@else{{$services_category->name_am}}@endif</h2>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:240px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ebeb92"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  fw-mobile-hide-element tf-sh-63e2c55f32cf8f8333d9731bd96e0fb3 "
                         style="  background-image:url({{asset('wp-content/uploads/2016/06/healthy-background.jpg')}}); background-repeat: no-repeat; background-position: center top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-dd4110937ca34c70203a283cfe3290d4"
                                 class="fw-col-sm-8 fw-col-md-6 tf-sh-dd4110937ca34c70203a283cfe3290d4">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="{{asset('wp-content/uploads/2016/07/mail-icon.png')}}" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                {{__('about.address')}} </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-d58472aa7c5dd66cf1c8faf42755eccb"
                                 class="fw-col-sm-4 fw-col-md-3 tf-sh-d58472aa7c5dd66cf1c8faf42755eccb">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-78e8669f6752f2fd02ef70707a9a8630  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="{{asset('wp-content/uploads/2016/07/call-icon.png')}}" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                +374 10 272272 </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-52ab08806e8670224e46a34b24da472f"
                                 class="fw-tablet-hide-element fw-col-sm-3 fw-tablet-landscape-hide-element tf-sh-52ab08806e8670224e46a34b24da472f">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-60db5ea8816ddda26c75e85b31c9e362  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="{{asset('wp-content/uploads/2016/07/around-icon.png')}}" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                {{__('about.email')}} </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                @foreach($services as $val)
                    @if($x%2 != 0)
                        <section id="{{$val->title_en}}"
                                 class=" fw-main-row-custom fw-section-no-padding fw-content-overlay-custom fw_theme_bg_fw-custom fw-section-image auto  tf-sh-d0073d6033be11a3a89872b885f85414 "
                                 style="  background-image:url({{asset('wp-content/uploads/2016/06/clock-background.png')}}); background-repeat: no-repeat; background-position: center top; background-size: auto; margin-bottom:-40px; ">
                            <div class="fw-container">
                                <div class="fw-row">

                                    <div id="column-e2756c36a681f1d487527e3c54397127"
                                         class="fw-col-sm-12 fw-mobile-hide-element tf-sh-e2756c36a681f1d487527e3c54397127">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:100px;"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="fw-row">
                                    <div id="column-4913e21794c318781dfcbdc122893e83"
                                         class="fw-col-sm-8 tf-sh-4913e21794c318781dfcbdc122893e83  fw-animated-element fw-col-no-padding"
                                         data-animation-type="fadeInLeft" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:10px;"></div>
                                            <div class="fw-heading fw-heading-left  tf-sh-8b50891d89f5b2a827167faad435c161">
                                                <h3 class="fw-special-title">@if(session('locale') == 'en'){{$val->title_en}}@elseif(session('locale') == 'ru'){{$val->title_ru}}@else{{$val->title_am}}@endif
                                                    @if($val->title_am && $val->title_ru && $val->title_en)
                                                        <img src="{{asset('wp-content/uploads/2016/06/arrow.png')}}">
                                                    @endif
                                                </h3>


                                            </div>
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:25px;"></div>
                                            <div class="fw-text-box tf-sh-0e39766cb8b7ecfcb94a851ba1d97683 ">
                                                <div class="fw-text-inner">
                                                    <p>@if(session('locale') == 'en'){{$val->description_en}}@elseif(session('locale') == 'ru'){{$val->description_ru}}@else{{$val->description_am}} @endif</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="column-6f9e00862602620bc77d9cb796f60971"
                                         class="fw-col-sm-4 tf-sh-6f9e00862602620bc77d9cb796f60971  fw-animated-element"
                                         data-animation-type="fadeInRight" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">


                                            <div class="fw-block-image-parent image-shadow fw-block-image-right"
                                                 style="width: 360px; border-style: solid; border-width: 12px; border-color: #ffffff;">
			<span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image">
                    <img src="{{asset('/img/serviceimage/'.$val->img_name)}}" alt="afterschool-img"
                         data-maxdpr="1.7" width="360" class="lazyload"/>
                    <meta itemprop="url"
                          content="{{asset('wp-content/uploads/2016/06/afterschool-img.jpg')}}"><meta
                            itemprop="width" content="360"><meta itemprop="height" content="270"></noscript>
                <img
                        src="{{asset('/img/serviceimage/'.$val->img_name)}}"
                        alt="afterschool-img" width="360" class="lazyload"/>
            </span>
                                            </div>


                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:10px;"></div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </section>
                        @if($x != $count)
                            <section id="section-59268d1c38680"
                                     class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-9ca01a766c042023d7f9a97ea87ca096 "
                                     style="   ">
                                <div class="fw-container">
                                    <div class="fw-row">
                                        <div id="column-6e2f9e569f003377dbb520ec9f4472c4"
                                             class="fw-col-sm-6 fw-col-md-8 fw-mobile-hide-element tf-sh-6e2f9e569f003377dbb520ec9f4472c4">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                            </div>
                                        </div>
                                        <div id="column-0328ab2681847568d7ead35b2ef52f10"
                                             class="fw-col-sm-6 fw-col-md-4 tf-sh-0328ab2681847568d7ead35b2ef52f10  fw-animated-element"
                                             data-animation-type="bounceInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="text-center">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="fw-row">
                                        <div id="column-0eae44a465347ef8489a90e66f767f17"
                                             class="fw-col-sm-12 tf-sh-0eae44a465347ef8489a90e66f767f17  fw-animated-element"
                                             data-animation-type="fadeInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                                     style="height:60px;"></div>

                                                <div class="fw-block-image-parent  fw-block-image-center"
                                                     style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                            src="{{asset('wp-content/uploads/2016/06/separator.png')}}" alt="separator"
                            data-maxdpr="1.7" width="800" class="lazyload"/><meta itemprop="url"
                                                                                  content="{{asset('wp-content/uploads/2016/06/separator.png')}}"><meta
                            itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img
                        src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-sizes="auto"
                        data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"
                        alt="separator" data-maxdpr="1.7" width="800" class="lazyload"/>
                <span class="fw-after-no-ratio"
                      style="padding-bottom: 3%"></span>
            </span>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </section>
                        @endif
                    @else
                        <section id="{{$val->title_en}}"
                                 class=" fw-main-row-custom fw-section-no-padding fw-content-overlay-custom auto  tf-sh-14c3141fd7f353254ff053895f2fdd4a "
                                 style="  margin-bottom:-40px; ">
                            <div class="fw-container">
                                <div class="fw-row">

                                    <div id="column-6c9ce23aefe49c4df2cd8ac6384b59b6"
                                         class="fw-col-sm-4 tf-sh-6c9ce23aefe49c4df2cd8ac6384b59b6  fw-animated-element"
                                         data-animation-type="fadeInLeft" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:90px;"></div>

                                            <div class="fw-block-image-parent image-shadow fw-block-image-left"
                                                 style="width: 360px; border-style: solid; border-width: 12px; border-color: #ffffff;">
			<span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image">
                    <img
                            src="{{asset('/img/serviceimage/'.$val->img_name)}}" alt="kindergarten-img"
                            data-maxdpr="1.7" width="360" class="lazyload"/>
                    <meta itemprop="url"
                          content="{{asset('wp-content/uploads/2016/06/kindergarten-img.jpg')}}"><meta
                            itemprop="width" content="360"><meta itemprop="height" content="270"></noscript>
                <img
                        src="{{asset('/img/serviceimage/'.$val->img_name)}}"
                        data-sizes="auto"
                        data-srcset=""
                        alt="kindergarten-img" data-maxdpr="1.7" width="360" class="lazyload"/>
            </span>
                                            </div>


                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:10px;"></div>
                                        </div>
                                    </div>
                                    <div id="column-5f1e16bb35311bbe36c77a451d3448ab"
                                         class="fw-col-sm-8 tf-sh-5f1e16bb35311bbe36c77a451d3448ab  fw-animated-element fw-col-no-padding"
                                         data-animation-type="fadeInRight" data-animation-delay="300">
                                        <div class="fw-main-row-overlay"></div>
                                        <div class="fw-col-inner">
                                            <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                                 style="height:70px;"></div>
                                            <div class="fw-heading fw-heading-left  tf-sh-94c3cf3bee3c034f051b0740bf17b8f9">
                                                <h3 class="fw-special-title">@if(session('locale') == 'en'){{$val->title_en}}@elseif(session('locale') == 'ru'){{$val->title_ru}}@else{{$val->title_am}}@endif @if($val->title_am && $val->title_ru && $val->title_en)
                                                        <img src="{{asset('wp-content/uploads/2016/06/arrow.png')}}">
                                                    @endif
                                                </h3>


                                            </div>
                                            <div class="fw-divider-space  fw-custom-space  clearfix"
                                                 style="height:25px;"></div>
                                            <div class="fw-text-box tf-sh-a83ef73ad2c4838c1ab539c8245b4aac ">
                                                <div class="fw-text-inner">
                                                    <p>@if(session('locale') == 'en'){{$val->description_en}}@elseif(session('locale') == 'ru'){{$val->description_ru}}@else{{$val->description_am}} @endif </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </section>
                        @if($x != $count)
                            <section id="section-59268d1c3d4a2"
                                     class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-95a68af7291429b4a4a265a43c3cc006 "
                                     style="   ">
                                <div class="fw-container">
                                    <div class="fw-row">
                                        <div id="column-22b8b344984b5522f029bed9ff0592a7"
                                             class="fw-col-sm-6 fw-col-md-4 tf-sh-22b8b344984b5522f029bed9ff0592a7  fw-animated-element"
                                             data-animation-type="bounceInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="text-center">
                                                </div>
                                            </div>
                                        </div>
                                        <div id="column-e97bc0b6fdb195cd94406c374d36bd7c"
                                             class="fw-col-sm-6 fw-col-md-8 fw-mobile-hide-element tf-sh-e97bc0b6fdb195cd94406c374d36bd7c">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="fw-row">
                                        <div id="column-47d6be7bad68946de5ed6a3a0273d066"
                                             class="fw-col-sm-12 tf-sh-47d6be7bad68946de5ed6a3a0273d066  fw-animated-element"
                                             data-animation-type="fadeInUp" data-animation-delay="300">
                                            <div class="fw-main-row-overlay"></div>
                                            <div class="fw-col-inner">
                                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                                     style="height:60px;"></div>

                                                <div class="fw-block-image-parent  fw-block-image-center"
                                                     style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                            src="{{asset('wp-content/uploads/2016/06/separator.png')}}" alt="separator"
                            data-maxdpr="1.7" width="800" class="lazyload"/><meta itemprop="url"
                                                                                  content="{{asset('wp-content/uploads/2016/06/separator.png')}}"><meta
                            itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img
                        src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-sizes="auto"
                        data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"
                        alt="separator" data-maxdpr="1.7" width="800" class="lazyload"/><span class="fw-after-no-ratio"
                                                                                              style="padding-bottom: 3%"></span>							</span>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </section>
                        @endif
                    @endif
                    @php($x++)
                @endforeach
                <section id="section-59268d1c49c15"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-12472276d0a5edefd315a4dbe0caddac "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-69747ed839123cb03effce5fcf7dbf6d"
                                 class="fw-col-sm-6 fw-col-md-4 tf-sh-69747ed839123cb03effce5fcf7dbf6d  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="text-center">
                                    </div>
                                </div>
                            </div>
                            <div id="column-c663beca6ecf1234868f7137ab57b854"
                                 class="fw-col-sm-6 fw-col-md-8 fw-mobile-hide-element tf-sh-c663beca6ecf1234868f7137ab57b854">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-472779d98d8ea24562ed95a6e870a3da"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-472779d98d8ea24562ed95a6e870a3da">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:140px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                {{--<img src="{{asset('wp-content/uploads/2016/06/healthy-background.jpg')}}" alt="" width="100%">--}}
                <section id="section-59268d1c4d579"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom fw-content-vertical-align-middle tf-sh-f304bad86b4d537e5da805a8c4bbadea "
                         style="  background-image:url({{asset('wp-content/uploads/2016/06/team-background.jpg')}}); background-repeat: no-repeat; background-position: left top; background-size: auto;  height: 280px;">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-efbdbe37c0b7b90af8ede6bcf5e57023"
                                 class="fw-col-sm-9 tf-sh-efbdbe37c0b7b90af8ede6bcf5e57023  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-heading fw-heading-left  fw-heading-with-subtitle tf-sh-826086d450887f165de1eec3f9819135">
                                        <h3 class="fw-special-title">{{__('services.smart')}}</h3>


                                        <div class="fw-special-subtitle">{{__('services.can')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div id="column-639a9c802864c3232d2545961e80ef30"
                                 class="fw-col-sm-3 tf-sh-639a9c802864c3232d2545961e80ef30  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="500">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="text-right"><a href="/about" target="_self"
                                                               class="fw-btn tf-sh-05ca927d3e1ff7faf5172da26129f61d    button-with-bg fw-btn-4"
                                                               style="width:178px; height:71px; line-height:71px;">
		<span style="top:0;">
			{{__('services.read')}}		</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>


        </div><!-- /.site-main -->

        <!-- Footer -->
        @include('layouts.footer')
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#page"><img
                src="{{asset('wp-content/uploads/2016/07/to-top.png')}}" alt="to top button"/></a>
@endsection
