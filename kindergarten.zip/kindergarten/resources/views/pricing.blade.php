@extends("layouts.pricingapp")

@section('content')
<div id="page" class="hfeed site">
    @include('layouts.header')
    		<div id="main" class="site-main">
        <div class="fw-page-builder-content"><section  id="section-59268d1e78b44" class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-b7a55819bd5e15f211650ae2821852e2 header-animation-speed"  style="  background-image:url(../../wp-content/uploads/2016/07/page-background.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;"  >
                <div class="fw-container-fluid" >
                    <div class="fw-row">
                        <div id="column-2d172d9318c24a51d826b52791797776" class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element" data-animation-type="fadeInUp" data-animation-delay="400">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:180px;" ></div><div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"  data-animation-type="bounceInDown" data-animation-delay="400">
                                    <h2 class="fw-special-title">Pricing</h2>


                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:240px;" ></div>	</div>
                        </div></div>

                </div>
            </section>
            <section  id="section-59268d1e798c4" class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  fw-mobile-hide-element tf-sh-6dd5a1fb0bc61978f95834b8647928bb "  style="  background-image:url(../../wp-content/uploads/2016/06/healthy-background.jpg); background-repeat: no-repeat; background-position: center top; background-size: auto;  "  >
                <div class="fw-container" >
                    <div class="fw-row">
                        <div id="column-dd4110937ca34c70203a283cfe3290d4" class="fw-col-sm-8 fw-col-md-6 tf-sh-dd4110937ca34c70203a283cfe3290d4" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;" ></div><div class="fw-icon-title fw-icon-title-left clearfix tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40  fw-content-align-center" >
                                    <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="" href="../../index1df3.html?page_id=13" target="_self">
							<img src="../../wp-content/uploads/2016/07/mail-icon.png" alt="" />						</a>
									</span>

                                        <h6 class="fw-icon-title-text">
                                            <a class="" href="../../index1df3.html?page_id=13" target="_self">1ST Street, New York, 041569 NY</a>
                                        </h6>
                                    </div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;" ></div>	</div>
                        </div><div id="column-d58472aa7c5dd66cf1c8faf42755eccb" class="fw-col-sm-4 fw-col-md-3 tf-sh-d58472aa7c5dd66cf1c8faf42755eccb" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;" ></div><div class="fw-icon-title fw-icon-title-left clearfix tf-sh-78e8669f6752f2fd02ef70707a9a8630  fw-content-align-center" >
                                    <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="" href="../../index1df3.html?page_id=13" target="_self">
							<img src="../../wp-content/uploads/2016/07/call-icon.png" alt="" />						</a>
									</span>

                                        <h6 class="fw-icon-title-text">
                                            <a class="" href="../../index1df3.html?page_id=13" target="_self">047 339 205</a>
                                        </h6>
                                    </div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;" ></div>	</div>
                        </div><div id="column-52ab08806e8670224e46a34b24da472f" class="fw-tablet-hide-element fw-col-sm-3 fw-tablet-landscape-hide-element tf-sh-52ab08806e8670224e46a34b24da472f" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;" ></div><div class="fw-icon-title fw-icon-title-left clearfix tf-sh-60db5ea8816ddda26c75e85b31c9e362  fw-content-align-center" >
                                    <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="" href="../../index1df3.html?page_id=13" target="_self">
							<img src="../../wp-content/uploads/2016/07/around-icon.png" alt="" />						</a>
									</span>

                                        <h6 class="fw-icon-title-text">
                                            <a class="" href="../../index1df3.html?page_id=13" target="_self">hello@play.com</a>
                                        </h6>
                                    </div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;" ></div>	</div>
                        </div></div>

                </div>
            </section>
            <section  id="section-59268d1e7b5cc" class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  tf-sh-44b6af090578f504f72d1da58509ce82 "  style="  background-image:url(../../wp-content/uploads/2016/07/purse-background.png); background-repeat: no-repeat; background-position: center top; background-size: auto;  "  >
                <div class="fw-container" >
                    <div class="fw-row">
                        <div id="column-e2756c36a681f1d487527e3c54397127" class="fw-col-sm-12 fw-mobile-hide-element tf-sh-e2756c36a681f1d487527e3c54397127" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:100px;" ></div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-4913e21794c318781dfcbdc122893e83" class="fw-col-sm-6 tf-sh-4913e21794c318781dfcbdc122893e83  fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:10px;" ></div><div class="fw-heading fw-heading-left  tf-sh-8b50891d89f5b2a827167faad435c161" >
                                    <h3 class="fw-special-title">Prices for Every Pocket<img src="../../wp-content/uploads/2016/06/arrow.png"></h3>


                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:25px;" ></div><div class="fw-text-box tf-sh-0e39766cb8b7ecfcb94a851ba1d97683 " >
                                    <div class="fw-text-inner">
                                        <p>Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibe ndum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus. Mauris iaculis porttitor posuere. Praesent id.</p>
                                    </div>
                                </div>	</div>
                        </div><div id="column-c951cd3b7f19082b1e56848cac97c3dc" class="fw-col-sm-6 tf-sh-c951cd3b7f19082b1e56848cac97c3dc  fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="500">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:28px;" ></div><div class="text-right">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-82e7d97c08f503a997c0ad82cb159425    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Get A Quote		</span>
                                    </a>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:50px;" ></div><div class="fw-text-box tf-sh-c2185ec7b1ae626322a09e8a6a0f5ed5 " >
                                    <div class="fw-text-inner">
                                        <p>Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta. Sed nec diam eu diam mattis viverra. Nulla fringilla, orci ac euismod semper, magna diam porttitor mauris, quis sollicitudin sapien justo in libero. Vestibulum mollis mauris enim. Morbi euismod.</p>
                                    </div>
                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-1afbd7005c5eb0e373926e5a4659343b" class="fw-col-sm-12 fw-mobile-hide-element tf-sh-1afbd7005c5eb0e373926e5a4659343b remove-on-mobile" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:100px;" ></div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-ea63151805057ca8160dd5eb3f5829e4" class="fw-col-sm-12 fw-col-md-4 tf-sh-ea63151805057ca8160dd5eb3f5829e4 remove-on-mobile fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-heading fw-heading-left  fw-heading-with-subtitle tf-sh-18a6dc26c80d6e32eff80cf39ac476c4" >
                                    <h2 class="fw-special-title">159<sup style="font-size:40px;">$</sup><span style="font-family:'Amatic SC'; font-size:35px; font-weight:700; letter-spacing: -0.5px;"> / MONTH</span><img style="position:absolute; top:15px; left: 225px;" src="../../wp-content/uploads/2016/06/arrow.png"></h2>


                                    <div class="fw-special-subtitle">Afterschool Pack</div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;" ></div><div class="fw-text-box tf-sh-c0f8ec740060c0ef80623d21e5c589fe " >
                                    <div class="fw-text-inner">
                                        <p>Access to entire collection <img style="float:right;" src="../../wp-content/uploads/2016/06/list-item-check.png"></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-624025f0852e602d10f9f9649ce38532  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-79682a1987ff9b74d8d8181fc012017c " >
                                    <div class="fw-text-inner">
                                        <p>Access to new releases <img style="float: right;" src="../../wp-content/uploads/2016/06/list-item-check.png" /></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-4096cd39a810cd56bad669b5893e1e84  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-83a7eed67351086a4aff830d895d3f28 " >
                                    <div class="fw-text-inner">
                                        <p>Support & Updates <img style="float: right;" src="../../wp-content/uploads/2016/07/list-item-negative.png" /></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-3637013c398a8ccab96bc72a8a22ab52  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-da85a0085a1dddeed430c2fde9d19a47 " >
                                    <div class="fw-text-inner">
                                        <p>HTML version included <img style="float: right;" src="../../wp-content/uploads/2016/07/list-item-negative.png" /></p>
                                    </div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:65px;" ></div><div class="text-center">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-8783645e862262faec8cd78b2d73ae1c    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Get A Quote		</span>
                                    </a>
                                </div>	</div>
                        </div><div id="column-4a607993179ed09c89f2138a96553b89" class="fw-col-sm-12 fw-col-md-4 tf-sh-4a607993179ed09c89f2138a96553b89 remove-on-mobile fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="500">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-heading fw-heading-left  fw-heading-with-subtitle tf-sh-abe9766afe9f9ab5d514aa6d9455f661" >
                                    <h2 class="fw-special-title">270<sup style="font-size:40px;">$</sup><span style="font-family:'Amatic SC'; font-size:35px; font-weight:700; letter-spacing: -0.5px;"> / MONTH</span><img style="position:absolute; top:15px; left: 225px;" src="../../wp-content/uploads/2016/06/arrow.png"></h2>


                                    <div class="fw-special-subtitle">Toddlers Pack</div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;" ></div><div class="fw-text-box tf-sh-d0307123f7aa9e2ac94b26b60d156e64 " >
                                    <div class="fw-text-inner">
                                        <p>Access to entire collection <img style="float:right;" src="../../wp-content/uploads/2016/06/list-item-check.png"></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-e5eada2a168a927b374a3603b2162de2  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-732b72a3fa7874f72d9d8f6a0155308b " >
                                    <div class="fw-text-inner">
                                        <p>Access to new releases <img style="float: right;" src="../../wp-content/uploads/2016/06/list-item-check.png" /></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-86a25cca257c42bf73069ef857559959  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-4d2633f756514db1fe51176b97d6d85c " >
                                    <div class="fw-text-inner">
                                        <p>Support &amp; Updates <img style="float: right;" src="../../wp-content/uploads/2016/06/list-item-check.png" /></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-44357d6a566837d640b8e375ab3acc2e  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-9803b7f7306ba62d9435fd5c3d626f59 " >
                                    <div class="fw-text-inner">
                                        <p>HTML version included <img style="float: right;" src="../../wp-content/uploads/2016/07/list-item-negative.png" /></p>
                                    </div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:65px;" ></div><div class="text-center">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-483f9b7091275cbd6afaf561cf925c05    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Get A Quote		</span>
                                    </a>
                                </div>	</div>
                        </div><div id="column-5223f09e727b77024e8810dded61382e" class="fw-col-sm-12 fw-col-md-4 tf-sh-5223f09e727b77024e8810dded61382e remove-on-mobile fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="700">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-heading fw-heading-left  fw-heading-with-subtitle tf-sh-fc3fcf37989d06e7dc5aa52db3313a8f" >
                                    <h2 class="fw-special-title">369<sup style="font-size:40px;">$</sup><span style="font-family:'Amatic SC'; font-size:35px; font-weight:700; letter-spacing: -0.5px;"> / MONTH</span><img style="position:absolute; top:15px; left: 225px;" src="../../wp-content/uploads/2016/06/arrow.png"></h2>


                                    <div class="fw-special-subtitle">Parties Pack</div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;" ></div><div class="fw-text-box tf-sh-270826f1fd8f559d9560461701883cc2 " >
                                    <div class="fw-text-inner">
                                        <p>Access to entire collection <img style="float:right;" src="../../wp-content/uploads/2016/06/list-item-check.png"></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-7f548dcc1f5e5135ec144a97638c5f05  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-068d69aa890f91d89fc771d68bda489e " >
                                    <div class="fw-text-inner">
                                        <p>Access to new releases <img style="float: right;" src="../../wp-content/uploads/2016/06/list-item-check.png" /></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-651e2515b632786a8f4786106ba8aa48  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-420b03ba3030a31500fa803da1c30f92 " >
                                    <div class="fw-text-inner">
                                        <p>Support &amp; Updates <img style="float: right;" src="../../wp-content/uploads/2016/06/list-item-check.png" /></p>
                                    </div>
                                </div>	<div  class="fw-divider tf-sh-13cbfdd1d59449cb3f5c45ab2ab2715c  fw-divider-align-center fw-divider-full-width fw-line-solid fw-divider-line  "  style="width: auto; padding-top:20px; margin-bottom:17px; border-color:#e9ded6;" ></div>
                                <div class="fw-text-box tf-sh-a0556650e88b4364fa2c66d21cdaab35 " >
                                    <div class="fw-text-inner">
                                        <p>HTML version included <img style="float: right;" src="../../wp-content/uploads/2016/06/list-item-check.png" /></p>
                                    </div>
                                </div><div class="fw-divider-space  fw-custom-space  clearfix" style="height:65px;" ></div><div class="text-center">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-9e8adafb2820628c14f4e57f6331d6e9    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Get A Quote		</span>
                                    </a>
                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-b557d7f5f23fcefa43d3bba1896bd643" class="fw-col-sm-12 fw-mobile-hide-element tf-sh-b557d7f5f23fcefa43d3bba1896bd643" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:120px;" ></div>	</div>
                        </div></div>

                </div>
            </section><section  id="section-59268d1e82132" class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-2ffb6ad4c015f6d9e8355599403974c1 "  style="   "  >
                <div class="fw-container" >
                    <div class="fw-row">
                        <div id="column-1467bfe085c8aa203df325a8bdb51775" class="fw-col-sm-12 tf-sh-1467bfe085c8aa203df325a8bdb51775  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-heading fw-heading-left  tf-sh-ee9bffb084b942147dd1bc253beaba9e" >
                                    <h4 class="fw-special-title">Q: What we do and why we do it?   <img src="../../wp-content/uploads/2016/06/arrow.png"></h4>


                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-73b314656828e205e649fd12a3f65aec" class="fw-col-sm-8 tf-sh-73b314656828e205e649fd12a3f65aec  fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-text-box tf-sh-7d8d3365541812f635430e22ee735893 " >
                                    <div class="fw-text-inner">
                                        <p>Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus. Mauris iaculis porttitor posuere. Praesent id metus massa, ut blandit odio roin quis tortor orci.</p>
                                    </div>
                                </div>	</div>
                        </div><div id="column-8da2bb1c94cfcfc4ce0b00db63385e5e" class="fw-col-sm-4 tf-sh-8da2bb1c94cfcfc4ce0b00db63385e5e  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="500">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="text-center">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-e9727d1d0033d6b09783e125ce3c0cee    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Contact Us		</span>
                                    </a>
                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-0eae44a465347ef8489a90e66f767f17" class="fw-col-sm-12 tf-sh-0eae44a465347ef8489a90e66f767f17" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix" style="height:60px;" ></div>

                                <div class="fw-block-image-parent  fw-animated-element fw-block-image-center"  data-animation-type="bounceInUp" data-animation-delay="300" style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img src="../../wp-content/uploads/2016/06/separator.png"  alt="separator" data-maxdpr="1.7" width="800" class="lazyload" /><meta itemprop="url" content="../../wp-content/uploads/2016/06/separator.png"><meta itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-sizes="auto" data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"   alt="separator" data-maxdpr="1.7" width="800" class="lazyload" /><span class="fw-after-no-ratio" style="padding-bottom: 3%"></span>							</span>
                                </div>


                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix" style="height:60px;" ></div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-9bfbf831f1024e873c559a0319a1210e" class="fw-col-sm-12 tf-sh-9bfbf831f1024e873c559a0319a1210e  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-heading fw-heading-left  tf-sh-7850c44d07f5790feadbcd8234527ca9" >
                                    <h4 class="fw-special-title">Q: Phasellus Molestie Magna Non Est Non?    <img src="../../wp-content/uploads/2016/06/arrow.png"></h4>


                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-02e848aa7d9c9644575fac9a633c844f" class="fw-col-sm-8 tf-sh-02e848aa7d9c9644575fac9a633c844f  fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-text-box tf-sh-0e2beea0105ca7fc907c5a2ce57e8726 " >
                                    <div class="fw-text-inner">
                                        <p>Etiam at risus et justo dignissim congue. Donec congue lacinia dui, a porttitor lectus condimentum laoreet. Nunc eu ullamcorper orci. Quisque eget odio ac lectus vestibulum faucibus eget in metus. In pellentesque faucibus vestibulum. Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus in blandit. Curabitur vulputate.</p>
                                    </div>
                                </div>	</div>
                        </div><div id="column-df6ef081014e8fbec8863d35a6c5c506" class="fw-col-sm-4 tf-sh-df6ef081014e8fbec8863d35a6c5c506  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="500">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="text-center">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-da943cb8a69d9b6abf923b86bca55b66    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Contact Us		</span>
                                    </a>
                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-5120521b0c911fdf946b1ab54919780b" class="fw-col-sm-12 tf-sh-5120521b0c911fdf946b1ab54919780b  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix" style="height:60px;" ></div>

                                <div class="fw-block-image-parent  fw-block-image-center"  style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img src="../../wp-content/uploads/2016/06/separator.png"  alt="separator" data-maxdpr="1.7" width="800" class="lazyload" /><meta itemprop="url" content="../../wp-content/uploads/2016/06/separator.png"><meta itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-sizes="auto" data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"   alt="separator" data-maxdpr="1.7" width="800" class="lazyload" /><span class="fw-after-no-ratio" style="padding-bottom: 3%"></span>							</span>
                                </div>


                                <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix" style="height:60px;" ></div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-027f4dac64c2d3c40d63987bd28f4d58" class="fw-col-sm-12 tf-sh-027f4dac64c2d3c40d63987bd28f4d58  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-heading fw-heading-left  tf-sh-ba7236b36612514d84b3ef71d7003cec" >
                                    <h4 class="fw-special-title">Q: Nullam In Dui Mauris. Vivamus?     <img src="../../wp-content/uploads/2016/06/arrow.png"></h4>


                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-a7d37a5081a00fa881aedc84b2506a71" class="fw-col-sm-8 tf-sh-a7d37a5081a00fa881aedc84b2506a71  fw-animated-element fw-col-no-padding" data-animation-type="bounceInUp" data-animation-delay="300">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-text-box tf-sh-286726d4019bb257c622af1c109c2f71 " >
                                    <div class="fw-text-inner">
                                        <p>Etiam at risus et justo dignissim congue. Donec congue lacinia dui, a porttitor lectus condimentum laoreet. Nunc eu ullamcorper orci. Quisque eget odio ac lectus vestibulum faucibus eget in metus. In pellentesque faucibus vestibulum. Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus in blandit. Curabitur vulputate.</p>
                                    </div>
                                </div>	</div>
                        </div><div id="column-702f0d97c46acc984ea7edc13280aaf3" class="fw-col-sm-4 tf-sh-702f0d97c46acc984ea7edc13280aaf3  fw-animated-element" data-animation-type="bounceInUp" data-animation-delay="500">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="text-center">	<a href="../../index1df3.html?page_id=13" target="_self" class="fw-btn tf-sh-00c8779a3b7681a223b3d7bde6fa8fb6    button-with-bg fw-btn-4"  style="width:135px; height:53px; line-height:53px;">
		<span style="top:0;">
			Contact Us		</span>
                                    </a>
                                </div>	</div>
                        </div></div>

                    <div class="fw-row">
                        <div id="column-374748a921bc8188da39edf67782379b" class="fw-col-sm-12 fw-mobile-hide-element tf-sh-374748a921bc8188da39edf67782379b" >
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                                <div class="fw-divider-space  fw-custom-space  clearfix" style="height:140px;" ></div>	</div>
                        </div></div>

                </div>
            </section><section  id="section-59268d1e87318" class=" fw-main-row-custom fw-section-no-padding  auto  fw-mobile-hide-element tf-sh-1fb6439f54759ba407d35bbb709a73d9 "  style="   "  >
                <div class="fw-container-fluid" >
                    <div class="fw-row">
                        <div id="column-8fdc7b5ec21e901c4c0dd0778c64d093" class="fw-col-sm-12 tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093  fw-column-height-custom" style="height: 5px;">
                            <div class="fw-main-row-overlay"></div>
                            <div class="fw-col-inner">
                            </div>
                        </div></div>

                </div>
            </section></div>


    </div><!-- /.site-main -->

    <!-- Footer -->
    @include('layouts.footer')
</div><!-- /#page -->
<a class="scroll-to-top anchor upload-icon" href="#page"><img src="../../wp-content/uploads/2016/07/to-top.png" alt="to top button" /></a>
    @endsection
