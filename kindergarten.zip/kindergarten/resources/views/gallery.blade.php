@extends('layouts.galleryapp')

@section('content')
    <div id="page" class="hfeed site">
        @include('layouts.header')
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d1d92db4"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-913f07399ee5493036a7e6da7a960af9 header-animation-speed"
                         style="  background-image:url({{asset('wp-content/uploads/2016/07/page-background.jpg')}}); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-2d172d9318c24a51d826b52791797776"
                                 class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element"
                                 data-animation-type="fadeInUp" data-animation-delay="400">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:180px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"
                                         data-animation-type="bounceInDown" data-animation-delay="400">
                                        <h2 class="fw-special-title">{{__('gallery.gallery')}}</h2>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:240px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1d94431"
                         class=" fw-main-row-custom fw-section-no-padding fw-content-overlay-custom fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-fc6af57adb99b2eefdf30c23f1436531 filter-bg"
                         style="  background-image:url({{asset('wp-content/uploads/2016/06/healthy-background.jpg')}}); background-repeat: no-repeat; background-position: center top; background-size: auto; margin-bottom:-120px; height: 160px;">
                    <div class="fw-container">
                    </div>
                </section>
                <section id="section-59268d1d961d6"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-0dd7a2a43da99da19f6405ed3c37836e "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-81ac8383a95ad859213f7856e174e038"
                                 class="fw-col-sm-12 tf-sh-81ac8383a95ad859213f7856e174e038 portfolio">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-col-inner">
                                        <div class="tf-sh-7f923af5b4c7841305d2129e26f4357b fw-portfolio fw-portfolio-1 fw-portfolio-cols-3 fw-portfolio-content-position-middle fw-portfolio-content-align-center  fw-portfolio-landscape">
                                            <div class="fw-portfolio-filter">
                                                <ul id="fw-portfolio-filter-59268d1d9954d" class="portfolio_filter"
                                                    data-isotope="1" data-list-id="fw-portfolio-list-59268d1d9954d">
                                                    <li class="categories-item active" data-category="kindergarten"><a
                                                                href="#">{{__('gallery.kindergarten')}}</a></li>
                                                    @foreach($category as $val )
                                                        <li class="categories-item" data-category="{{$val->name_en}}"><a href="#">@if(session('locale')=="en"){{$val->name_en}}@elseif(session('locale')=="ru"){{$val->name_ru}}@else{{$val->name_ru}}@endif</a>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                                <a class="prev" id="fw-portfolio-filter-59268d1d9954d-prev" href="#"><i
                                                            class="fa"></i></a>
                                                <a class="next" id="fw-portfolio-filter-59268d1d9954d-next" href="#"><i
                                                            class="fa"></i></a>
                                            </div>
                                            <div class="row fw-portfolio-wrapper">
                                                <ul id="fw-portfolio-list-59268d1d9954d"
                                                    class="fw-portfolio-list clearfix" data-columns-number="3">
                                                    @foreach($gallary as $val)
                                                    <li data-category="kindergarten, {{$val->categores->first()['name_en']}} ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="#">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-12.jpg")}}"
                                                                            alt="portfolio-img-12" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-12.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="{{asset("img/gallaryimage/".$val->img_name)}}"
                                                                     data-sizes="auto"
                                                                     data-srcset="{{asset("img/gallaryimage/".$val->img_name)}}"
                                                                     alt="portfolio-img-12" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                @if(session('locale')=='en'){{$val->name_en}}@elseif(session('locale')=='ru'){{$val->name_ru}}@else{{$val->name_am}}@endif
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>@if(session('locale')=='en'){!! $val->description_en !!}@elseif(session('locale')=='ru'){!! $val->description_ru !!}@else{!! $val->description_am !!}@endif</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    @endforeach
                                                    <li data-category="activities, kindergarten, play-rooms, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/creative-activities/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-11.jpg")}}"
                                                                            alt="portfolio-img-11" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-11.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-11-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-11-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-11.jpg 358w"
                                                                     alt="portfolio-img-11" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Creative Activities
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="facilities, kindergarten, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/healthy-nutrients/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-10.jpg")}}"
                                                                            alt="portfolio-img-10" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-10.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-10-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-10-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-10.jpg 358w"
                                                                     alt="portfolio-img-10" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Healthy Nutrients
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="facilities, kindergarten, locations, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/new-chicago-location/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-9.jpg")}}"
                                                                            alt="portfolio-img-9" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-9.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-9-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-9-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-9.jpg 358w"
                                                                     alt="portfolio-img-9" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                New Chicago Location
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="activities, kindergarten, locations, play-rooms, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/parents-day/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-8.jpg")}}"
                                                                            alt="portfolio-img-8" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-8.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-8-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-8-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-8.jpg 358w"
                                                                     alt="portfolio-img-8" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Parents Day
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="facilities, kindergarten, play-rooms, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/toddler-care/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-7.jpg")}}"
                                                                            alt="portfolio-img-7" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-7.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-7-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-7-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-7.jpg 358w"
                                                                     alt="portfolio-img-7" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Toddler Care
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="facilities, kindergarten, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/healthy-food/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-6.jpg")}}"
                                                                            alt="portfolio-img-6" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-6.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-6-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-6-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-6.jpg 358w"
                                                                     alt="portfolio-img-6" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Healthy Food
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="activities, kindergarten, locations, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/outdoor-activities/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-5.jpg")}}"
                                                                            alt="portfolio-img-5" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-5.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-5-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-5-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-5.jpg 358w"
                                                                     alt="portfolio-img-5" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Outdoor Activities
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="kindergarten, play-rooms, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/fun-friday/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-4.jp")}}g"
                                                                            alt="portfolio-img-4" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-4.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-4-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-4-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-4.jpg 358w"
                                                                     alt="portfolio-img-4" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Fun Friday
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="facilities, kindergarten, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/safe-environment/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-3.jpg")}}"
                                                                            alt="portfolio-img-3" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-3.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-3-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-3-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-3.jpg 358w"
                                                                     alt="portfolio-img-3" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Safe Environment
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="activities, kindergarten, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/daily-activities/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-2.jpg")}}"
                                                                            alt="portfolio-img-2" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-2.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-2-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-2-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-2.jpg 358w"
                                                                     alt="portfolio-img-2" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Daily Activities
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Impsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                    <li data-category="activities, kindergarten, locations, ">
                                                        <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">
                                                            <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                               href="../../project/test/index.html">
                                                                <noscript itemscope
                                                                          itemtype="http://schema.org/ImageObject"
                                                                          itemprop="image"><img
                                                                            src="{{asset("wp-content/uploads/2016/06/portfolio-img-1.jpg")}}"
                                                                            alt="portfolio-img-1" data-maxdpr="1.7"
                                                                            class="attachment-post-thumbnail lazyload"/>
                                                                    <meta itemprop="url"
                                                                          content="{{asset("wp-content/uploads/2016/06/portfolio-img-1.jpg")}}">
                                                                    <meta itemprop="width" content="358">
                                                                    <meta itemprop="height" content="201">
                                                                </noscript>
                                                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                     data-sizes="auto"
                                                                     data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-1-300x168.jpg 300w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-1-295x166.jpg 295w, https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/portfolio-img-1.jpg 358w"
                                                                     alt="portfolio-img-1" data-maxdpr="1.7"
                                                                     class="attachment-post-thumbnail lazyload"/>
                                                                <div class="fw-block-image-overlay">
                                                                    <div class="fw-itable">
                                                                        <div class="fw-icell">
                                                                            <div class="fw-overlay-title">
                                                                                Toddling Around
                                                                            </div>
                                                                            <div class="fw-overlay-description">
                                                                                <p>Lorem Ipsum Sit</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- /.fw-portfolio -->
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1db6627"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-190ab61181daf7838041d78d2a2a516a "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-e2196addbd6e0deecf4cf0271b021127"
                                 class="fw-col-sm-12 tf-sh-e2196addbd6e0deecf4cf0271b021127">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:100px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1db98f1"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  tf-sh-6c25df1596a68a41a889f6b6f1f0379a "
                         style="  background-image:url({{asset('wp-content/uploads/2016/06/team-background.jpg')}}); background-repeat: no-repeat; background-position: left top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-efbdbe37c0b7b90af8ede6bcf5e57023"
                                 class="fw-col-sm-12 tf-sh-efbdbe37c0b7b90af8ede6bcf5e57023">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:75px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-heading-with-subtitle fw-animated-element tf-sh-826086d450887f165de1eec3f9819135"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h3 class="fw-special-title">{{__('gallery.smart')}}</h3>


                                        <div class="fw-special-subtitle">{{__('gallery.can')}}</div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;"></div>
                                    <div class="text-center"><a href="/about"
                                                                target="_self"
                                                                class="fw-btn tf-sh-05ca927d3e1ff7faf5172da26129f61d    button-with-bg fw-animated-element fw-btn-4"
                                                                data-animation-type="bounceInUp"
                                                                data-animation-delay="300"
                                                                style="width:178px; height:71px; line-height:71px;">
		<span style="top:0;">
			{{__('gallery.dont')}}		</span>
                                        </a>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:85px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>


        </div><!-- /.site-main -->

        <!-- Footer -->
        @include('layouts.footer')
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#pa{{asset("")}} src="
       {{asset("")}}wp-content/uploads/2016/07/to-top.png" alt="to top button" /></a>
@endsection

