<?php

namespace App\Http\Controllers;

use App\AboutSectionTwoTitle;
use Illuminate\Http\Request;
use App\AboutSectionOne;
use App\AboutSectionTwo;
use App\AboutSectionThree;
use App\AboutSectionFour;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;

class AboutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $section1 = AboutSectionOne::where('id',1)->first();
        $section2_1 = AboutSectionTwoTitle::where('id',1)->first();
        $section2_2 = AboutSectionTwo::get();
        $section3 = AboutSectionThree::where('id',1)->first();
        $section4 = AboutSectionFour::where('id',1)->first();
        return view('about',[
            'section1'=>$section1,
            'section2_1'=>$section2_1,
            'section2_2'=>$section2_2,
            'section3'=>$section3,
            'section4'=>$section4
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function about()
    {
       $section1 = AboutSectionOne::where('id',1)->first();
       $section2_1 = AboutSectionTwoTitle::where('id',1)->first();
       $section2_2 = AboutSectionTwo::get();
       $section3 = AboutSectionThree::where('id',1)->first();
       $section4 = AboutSectionFour::where('id',1)->first();
        return view('admin.about',[
            'section1'=>$section1,
            'section2_1'=>$section2_1,
            'section2_2'=>$section2_2,
            'section3'=>$section3,
            'section4'=>$section4
        ]);
    }

    public function updateSection4(Request $request, $id){

        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'staff_am' => 'required',
            'staff_en' => 'required',
            'staff_ru' => 'required',
            'user_am' => 'required',
            'user_en' => 'required',
            'user_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'comment_am' => 'required',
            'comment_en' => 'required',
            'comment_ru' => 'required',
            'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $section = AboutSectionFour::where('id',1)->first();
        $file = $section -> img_name;
        if(Input::hasFile('image')) {
            $filename = public_path() . '/img/about/section4' . $file;
            File::delete($filename);
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/about/section4' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/about/section4', $imgname);
            AboutSectionFour::where('id',$id)->update(['img_name'=>$imgname]);
        }
        AboutSectionFour::where('id',1)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'user_am'=>$request->user_am,
            'user_en'=>$request->user_en,
            'user_ru'=>$request->user_ru,
            'comment_am'=>$request->comment_am,
            'comment_en'=>$request->comment_en,
            'comment_ru'=>$request->comment_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,
            'staff_am' => $request->staff_am,
            'staff_en' => $request->staff_en,
            'staff_ru' => $request->staff_ru,
        ]);
        return redirect()->back()->with('message', 'Թարմացումը hաջողությամբ կատարվեց');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminat e\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateSection1(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $section = AboutSectionOne::where('id',$id)->first();
        $file = $section -> img_name;
        if (Input::hasFile('image')) {
            $filename = public_path() . '/img/about/section1' . $file;
            File::delete($filename);
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/about/section1' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/about/section1', $imgname);
            AboutSectionOne::where('id',$id)->update(['img_name'=>$imgname]);
        }
        AboutSectionOne::where('id',$id)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,
        ]);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

    public function updateSection2(Request $request,$id ){

        $validator = Validator::make($request->all(), [
            'title_am' => 'required',
            'title_en' => 'required',
            'title_ru' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        AboutSectionTwoTitle::where('id',$id)->update([
            'title_am'=>$request->title_am,
            'title_en'=>$request->title_en,
            'title_ru'=>$request->title_ru
        ]);
        $name_am = [];
        $name_ru = [];
        $name_en = [];
        $i = 0;
        $j = 0;
        $k = 0;

            foreach ($request->name_am as $val){
                if(!is_null($val)){
                    $name_am[$i] = $val;
                }
                $i++;
            }
            foreach ($request->name_en as $val){
                if(!is_null($val)){
                    $name_en[$j] = $val;
                }
                $j++;
            }
            foreach ($request->name_ru as $val){
                if(!is_null($val)){
                    $name_ru[$k] = $val;
                }
                $k++;
            }
            if(count($name_am) == count($name_en) && count($name_en) == count($name_ru)){
                for($n = 0; $n < count($name_am); $n++){
                    $insert = AboutSectionTwo::insert([
                        'name_am' => $name_am[$n],
                        'name_en' => $name_en[$n],
                        'name_ru' => $name_ru[$n],
                    ]);
                }

            }
            else{
                return redirect()->back()->with('message', 'Լրացրեք երեք լեզուներով');
            }
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

    public function updateSection3(Request $request,$id){
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'tour_am' => 'required',
            'tour_ru' => 'required',
            'tour_en' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'video_src' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        AboutSectionThree::where('id',$id)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'tour_am'=>$request->tour_am,
            'tour_en'=>$request->tour_en,
            'tour_ru'=>$request->tour_ru,
            'description_am'=>$request->description_am,
            'description_en'=>$request->description_en,
            'description_ru'=>$request->description_ru,
            'video_src'=>$request->video_src
        ]);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroySection2($id)
    {
        $section = AboutSectionTwo::where('id',$id)->first();
        $section->delete();
        return redirect()->back();
    }

    public function updateHeader(Request $request){
        $validator = Validator::make($request->all(), [
            'image' => 'required|image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $filename = public_path() . '/img/about/header/about-kid.png';
        File::delete($filename);
        $image = $request->file('image');
        $imgname = 'about-kid.png';
        $image->move(public_path() . '/img/about/header/', $imgname);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }
}
