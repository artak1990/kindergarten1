<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class EmailController extends Controller
{


    public function sendEmail(Request $request){

        $validator = Validator::make($request->all(), [
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required|email',
            'phone' => 'required|numeric',
            'subject' => 'required',
            'message' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        Mail::send('email.email' ,[ 'data' => $request ], function ($message) use ($request) {

            $message->from( $request->email, $request->firstname);

            $message->to('arto.90artak@gmail.com')->subject($request->subject);

        });

       return redirect()->back()->with('message', __('contact.contact_email'));
    }
}
