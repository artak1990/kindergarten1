<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Gallery;
use App\Category;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;

class GalleryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $gallary = Gallery::get();
        $category = Category::get();
        return view('admin.gallery',['gallary'=>$gallary,'category'=>$category]);
    }

    public function gallery(){
        $gallary = Gallery::get();
        $category = Category::get();
        return view('gallery',['gallary'=>$gallary,'category'=>$category]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'image' => 'required|image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        if (Input::hasFile('image')) {
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/gallaryimage/' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/gallaryimage/', $imgname);
            $insert = Gallery::insert([
                'img_name' => $imgname,
                'name_am' => $request->name_am,
                'name_en' => $request->name_en,
                'name_ru' => $request->name_ru,
                'description_am' => $request->description_am,
                'description_en' => $request->description_en,
                'description_ru' => $request->description_ru,
                'cat_id' => $request->categiry,
            ]);
        }
        return redirect()->back()->with('message', 'Նկարը ավելացվեց');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $gallery = Gallery::where('id', $request->id )->first();
        return response()->json($gallery);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $gallery = Gallery::where('id',$id)->first();
        $file = $gallery -> img_name;

        if (Input::hasFile('image')) {
            $filename = public_path() . '/img/gallaryimage/' . $file;
            File::delete($filename);
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/gallaryimage/' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/gallaryimage/', $imgname);
            Gallery::where('id',$id)->update(['img_name'=>$imgname]);
        }
        Gallery::where('id',$id)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,
            'cat_id' => $request->categiry
        ]);
        return redirect()->back()->with('message', 'Թարմացումը hաջողությամբ կատարվեց');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $gallery = Gallery::where('id',$id)->first();
        $file = $gallery -> img_name;
        $filename = public_path() . '/img/gallaryimage/' . $file;
        File::delete($filename);
        $gallery->delete();
        return redirect()->back();
    }

    public  function updateHeader(Request $request){
        $validator = Validator::make($request->all(), [
            'image' => 'required|image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $filename = public_path() . '/img/gallaryimage/header/gallery-kid-1.png';
        File::delete($filename);
        $image = $request->file('image');
        $imgname = 'gallery-kid-1.png';
        $image->move(public_path() . '/img/gallaryimage/header/', $imgname);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }
}
