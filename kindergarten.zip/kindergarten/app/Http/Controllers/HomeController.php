<?php

namespace App\Http\Controllers;

use App\Gallery;
use Illuminate\Http\Request;
use App\HomeSectionOne;
use App\HomeSectionTow;
use App\HomeSectionThree;
use App\HomeSectionFour;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use App\Service;
use App\HomeSection5;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $services = Service::inRandomOrder()
            ->limit(4)->get();
        $gallery = Gallery::inRandomOrder()
            ->limit(5)->get();
        $section = HomeSectionOne::get();
        $section2 = HomeSectionTow::where('id',1)->first();
        $section3 = HomeSectionThree::get();
        $section4 = HomeSectionFour::where('id',1)->first();
        $section5 = HomeSection5::get();
        return view('home' ,['section'=>$section,'section2' =>$section2,'section3'=>$section3,'section4'=>$section4,'services' => $services,'gallery'=>$gallery,'section5'=>$section5]);
    }

    public function home()
    {
        $services = Service::inRandomOrder()
            ->limit(4)->get();
        $gallery = Gallery::inRandomOrder()
            ->limit(5)->get();
        $section = HomeSectionOne::get();
        $section2 = HomeSectionTow::where('id',1)->first();
        $section3 = HomeSectionThree::get();
        $section4 = HomeSectionFour::where('id',1)->first();
        $section5 = HomeSection5::get();
        return view('admin.home',['section'=>$section,'section2' =>$section2,'section3'=>$section3,'section4'=>$section4,'services' => $services,'gallery'=>$gallery ,'section5' => $section5]);
    }

    public function update(Request $request){
        $validator = Validator::make($request->all(), [

            'name_am.*' => 'required|min:1',
            'name_en.*' => 'required|min:1',
            'name_ru.*' => 'required|min:1',
            'description_am.*' => 'required|min:1',
            'description_en.*' => 'required|min:1',
            'description_ru.*' => 'required|min:1',
            'image.*' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            'image1' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            'image2' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            'image3' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }


        if (Input::hasFile('image1')) {
            $section = HomeSectionOne::where('id',1)->first();
            $file = $section -> img_name;
            $filename = public_path() . '/img/home/section1' . $file;
            File::delete($filename);
            $image = $request->file('image1');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/home/section1' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/home/section1', $imgname);
            HomeSectionOne::where('id',1)->update(['img_name'=>$imgname]);
        }

        if (Input::hasFile('image2')) {
            $section = HomeSectionOne::where('id',2)->first();
            $file = $section -> img_name;
            $filename = public_path() . '/img/home/section1' . $file;
            File::delete($filename);
            $image = $request->file('image2');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/home/section1' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/home/section1', $imgname);
            HomeSectionOne::where('id',2)->update(['img_name'=>$imgname]);
        }

        if (Input::hasFile('image3')) {
            $section = HomeSectionOne::where('id',3)->first();
            $file = $section -> img_name;
            $filename = public_path() . '/img/home/section1' . $file;
            File::delete($filename);
            $image = $request->file('image3');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/home/section1' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/home/section1', $imgname);
            HomeSectionOne::where('id',3)->update(['img_name'=>$imgname]);
        }
        for($i=0; $i<count($request->name_am); $i++){
            HomeSectionOne::where('id',$i+1)->update([
                'name_am'=>$request->name_am[$i],
                'name_en'=>$request->name_en[$i],
                'name_ru'=>$request->name_ru[$i],
                'description_am' => $request->description_am[$i],
                'description_en' => $request->description_en[$i],
                'description_ru' => $request->description_ru[$i],
            ]);
        }

        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

    public function updateSection5(Request $request){
        $validator = Validator::make($request->all(), [

            'name_am.*' => 'required|min:1',
            'name_en.*' => 'required|min:1',
            'name_ru.*' => 'required|min:1',
            'description_am.*' => 'required|min:1',
            'description_en.*' => 'required|min:1',
            'description_ru.*' => 'required|min:1'
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        for($i = 0; $i < 3; $i++){
            HomeSection5::where('id',$i+1)->update([
                'name_am' =>$request->name_am[$i],
                'name_en' =>$request->name_en[$i],
                'name_ru' =>$request->name_ru[$i],
                'description_am' =>$request->description_am[$i],
                'description_en' =>$request->description_en[$i],
                'description_ru' =>$request->description_ru[$i],
            ]);
        }
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');


    }

    public function updateSection2(Request $request,$id){
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
            $section = HomeSectionTow::where('id',$id)->first();
            $file = $section -> img_name_1;
        if (Input::hasFile('image')) {
            $filename = public_path() . '/img/home/section2' . $file;
            File::delete($filename);
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/home/section2' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/home/section2', $imgname);
            HomeSectionTow::where('id',$id)->update(['img_name_1'=>$imgname]);
        }
        HomeSectionTow::where('id',$id)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,

        ]);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

    public function createSection3(Request $request){
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'staff_am' => 'required',
            'staff_en' => 'required',
            'staff_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'image' => 'required|image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        if (Input::hasFile('image')) {
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/home/section3' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/home/section3', $imgname);
            $insert = HomeSectionThree::insert([
                'img_name' => $imgname,
                'name_am' => $request->name_am,
                'name_en' => $request->name_en,
                'name_ru' => $request->name_ru,
                'description_am' => $request->description_am,
                'description_en' => $request->description_en,
                'description_ru' => $request->description_ru,
                'staff_am' => $request->staff_am,
                'staff_en' => $request->staff_en,
                'staff_ru' => $request->staff_ru,
            ]);
        }
        return redirect()->back()->with('message', 'Աշխատակիցը ավելացվեց');
    }

    public function editSection3(Request $request){
        $section3 = HomeSectionThree::where('id',$request->id)->first();
        return response()->json($section3);
    }

    public function updateSection3(Request $request,$id){
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'staff_am' => 'required',
            'staff_en' => 'required',
            'staff_ru' => 'required',
            'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $section = HomeSectionThree::where('id',$id)->first();
        $file = $section -> img_name;
        if (Input::hasFile('image')) {
            $filename = public_path() . '/img/home/section3' . $file;
            File::delete($filename);
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/home/section3' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/home/section3', $imgname);
            HomeSectionThree::where('id',$id)->update(['img_name'=>$imgname]);
        }
        HomeSectionThree::where('id',$id)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,
            'staff_am' => $request->staff_am,
            'staff_en' => $request->staff_en,
            'staff_ru' => $request->staff_ru,
        ]);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

    public function destroySection3 ($id){
        $section = HomeSectionThree::where('id',$id)->first();
        $file = $section -> img_name;
        $filename = public_path() . '/img/home/section3' . $file;
        File::delete($filename);
        $section->delete();
        return redirect()->back();
    }

    public function updateSection4(Request $request, $id){
        $validator = Validator::make($request->all(), [
            'name_am' => 'required',
            'name_en' => 'required',
            'name_ru' => 'required',
            'description_am' => 'required',
            'description_en' => 'required',
            'description_ru' => 'required',
            'image.*' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $section = HomeSectionFour::where('id',$id)->first();
        $file = [$section -> img_name_1,$section -> img_name_2,$section -> img_name_3];
        if($request->image_name){
            HomeSectionFour::where('id', $id)->update([
                'img_name_1'=>$request->image_name[0],
                'img_name_2'=>$request->image_name[1],
                'img_name_3'=>$request->image_name[2]
            ]);

        }
        if (Input::hasFile('image')) {
            if(count($request->image) < 3){
                return redirect()->back()->with('message', 'Նկարները երեքից պակաս լինել չեն կարող');
            }
            foreach ($file as $value){
                $filename = public_path() . '/img/home/section4' . $value;
                File::delete($filename);
            }
            $image = $request->file('image');
            $imgname = [];
            $j=0;

            foreach ($image as $val){
                $imgname[$j] = $val->getClientOriginalName();
                $j++;
            };
            $k=0;
            foreach ($imgname as $img){
                $img_name = $img;
                if (file_exists(public_path() . '/img/home/section4' . $img_name)) {
                    $img_name = random_int(0, 999) . $img_name;
                }
                $image[$k]->move(public_path() . '/img/home/section4', $img_name);
                $k++;
            }
            HomeSectionFour::where('id', $id)->update([
                'img_name_1'=>$imgname[0],
                'img_name_2'=>$imgname[1],
                'img_name_3'=>$imgname[2]
            ]);
        }
        HomeSectionFour::where('id',$id)->update([
            'name_am'=>$request->name_am,
            'name_en'=>$request->name_en,
            'name_ru'=>$request->name_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,

        ]);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

}
