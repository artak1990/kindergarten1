<?php

namespace App\Http\Controllers;

use App\ServiceCategory;
use Illuminate\Http\Request;
use App\Service;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\ServiceHeader;
use Illuminate\Support\Facades\Input;

class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        $str = explode("_",$id);
        $str = implode(' ',$str);
        $services_category = ServiceCategory::where('name_en',$str)->first();
        $services = Service::where( 'cat_id', $services_category->id )->get();
        $count = count($services);
        $x = 1;
        return view('admin.services',['services'=>$services,'services_category'=>$services_category,'x'=>$x, 'count'=>$count ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(is_null($request->title_am) && is_null($request->title_en) && is_null($request->title_ru)){
            $validator = Validator::make($request->all(), [
                'description_am' => 'required',
                'description_en' => 'required',
                'description_ru' => 'required',
                'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            ]);

        }else{
            $validator = Validator::make($request->all(), [
                'title_am' => 'required',
                'title_en' => 'required',
                'title_ru' => 'required',
                'description_am' => 'required',
                'description_en' => 'required',
                'description_ru' => 'required',
                'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            ]);
        }
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        if (Input::hasFile('image')) {
            $image = $request->file('image');
                $imgname = $image->getClientOriginalName();
                if (file_exists(public_path() . '/img/serviceimage/' . $imgname)) {
                    $imgname = random_int(0, 999) . $imgname;
                }
                $image->move(public_path() . '/img/serviceimage/', $imgname);
                $insert = Service::insert([
                    'img_name' => $imgname,
                    'title_am' => $request->title_am,
                    'title_en' => $request->title_en,
                    'title_ru' => $request->title_ru,
                    'description_am' => $request->description_am,
                    'description_en' => $request->description_en,
                    'description_ru' => $request->description_ru,
                    'cat_id' => $request->category,
                ]);
            }

            return redirect()->back()->with('message', 'Ծառայությունն ավելացվեց');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $service = Service::where('id',$request->id )->first();
        return response()->json($service);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(is_null($request->title_am) && is_null($request->title_en) && is_null($request->title_ru)){
            $validator = Validator::make($request->all(), [
                'description_am' => 'required',
                'description_en' => 'required',
                'description_ru' => 'required',
                'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            ]);

        }else{
            $validator = Validator::make($request->all(), [
                'title_am' => 'required',
                'title_en' => 'required',
                'title_ru' => 'required',
                'description_am' => 'required',
                'description_en' => 'required',
                'description_ru' => 'required',
                'image' => 'image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
            ]);
        }
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $service = Service::where('id',$id)->first();
        $file = $service -> img_name;
        if (Input::hasFile('image')) {
            $filename = public_path() . '/img/serviceimage/' . $file;
            File::delete($filename);
            $image = $request->file('image');
            $imgname = $image->getClientOriginalName();
            if (file_exists(public_path() . '/img/serviceimage/' . $imgname)) {
                $imgname = random_int(0, 999) . $imgname;
            }
            $image->move(public_path() . '/img/serviceimage/', $imgname);
            Service::where('id',$id)->update(['img_name'=>$imgname]);
        }
        Service::where('id',$id)->update([
            'title_am'=>$request->title_am,
            'title_en'=>$request->title_en,
            'title_ru'=>$request->title_ru,
            'description_am' => $request->description_am,
            'description_en' => $request->description_en,
            'description_ru' => $request->description_ru,
            'cat_id' => $request->category
        ]);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $service = Service::where('id',$id)->first();
        $file = $service -> img_name;
        $filename = public_path() . '/img/serviceimage/' . $file;
        File::delete($filename);
        $service->delete();
        return redirect()->back();
    }

    public function services($id){
        $str = explode("_",$id);
        $str = implode(' ',$str);
        $services_category = ServiceCategory::where('name_en',$str)->first();
        $services = Service::where( 'cat_id', $services_category->id )->get();
        $count = count($services);
        $x = 1;
        return view('services',['services'=>$services,'services_category'=>$services_category,'x'=>$x, 'count'=>$count ]);
    }

    public function updateHeader(Request $request){
        $validator = Validator::make($request->all(), [
            'image3' => 'required|image|mimes:jpeg,JPEG,png,PNG,jpg,JPG,gif,svg',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();
        }
        $filename = public_path() . '/img/serviceimage/header/services-kid.png';
        File::delete($filename);
        $image = $request->file('image3');
        $imgname = 'services-kid.png';
        $image->move(public_path() . '/img/serviceimage/header/', $imgname);
        return redirect()->back()->with('message', 'Թարմացումը հաջողությամբ կատարվեց');
    }

}
