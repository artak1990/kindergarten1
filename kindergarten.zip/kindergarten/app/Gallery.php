<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gallery extends Model
{
    public function categores(){
        return $this->hasMany('App\Category','id','cat_id');
    }
}
