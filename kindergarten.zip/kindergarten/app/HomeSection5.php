<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeSection5 extends Model
{
    //
}
