<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutSectionTwoTitle extends Model
{
    //
}
