<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use App\ServiceCategory;
use Illuminate\Support\Facades\View;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $ses_services = ServiceCategory::get();
        $url_ser = [];
        $i=0;
        $locale = LaravelLocalization::setLocale();
        if(is_null($locale)){
            $locale = 'am';
        }
        foreach ($ses_services as $val){
            $str = explode(" ",$val->name_en);
            $str = implode('_',$str);
            $url_ser[$i] = $str;
            $i++;
        };
        Schema::defaultStringLength(191);
        View::share(['ses_services'=>$ses_services,'url_ser'=>$url_ser,'locale' =>$locale]);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        config([
            'laravellocalization.supportedLocales' => [
                'am'  => array('name' => 'Armenian',  'script' => 'Armn', 'native' => 'AM', 'regional' => 'hy_AM'),
                'ru'  => array('name' => 'Russian',   'script' => 'Cyrl', 'native' => 'RU', 'regional' => 'ru_RU'),
                'en'  => array( 'name' => 'English', 'script' => 'Latn', 'native' => 'EN' ),
            ],

            'laravellocalization.useAcceptLanguageHeader' => true,

			'laravellocalization.hideDefaultLocaleInURL' => true
        ]);

    }
}
