<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    public function categores(){
        return $this->hasMany('App\ServiceCategory','id','cat_id');
    }
}
