<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutSectionThree extends Model
{
    //
}
