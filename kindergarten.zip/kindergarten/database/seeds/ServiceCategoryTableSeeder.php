<?php

use Illuminate\Database\Seeder;

class ServiceCategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $names = ['After School','Kindergarten','Toddler Care','Kid Parties'];
        foreach ($names as $name){
            DB::table('service_categories')->insert([
                'name_am' => $name,
                'name_en' => $name,
                'name_ru' => $name,
            ]);
        }

    }
}
