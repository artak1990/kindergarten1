<?php

use Illuminate\Database\Seeder;

class CategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $names = ['activites','facilites','locations','play-rooms'];
        foreach ($names as $name){
            DB::table('categories')->insert([
                'name_am' => $name,
                'name_en' => $name,
                'name_ru' => $name,
            ]);
        }
    }
}
