<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHomeSectionThreesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('home_section_threes', function (Blueprint $table) {
            $table->increments('id');
            $table->string('staff_am');
            $table->string('staff_en');
            $table->string('staff_ru');
            $table->string('name_am');
            $table->string('name_en');
            $table->string('name_ru');
            $table->string('img_name');
            $table->text('description_am');
            $table->text('description_en');
            $table->text('description_ru');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('home_section_threes');
    }
}
