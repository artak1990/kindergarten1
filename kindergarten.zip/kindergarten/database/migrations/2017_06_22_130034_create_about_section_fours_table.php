<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAboutSectionFoursTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('about_section_fours', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name_am');
            $table->string('name_en');
            $table->string('name_ru');
            $table->text('description_am');
            $table->text('description_en');
            $table->text('description_ru');
            $table->text('comment_am');
            $table->text('comment_en');
            $table->text('comment_ru');
            $table->string('user_am');
            $table->string('user_en');
            $table->string('user_ru');
            $table->string('staff_am');
            $table->string('staff_en');
            $table->string('staff_ru');
            $table->string('img_name');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('about_section_fours');
    }
}
