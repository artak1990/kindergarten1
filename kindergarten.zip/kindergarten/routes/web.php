<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(
    [
        'prefix' => LaravelLocalization::setLocale(),
        'middleware' => [ 'localeSessionRedirect', 'localizationRedirect', 'localeViewPath' ]
    ],
    function()
    {

    Route::get('/', 'HomeController@index');

    Route::get('/about','AboutController@index');

    Route::get('/contact', function () {
        return view('contact');
    });
    Route::get('/gallery', 'GalleryController@gallery');
    Route::get('/services/{id}','ServiceController@services');

//    Route::get('/pricing', function () {
//        return view('pricing');
//    });
});

Route::post('/sendemail','EmailController@sendEmail');
Route::group(['middleware' => 'auth'], function () {
    Route::get('/admin','HomeController@home');
    Route::get('/admin/about', 'AboutController@about');
    Route::get('/admin/services/{id}', 'ServiceController@index');
    Route::post('/admin/serviceheader/update', 'ServiceController@updateHeader');
    Route::post('/admin/galleryheader/update', 'GalleryController@updateHeader');
    Route::post('/admin/aboutheader/update', 'AboutController@updateHeader');
    Route::post('/admin/resetpassword/{id}', 'AdminController@resetPassword');
    Route::post('/admin/services/edit', 'ServiceController@edit');
    Route::post('/admin/service/update/{id}', 'ServiceController@update');
    Route::get('/admin/services/delete/{id}', 'ServiceController@destroy');
    Route::post('admin/service/create', 'ServiceController@store');
    Route::get('/admin/gallery', 'GalleryController@index');
    Route::post('/admin/gallery/create', 'GalleryController@store');
    Route::get('/admin/gallery/delete/{id}', 'GalleryController@destroy');
    Route::post('/admin/gallery/edit', 'GalleryController@edit');
    Route::post('/admin/gallery/update/{id}', 'GalleryController@update');
    Route::post('/admin/home/update', 'HomeController@update');
    Route::post('/admin/home/update_section2/{id}', 'HomeController@updateSection2');
    Route::post('/admin/home/create_section3','HomeController@createSection3');
    Route::post('/admin/home/edit_section3','HomeController@editSection3');
    Route::post('/admin/home/update_section3/{id}','HomeController@updateSection3');
    Route::get('/admin/home/delete_section3/{id}','HomeController@destroySection3');
    Route::post('/admin/home/update_section4/{id}','HomeController@updateSection4');
    Route::post('/admin/home/update_section5','HomeController@updateSection5');
    Route::post('/admin/about/update_section1/{id}','AboutController@updateSection1');
    Route::post('/admin/about/update_section2/{id}','AboutController@updateSection2');
    Route::post('/admin/about/update_section3/{id}','AboutController@updateSection3');
    Route::get('/admin/about/delete_section2/{id}','AboutController@destroySection2');
    Route::post('/admin/about/update_section4/{id}','AboutController@updateSection4');
});

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
