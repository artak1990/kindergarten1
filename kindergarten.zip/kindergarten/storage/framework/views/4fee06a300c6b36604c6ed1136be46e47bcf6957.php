<?php $__env->startSection('content'); ?>
    <div id="page" class="hfeed site">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <a href="#0" class="close" data-dismiss="alert" aria-label="close">×</a>
                <?php echo e(session()->get('message')); ?><br>
                <i class="fa fa-smile-o fa-3x" aria-hidden="true"></i>
            </div>
        <?php endif; ?>
        <?php if($errors->has('firstname') || $errors->has('lastname') || $errors->has('subject') || $errors->has('message')): ?>
            <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo e(__('contact.error_all')); ?></strong><br>
                <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
            </div>
        <?php endif; ?>
        <?php if($errors->has('email')): ?>
            <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo e(__('contact.error_email')); ?></strong><br>
                <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
            </div>
        <?php endif; ?>
        <?php if($errors->has('phone')): ?>
            <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo e(__('contact.error_phone')); ?></strong><br>
                <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
            </div>
        <?php endif; ?>
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d1ebddd8"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-1fc4149999787e5e16b054cbea2127d3 header-animation-speed"
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/07/page-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-2d172d9318c24a51d826b52791797776"
                                 class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element"
                                 data-animation-type="fadeInUp" data-animation-delay="400">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:180px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"
                                         data-animation-type="bounceInDown" data-animation-delay="400">
                                        <h2 class="fw-special-title"><?php echo e(__('contact.contact')); ?></h2>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:240px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ebeb92"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  fw-mobile-hide-element tf-sh-63e2c55f32cf8f8333d9731bd96e0fb3 "
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/healthy-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-dd4110937ca34c70203a283cfe3290d4"
                                 class="fw-col-sm-8 fw-col-md-6 tf-sh-dd4110937ca34c70203a283cfe3290d4">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="<?php echo e(asset('wp-content/uploads/2016/07/mail-icon.png')); ?>" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                <?php echo e(__('contact.address')); ?> </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-d58472aa7c5dd66cf1c8faf42755eccb"
                                 class="fw-col-sm-4 fw-col-md-3 tf-sh-d58472aa7c5dd66cf1c8faf42755eccb">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-78e8669f6752f2fd02ef70707a9a8630  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="<?php echo e(asset('wp-content/uploads/2016/07/call-icon.png')); ?>" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                +374 10 272272 </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-52ab08806e8670224e46a34b24da472f"
                                 class="fw-tablet-hide-element fw-col-sm-3 fw-tablet-landscape-hide-element tf-sh-52ab08806e8670224e46a34b24da472f">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-60db5ea8816ddda26c75e85b31c9e362  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="<?php echo e(asset('wp-content/uploads/2016/07/around-icon.png')); ?>" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                <?php echo e(__('contact.email')); ?> </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ec0776"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-8a36a227e9841e5620ecb29816bdabf3 "
                         style="   ">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-9c4a31491469f610c93055b22b7a61ad"
                                 class="fw-col-sm-12 tf-sh-9c4a31491469f610c93055b22b7a61ad  fw-col-no-padding">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                        
                                    
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.5586385148126!2d44.49861421503907!3d40.196634779391275!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd14152501ad%3A0x2d40979b8216ea8c!2sGulakyan+St%2C+Yerevan%2C+Armenia!5e0!3m2!1sru!2sru!4v1499070967718" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ec1ed2"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-e9832619ca175dae66fa3bf12cfc02e5 "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-6d84b59042d5594ec1be5f336534ad70"
                                 class="fw-col-sm-12 tf-sh-6d84b59042d5594ec1be5f336534ad70">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:90px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-ee9bffb084b942147dd1bc253beaba9e"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h4 class="fw-special-title"><?php echo e(__('contact.can')); ?><img
                                                    src="<?php echo e(asset('wp-content/uploads/2016/06/arrow.png')); ?>"></h4>


                                    </div>
                                    <div class="fw-text-box tf-sh-f4bb12b90d1c02b320b5fd2d3d5c0c11  fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <div class="fw-text-inner">
                                            <p style="text-align: center;"><?php echo e(__('contact.your')); ?></p>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:90px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-48ae7f74e4268e0ded1de0535389ee33"
                                 class="fw-col-sm-12 tf-sh-48ae7f74e4268e0ded1de0535389ee33 contact-form fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-contact-form tf-sh-3c9f96996ad4f6498e8d3a504d502c5e "
                                         data-redirect-page="">
                                        <div class="fw-row wrap-forms wrap-contact-forms">
                                            <form data-fw-form-id="fw_form" method="post"
                                                  action="/sendemail" class="fw_form_fw_form">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <div class="fw-row"></div>
                                                <div class="fw-row">
                                                    <div class="fw-col-xs-12 fw-col-sm-6 form-builder-item">
                                                        <div class="field-text">
                                                            <input type="text" name="firstname"
                                                                   placeholder="<?php echo e(__('contact.firstname')); ?>" value="" id="id-1">
                                                        </div>
                                                    </div>
                                                    <div class="fw-col-xs-12 fw-col-sm-6 form-builder-item">
                                                        <div class="field-text">
                                                            <input type="text" name="lastname"
                                                                   placeholder="<?php echo e(__('contact.lastname')); ?>" value="" id="id-2">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fw-row">
                                                    <div class="fw-col-xs-12 fw-col-sm-6 form-builder-item">
                                                        <div class="field-text">
                                                            <input type="text" name="email"
                                                                   placeholder="<?php echo e(__('contact.mail')); ?>" value="" id="id-3">
                                                        </div>
                                                    </div>
                                                    <div class="fw-col-xs-12 fw-col-sm-6 form-builder-item">
                                                        <div class="field-text">
                                                            <input type="text" name="phone"
                                                                   placeholder="<?php echo e(__('contact.phone')); ?>" value="" id="id-4">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fw-row">
                                                    <div class="fw-col-xs-12 form-builder-item">
                                                        <div class="field-text">
                                                            <input type="text" name="subject" placeholder="<?php echo e(__('contact.subject')); ?>"
                                                                   value="" id="id-5">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fw-row">
                                                    <div class="fw-col-xs-12 form-builder-item">
                                                        <div class="field-textarea">
                                                            <label for="id-6"> <?php echo e(__('contact.message')); ?> </label>
                                                            <textarea name="message" placeholder=""
                                                                      id="id-6"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fw-row"></div>
                                                <div class="fw-row">
                                                    <div class="fw-col-sm-12 field-submit text-center">
                                                        <button type="submit" class="fw-btn   fw-btn-4"
                                                                style="width:135px;height:53px;">
				<span>
											<?php echo e(__('contact.send')); ?>									</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ec469e"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-76a53f24d6deababfda1dc5ab29880fb "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-1b0a77bfb2015d2c59a58551a78352e9"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-1b0a77bfb2015d2c59a58551a78352e9">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:85px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-c532c8ce78fdd4957453330783d343c2"
                                 class="fw-tablet-hide-element fw-col-sm-2 fw-mobile-hide-element tf-sh-c532c8ce78fdd4957453330783d343c2">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                            <div id="column-25de512d1b4b1a38b777790681593aaa"
                                 class="fw-col-sm-4 fw-col-md-3 tf-sh-25de512d1b4b1a38b777790681593aaa  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-dc3263009835fa7534fd0ed98db9c319  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="" href="#" target="_self">
							<img src="<?php echo e(asset('wp-content/uploads/2016/07/facebook-icon.png')); ?>" alt=""/>						</a>
									</span>

                                            <h4 class="fw-icon-title-text">
                                                <a class="" href="https://web.facebook.com/Avetismankapartez/" target="_blank">Facebook</a>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="column-c1df9fedf0a293dd613f95b64c359162"
                                 class="fw-col-sm-4 fw-col-md-2 tf-sh-c1df9fedf0a293dd613f95b64c359162  fw-animated-element fw-col-no-padding"
                                 data-animation-type="bounceInUp" data-animation-delay="500">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-caaf442b6a76f5353c2c6e949a680b5e  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="" href="#" target="_self">
							<img src="<?php echo e(asset('wp-content/uploads/2016/07/twitter-icon.png')); ?>" alt=""/>						</a>
									</span>

                                            <h4 class="fw-icon-title-text">
                                                <a class="" href="#" target="_self">Twitter</a>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="column-99020028f15c9bc6e76da11fd0169252"
                                 class="fw-col-sm-4 fw-col-md-3 tf-sh-99020028f15c9bc6e76da11fd0169252  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="700">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-481c6c80d335419859142c8a890bd66c  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<a class="" href="#" target="_self">
							<img src="<?php echo e(asset('wp-content/uploads/2016/07/instagram-icon.png')); ?>" alt=""/>						</a>
									</span>

                                            <h4 class="fw-icon-title-text">
                                                <a class="" href="#" target="_self">Instagram</a>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="column-46aa0983b3cbd0a76ebd89f55eaeb53b"
                                 class="fw-tablet-hide-element fw-col-sm-2 fw-mobile-hide-element tf-sh-46aa0983b3cbd0a76ebd89f55eaeb53b">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-21498d78a83a5dda23057db4deec7551"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-21498d78a83a5dda23057db4deec7551">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:85px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ec6a77"
                         class=" fw-main-row-custom fw-section-no-padding  auto  fw-mobile-hide-element tf-sh-aa8ce73ecfd73ff1712d88311ac9e6e2 "
                         style="   ">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-8fdc7b5ec21e901c4c0dd0778c64d093"
                                 class="fw-col-sm-12 tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093  fw-column-height-custom"
                                 style="height: 5px;">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>


        </div><!-- /.site-main -->

        <!-- Footer -->
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#page"><img
                src="<?php echo e(asset('wp-content/uploads/2016/07/to-top.png')); ?>" alt="to top button"/></a>
    <style>
        .alert{
            position: fixed;
            top:0;
            left:0;
            right: 0;
            bottom:0;
            margin: auto;
            z-index: 9999999999999;
            width: 50%;
            height: 150px;
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.contactapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>