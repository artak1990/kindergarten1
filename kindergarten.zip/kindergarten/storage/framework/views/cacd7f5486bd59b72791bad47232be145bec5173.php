<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal_section4" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Չորորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/home/update_section4/1" method="post" enctype="multipart/form-data"
                                  id="service_update">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="block">
                                            <input type="file" name="image[]" id="" data-name="c" class="image"
                                                   multiple="multiple"/>
                                            <div id="multiple-file-preview">

                                                <div class="clear-both">
                                                    <ul id="sortable" data-xname="c" class="sort">

                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="multiple-file-preview">

                                            <div class="clear-both">
                                                <ul id="sortable1" class="sort_update">
                                                    <li class="ui-state-default" data-order="0"
                                                        data-target="tur_image_0">
                                                        <img src="<?php echo e(asset('img/home/section4/'.$section4->img_name_1)); ?>"
                                                             style="width:100%;"/>
                                                        <input type="hidden" name="image_name[]"
                                                               value="<?php echo e($section4->img_name_1); ?>">
                                                    </li>
                                                    <li class="ui-state-default" data-order="0"
                                                        data-target="tur_image_1">
                                                        <img src="<?php echo e(asset('img/home/section4/'.$section4->img_name_2)); ?>"
                                                             style="width:100%;"/>
                                                        <input type="hidden" name="image_name[]"
                                                               value="<?php echo e($section4->img_name_2); ?>">
                                                    </li>
                                                    <li class="ui-state-default" data-order="0"
                                                        data-target="tur_image_2">
                                                        <img src="<?php echo e(asset('img/home/section4/'.$section4->img_name_3)); ?>"
                                                             style="width:100%;"/>
                                                        <input type="hidden" name="image_name[]"
                                                               value="<?php echo e($section4->img_name_3); ?>">
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 section4-div-update">
                                    <label for="">Անուն Հայ*</label>
                                    <input type="text" name="name_am" id="name_am" value="<?php echo e($section4->name_am); ?>"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section4-div-update">
                                    <label for="">Անուն Անգ*</label>
                                    <input type="text" name="name_en" id="update_name_en" value="<?php echo e($section4->name_en); ?>"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section4-div-update">
                                    <label for="">Անուն Ռուս*</label>
                                    <input type="text" name="name_ru" id="update_name_ru" value="<?php echo e($section4->name_ru); ?>"
                                           class="form-control">
                                </div>
                                <div class="col-md-12 section4-div-update">
                                    <label for="">Նկարագրություն Հայ*</label>
                                    <textarea type="text" name="description_am" id="update_description_am"
                                              class="form-control"><?php echo $section4->description_am; ?></textarea>
                                </div>
                                <div class="col-md-12 section4-div-update">
                                    <label for="">Նկարագրություն Անգ*</label>
                                    <textarea type="text" name="description_en" id="update_description_en"
                                              class="form-control"><?php echo $section4->description_en; ?></textarea>
                                </div>
                                <div class="col-md-12 section4-div-update">
                                    <label for="">Նկարագրություն Ռուս*</label>
                                    <textarea type="text" name="description_ru" id="update_description_ru"
                                              class="form-control"><?php echo $section4->description_ru; ?></textarea>
                                </div>
                                <input type="submit" class="form-control" value="Թարմացնել">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
<style>
    .section4-div-update {
        border: 2px solid;
        padding: 5px;
        margin: 5px;
        border-radius: 5px;
    }
</style>