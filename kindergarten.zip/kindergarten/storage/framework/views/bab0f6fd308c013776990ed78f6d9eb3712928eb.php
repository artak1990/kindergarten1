<!doctype html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" >

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/about/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:53:00 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="" href="">
    <meta name="" content="">
    <title>ABOUT | Kindergarten </title>

    <!-- This site is optimized with the Yoast SEO plugin v4.5 - https://yoast.com/wordpress/plugins/seo/ -->
    <link rel="canonical" href="index.html" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content='' />
    <meta name="" content="" />
    <meta name="" content="" />
    <!-- / Yoast SEO plugin. -->

    <link rel='dns-prefetch' href='http://use.typekit.net/' />
    <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Feed" href="<?php echo e(asset('feed/index.html')); ?>" />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Comments Feed" href="<?php echo e(asset('comments/feed/index.html')); ?>" />
    <link rel='stylesheet' id='layerslider-css'  href='<?php echo e(asset('wp-content/plugins/LayerSlider/static/css/layerslider6fda.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='ls-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css'  href='<?php echo e(asset('wp-content/plugins/revslider/public/assets/css/settings5223.css')); ?>' type='text/css' media='all' />
    <style id='rs-plugin-settings-inline-css' type='text/css'>
        #rs-demo-id {}
    </style>
    <link rel='stylesheet' id='woocommerce-layout-css'  href='<?php echo e(asset('wp-content/plugins/woocommerce/assets/css/woocommerce-layout32bb.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php echo e(asset('wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen32bb.css')); ?>' type='text/css' media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' id='woocommerce-general-css'  href='<?php echo e(asset('wp-content/plugins/woocommerce/assets/css/woocommerce32bb.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='parent-style-css'  href='<?php echo e(asset('wp-content/themes/kids-play-parent/style66f2.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css'  href='<?php echo e(asset('wp-content/plugins/unyson/framework/static/libs/font-awesome/css/font-awesome.min9450.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css'  href='<?php echo e(asset('wp-content/themes/kids-play-parent/css/bootstrap4b68.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-mmenu-css'  href='<?php echo e(asset('wp-content/themes/kids-play-parent/css/jquery.mmenu.all4b68.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='kids-play-style-css'  href='<?php echo e(asset('wp-content/uploads/kids-play-style3494.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-theme-style-css'  href='<?php echo e(asset('wp-content/themes/kids-play-child/style4b68.css')); ?>' type='text/css' media='all' />


    <link rel="stylesheet" href="<?php echo e(asset('css/aboutstyle.css')); ?>">


    <link rel='stylesheet' id='prettyPhoto-css'  href='<?php echo e(asset('wp-content/themes/kids-play-parent/css/prettyPhoto4b68.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='animate-css'  href='<?php echo e(asset('wp-content/themes/kids-play-parent/css/animate4b68.css')); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/background66f2.css')); ?>' type='text/css' media='all' />
    
    
    <link rel='stylesheet' id='fw-googleFonts-css'  href='https://fonts.googleapis.com/css?family=Amatic+SC%3A700%7CNoto+Serif%3A700%2Cregular%2Citalic%2C700italic%7CNTR%3Aregular%7CNoto+Sans%3A700%7CMontserrat%3A700%2Cregular%7CQuattrocento+Sans%3A700%7CMerriweather%3A700&amp;subset=latin&amp;ver=4.7.5' type='text/css' media='all' />

    <script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/LayerSlider/static/js/greensockcd11.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-includes/js/jquery/jqueryb8ff.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-includes/js/jquery/jquery-migrate.min330a.js')); ?>'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var LS_Meta = {"v":"5.6.9"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/LayerSlider/static/js/layerslider.kreaturamedia.jquery6fda.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/LayerSlider/static/js/layerslider.transitions6fda.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min5223.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min5223.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lib/bootstrap.min4b68.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.touchSwipe.min4b68.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lib/html5shiv4b68.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lib/respond.min4b68.js')); ?>'></script>
    <meta name="generator" content="Powered by LayerSlider 5.6.9 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
    <!-- LayerSlider updates and docs at: https://kreaturamedia.com/layerslider-responsive-wordpress-slider-plugin/ -->
    <link rel='https://api.w.org/' href='<?php echo e(asset('wp-json/index.html')); ?>' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo e(asset('xmlrpc0db0.php')); ?>" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo e(asset('wp-includes/wlwmanifest.xml')); ?>" />
    <meta name="generator" content="WordPress 4.7.5" />
    <meta name="generator" content="WooCommerce 2.6.14" />
    <link rel='shortlink' href='<?php echo e(asset('index64b4.html?p=10')); ?>' />
    <link rel="alternate" type="application/json+oembed" href="<?php echo e(asset('/wp-json/oembed/1.0/embed110b.json?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2Fabout%2F')); ?>" />
    <link rel="alternate" type="text/xml+oembed" href="<?php echo e(asset('wp-json/oembed/1.0/embedcca2?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2Fabout%2F&amp;format=xml')); ?>" />
    <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
    <meta name="generator" content="Powered by Slider Revolution 5.2.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
</head>
<body class="page-template page-template-visual-builder-template page-template-visual-builder-template-php page page-id-10 fw-full fw-website-align-center fw-section-space-md header-1 fw-top-bar-off fw-absolute-header fw-top-social-right  fw-top-logo-left fw-logo-image fw-logo-retina fw-animation-mobile-off tf-static-ribbon-bar" itemscope="itemscope" itemtype="http://schema.org/WebPage">



<?php echo $__env->yieldContent('content'); ?>




<script>if (top.location != location) {
        // detect if location differ and redirect to original link (for exclude a external iframe)
        if( jQuery.isEmptyObject(top.location) ) {
            top.location.href = document.location.href;
        }
    }</script>

<script type='text/javascript'>
    /* <![CDATA[ */
    var TFvar = {"theme": "kindergarten-wordpress-theme"};
    /* ]]> */
</script>

<!-- Fonts -->

    
        
    
    
    



    
        
        
                    
                
        
                
        
        
        
    

    
    
    

    
    

    
    



    
        
        
        
        
        
    
    
    
    
        
            
        
    



    
        
                
        
        
        
        
        
        
        
        
        
        
        
        
            
            
            
        
    



    
        
    




    
            
        
        
            
    
    
    
        
        
    







    
    
    

<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min32bb.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js')); ?>'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var woocommerce_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/about\/?wc-ajax=%%endpoint%%"};
    /* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min32bb.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js')); ?>'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var wc_cart_fragments_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/about\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
    /* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min32bb.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lib/modernizr.min4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.carouFredSel-6.2.1-packed4b68.js?ver=1.0.4')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.prettyPhoto4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.customInput4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/scrollTo.min4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.mmenu.min.all4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/selectize.min4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.parallax4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-includes/js/jquery/ui/effect.mine899.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lazysizes.min4b68.js')); ?>'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var FwPhpVars = {"ajax_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","template_directory":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-content\/themes\/kids-play-parent","previous":"Previous","next":"Next","smartphone_animations":"no","header_5_position":"left","header_6_position":"left","effect_panels":"","effect_listitems_slide":"","fail_form_error":"Sorry you are an error in ajax, please contact the administrator of the website","socials":""};
    /* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/general4b68.js?ver=1.0.4')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core66f2.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition66f2.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background66f2.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init66f2.js')); ?>'></script>





<script type='text/javascript' src='<?php echo e(asset('wp-includes/js/wp-embed.min66f2.js')); ?>'></script>

</body>

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/about/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:53:07 GMT -->
</html>