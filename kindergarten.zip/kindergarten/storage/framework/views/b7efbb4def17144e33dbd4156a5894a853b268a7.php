<?php $__env->startSection('content'); ?>
    <div id="page" class="hfeed site">
        <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($errors->has('description_en') || $errors->has('description_am') || $errors->has('description_ru') || $errors->has('name_en') || $errors->has('name_am') || $errors->has('name_ru') || $errors->has('staff_am') || $errors->has('staff_en') || $errors->has('staff_ru') || $errors->has('description_en.*') || $errors->has('description_am.*') || $errors->has('description_ru.*') || $errors->has('name_en.*') || $errors->has('name_am.*') || $errors->has('name_ru.*')): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Լրացրեք պարտադիր դաշտերը</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errors->has('email')): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Մուտքանուն դաշտը պարտադիր է լրացման համար</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errors->has('password')): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Խնդրում են երկու դաշտում ել մուտքագրել նույն գաղտնաբառը</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errors->has('image') || $errors->has('image.*') || $errors->has('image1') || $errors->has('image2') || $errors->has('image3')): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Խնդրում ենք բեռնել նկարը հետևյալ ֆորմատներից մեկով
                        jpeg, JPEG, png, PNG, jpg, JPG, gif, svg</strong><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session()->has('message') && session()->get('message') != 'Նկարները երեքից պակաս լինել չեն կարող'): ?>
            <div class="my-all">
                <div class="alert alert-success">
                    <a href="#0" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo e(session()->get('message')); ?><br>
                    <i class="fa fa-smile-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session()->get('message') == 'Նկարները երեքից պակաս լինել չեն կարող'): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#0" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo e(session()->get('message')); ?><br>
                    <i class="fa fa-frown-o fa-5x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d04f1704"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding fw-content-overlay-custom auto  tf-sh-55620b31b9af4571c73f7284539fbdf3 "
                         style="  margin-bottom:-40px; ">
                    <div class="fw-container-fluid">
                        <div class="fw-row">

                            <div id="column-5579456537b98dc7cae4a785b508542e"
                                 class="fw-col-sm-12 tf-sh-5579456537b98dc7cae4a785b508542e  fw-col-no-padding">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">

                                    <link href="https://fonts.googleapis.com/css?family=Amatic+SC%3A700"
                                          rel="stylesheet" property="stylesheet" type="text/css" media="all"/>
                                    <link href="https://fonts.googleapis.com/css?family=Noto+Serif%3A400"
                                          rel="stylesheet" property="stylesheet" type="text/css" media="all"/>
                                    <div id="rev_slider_1_1_wrapper"
                                         class="rev_slider_wrapper fullwidthbanner-container"
                                         style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;background-image:url(<?php echo e(asset('wp-content/uploads/2016/07/main-slider-background.jpg')); ?>);background-repeat:no-repeat;background-size:cover;background-position:center center;">

                                        <!-- START REVOLUTION SLIDER 5.2.6 auto mode -->
                                        <div id="rev_slider_1_1" class="rev_slider fullwidthabanner"
                                             style="display:none;" data-version="5.2.6">

                                            <ul>    <!-- SLIDE  -->

                                                <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($val->id == 1): ?>
                                                        <li data-index="rs-20" data-transition="notransition"
                                                            data-slotamount="default" data-hideafterloop="0"
                                                            data-hideslideonmobile="off" data-easein="default"
                                                            data-easeout="default" data-masterspeed="default"
                                                            data-thumb=""
                                                            data-delay="9980" data-rotate="0" data-saveperformance="off"
                                                            data-title="Slide" data-param1="" data-param2=""
                                                            data-param3=""
                                                            data-param4="" data-param5="" data-param6="" data-param7=""
                                                            data-param8="" data-param9="" data-param10=""
                                                            data-description="">

                                                            <!-- MAIN IMAGE -->
                                                            <img src="<?php echo e(asset('wp-content/plugins/revslider/admin/assets/images/transparent.png')); ?>"
                                                                 alt="" data-bgposition="center center"
                                                                 data-bgfit="cover"
                                                                 data-bgrepeat="no-repeat" data-bgparallax="off"
                                                                 class="rev-slidebg" data-no-retina>
                                                            <!-- LAYERS -->

                                                            <!-- LAYER NR. 1 -->
                                                            <div class="tp-caption   tp-resizeme"
                                                                 id="slide-20-layer-16"
                                                                 data-x="627"
                                                                 data-y="81"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:right;s:900;e:Power2.easeInOut;"
                                                                 data-transform_out="x:left;s:900;e:Power2.easeIn;"
                                                                 data-start="0"
                                                                 data-responsive_offset="on"

                                                                 data-end="9100"

                                                                 style="z-index: 5;"><img
                                                                        src="<?php echo e(asset('img/home/section1/'.$val->img_name)); ?>"
                                                                        alt="" width="1158" height="827"
                                                                        data-ww="1158px"
                                                                        data-hh="827px" data-no-retina></div>

                                                            <!-- LAYER NR. 2 -->
                                                            <div class="tp-caption   tp-resizeme  Bubble-text rs-parallaxlevel-1"
                                                                 id="slide-20-layer-6"
                                                                 data-x="327"
                                                                 data-y="321"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:50px;opacity:0;s:800;e:Power4.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="1400"
                                                                 data-responsive_offset="on"

                                                                 data-end="9240"

                                                                 style="z-index: 6;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/main-slider-bubble.png')); ?>"
                                                                        alt="" width="500" height="330" data-ww="500px"
                                                                        data-hh="330px" data-no-retina></div>

                                                            <!-- LAYER NR. 3 -->
                                                            <div class="tp-caption   tp-resizeme  Title-1"
                                                                 id="slide-20-layer-7"
                                                                 data-x="417"
                                                                 data-y="217"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:700;e:Power3.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="550"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9240"

                                                                 style="z-index: 7; white-space: nowrap; font-size: 78px; line-height: 90px; font-weight: 700; color: rgba(245, 19, 16, 1.00);font-family:Amatic SC;">
                                                                <?php echo e($val->name_am); ?>

                                                            </div>

                                                            <!-- LAYER NR. 4 -->
                                                            <div class="tp-caption   tp-resizeme  Title-2"
                                                                 id="slide-20-layer-8"
                                                                 data-x="416"
                                                                 data-y="290"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:700;e:Power3.easeInOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="750"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9240"

                                                                 style="z-index: 8; white-space: nowrap; font-size: 118px; line-height: 120px; font-weight: 700; color: rgba(98, 42, 20, 1.00);font-family:Amatic SC;">
                                                            </div>

                                                            <!-- LAYER NR. 5 -->
                                                            <div class="tp-caption   tp-resizeme  Bubble-text-content"
                                                                 id="slide-20-layer-9"
                                                                 data-x="420"
                                                                 data-y="445"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:50px;opacity:0;s:800;e:Power4.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="1400"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9240"

                                                                 style="z-index: 9; white-space: nowrap; font-size: 16px; line-height: 27px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:Noto Serif;">
                                                                <?php echo $val->description_am; ?>

                                                            </div>

                                                            <!-- LAYER NR. 6 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-2"
                                                                 id="slide-20-layer-10"
                                                                 data-x="819"
                                                                 data-y="-41"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:easeInBack;"
                                                                 data-start="2050"
                                                                 data-responsive_offset="on"

                                                                 data-end="7600"

                                                                 style="z-index: 10;">
                                                                <img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/earth-1.png')); ?>"
                                                                        alt="" width="197" height="359" data-ww="197px"
                                                                        data-hh="359px" data-no-retina></div>

                                                            <!-- LAYER NR. 7 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-4"
                                                                 id="slide-20-layer-11"
                                                                 data-x="1164"
                                                                 data-y="-48"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="1850"
                                                                 data-responsive_offset="on"

                                                                 data-end="7400"

                                                                 style="z-index: 11;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/mercury-1.png')); ?>"
                                                                        alt="" width="300" height="544" data-ww="300px"
                                                                        data-hh="544px" data-no-retina></div>

                                                            <!-- LAYER NR. 8 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-3"
                                                                 id="slide-20-layer-12"
                                                                 data-x="1515"
                                                                 data-y="-33"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2250"
                                                                 data-responsive_offset="on"

                                                                 data-end="7200"

                                                                 style="z-index: 12;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/mars-1.png')); ?>"
                                                                        alt="" width="234" height="302" data-ww="234px"
                                                                        data-hh="302px" data-no-retina></div>

                                                            <!-- LAYER NR. 9 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-1"
                                                                 id="slide-20-layer-13"
                                                                 data-x="-72"
                                                                 data-y="-196"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2450"
                                                                 data-responsive_offset="on"

                                                                 data-end="7800"

                                                                 style="z-index: 13;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/sun-1.png')); ?>"
                                                                        alt="" width="425" height="425" data-ww="425px"
                                                                        data-hh="425px" data-no-retina></div>

                                                            <!-- LAYER NR. 10 -->
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                        </li>
                                                    <?php elseif($val->id == 2): ?>
                                                        <li data-index="rs-30" data-transition="notransition"
                                                            data-slotamount="default" data-hideafterloop="0"
                                                            data-hideslideonmobile="off" data-easein="default"
                                                            data-easeout="default" data-masterspeed="default"
                                                            data-thumb=""
                                                            data-delay="9630" data-rotate="0" data-saveperformance="off"
                                                            data-title="Slide" data-param1="" data-param2=""
                                                            data-param3=""
                                                            data-param4="" data-param5="" data-param6="" data-param7=""
                                                            data-param8="" data-param9="" data-param10=""
                                                            data-description="">
                                                            <!-- MAIN IMAGE -->
                                                            <img src="<?php echo e(asset('wp-content/plugins/revslider/admin/assets/images/transparent.png')); ?>"
                                                                 alt="" data-bgposition="center center"
                                                                 data-bgfit="cover"
                                                                 data-bgrepeat="no-repeat" data-bgparallax="off"
                                                                 class="rev-slidebg" data-no-retina>
                                                            <!-- LAYERS -->

                                                            <!-- LAYER NR. 1 -->
                                                            <div class="tp-caption   tp-resizeme"
                                                                 id="slide-30-layer-17"
                                                                 data-x="223"
                                                                 data-y="144"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="opacity:0;s:900;e:Power2.easeInOut;"
                                                                 data-transform_out="opacity:0;s:400;"
                                                                 data-start="0"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 5;"><img
                                                                        src="<?php echo e(asset('img/home/section1/'.$val->img_name)); ?>"
                                                                        alt="" width="989" height="705" data-ww="989px"
                                                                        data-hh="705px" data-no-retina></div>

                                                            <!-- LAYER NR. 2 -->
                                                            <div class="tp-caption   tp-resizeme  Bubble-text rs-parallaxlevel-1"
                                                                 id="slide-30-layer-6"
                                                                 data-x="977"
                                                                 data-y="257"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:50px;opacity:0;s:800;e:Power4.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="1400"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 6;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/main-slider-bubble-2.png')); ?>"
                                                                        alt="" width="500" height="330" data-ww="500px"
                                                                        data-hh="330px" data-no-retina></div>

                                                            <!-- LAYER NR. 3 -->
                                                            <div class="tp-caption   tp-resizeme  Title-1"
                                                                 id="slide-30-layer-7"
                                                                 data-x="1067"
                                                                 data-y="239"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:700;e:Power3.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="550"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 7; white-space: nowrap; font-size: 99px; line-height: 90px; font-weight: 700; color: rgba(255, 175, 28, 1.00);font-family:Amatic SC;">
                                                                <?php echo e($val->name_am); ?>

                                                            </div>

                                                            <!-- LAYER NR. 4 -->
                                                            <div class="tp-caption   tp-resizeme  Title-1"
                                                                 id="slide-30-layer-8"
                                                                 data-x="1170"
                                                                 data-y="223"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:700;e:Power3.easeInOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="750"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 8; white-space: nowrap; font-size: 99px; line-height: 120px; font-weight: 700; color: rgba(98, 42, 20, 1.00);font-family:Amatic SC;">
                                                            </div>

                                                            <!-- LAYER NR. 5 -->
                                                            <div class="tp-caption   tp-resizeme  Bubble-text-content"
                                                                 id="slide-30-layer-9"
                                                                 data-x="1071"
                                                                 data-y="365"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:50px;opacity:0;s:800;e:Power4.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="1400"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 9; white-space: nowrap; font-size: 16px; line-height: 27px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:Noto Serif;">
                                                                <?php echo $val->description_am; ?>

                                                            </div>

                                                            <!-- LAYER NR. 6 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-1"
                                                                 id="slide-30-layer-10"
                                                                 data-x="640"
                                                                 data-y="-95"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:easeInBack;"
                                                                 data-start="2050"
                                                                 data-responsive_offset="on"

                                                                 data-end="7600"

                                                                 style="z-index: 10;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/lightbulb-3-1.png')); ?>"
                                                                        alt="" width="117" height="309" data-ww="117px"
                                                                        data-hh="309px" data-no-retina></div>

                                                            <!-- LAYER NR. 7 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-4"
                                                                 id="slide-30-layer-11"
                                                                 data-x="256"
                                                                 data-y="-70"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="1850"
                                                                 data-responsive_offset="on"

                                                                 data-end="7400"

                                                                 style="z-index: 11;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/lightbulb-2-1.png')); ?>"
                                                                        alt="" width="400" height="666" data-ww="400px"
                                                                        data-hh="666px" data-no-retina></div>

                                                            <!-- LAYER NR. 8 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-3"
                                                                 id="slide-30-layer-12"
                                                                 data-x="1406"
                                                                 data-y="-51"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2250"
                                                                 data-responsive_offset="on"

                                                                 data-end="7200"

                                                                 style="z-index: 12;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/lightbulb-5-1.png')); ?>"
                                                                        alt="" width="262" height="478" data-ww="262px"
                                                                        data-hh="478px" data-no-retina></div>

                                                            <!-- LAYER NR. 9 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-2"
                                                                 id="slide-30-layer-13"
                                                                 data-x="179"
                                                                 data-y="-46"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2450"
                                                                 data-responsive_offset="on"

                                                                 data-end="7800"

                                                                 style="z-index: 13;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/lightbulb-1-1.png')); ?>"
                                                                        alt="" width="170" height="338" data-ww="170px"
                                                                        data-hh="338px" data-no-retina></div>

                                                            <!-- LAYER NR. 10 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-2"
                                                                 id="slide-30-layer-16"
                                                                 data-x="768"
                                                                 data-y="-65"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2650"
                                                                 data-responsive_offset="on"

                                                                 data-end="8000"

                                                                 style="z-index: 14;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/lightbulb-4.png')); ?>"
                                                                        alt="" width="200" height="400" data-ww="200px"
                                                                        data-hh="400px" data-no-retina></div>

                                                            <!-- LAYER NR. 11 -->
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                        </li>
                                                    <?php elseif($val->id == 3): ?>
                                                        <li data-index="rs-19" data-transition="notransition"
                                                            data-slotamount="default" data-hideafterloop="0"
                                                            data-hideslideonmobile="off" data-easein="default"
                                                            data-easeout="default" data-masterspeed="default"
                                                            data-thumb=""
                                                            data-delay="9630" data-rotate="0" data-saveperformance="off"
                                                            data-title="Slide" data-param1="" data-param2=""
                                                            data-param3=""
                                                            data-param4="" data-param5="" data-param6="" data-param7=""
                                                            data-param8="" data-param9="" data-param10=""
                                                            data-description="">
                                                            <!-- MAIN IMAGE -->
                                                            <img src="<?php echo e(asset('wp-content/plugins/revslider/admin/assets/images/transparent.png')); ?>"
                                                                 alt="" data-bgposition="center center"
                                                                 data-bgfit="cover"
                                                                 data-bgrepeat="no-repeat" data-bgparallax="off"
                                                                 class="rev-slidebg" data-no-retina>
                                                            <!-- LAYERS -->

                                                            <!-- LAYER NR. 1 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-2"
                                                                 id="slide-19-layer-16"
                                                                 data-x="871"
                                                                 data-y="-27"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2450"
                                                                 data-responsive_offset="on"

                                                                 data-end="8000"

                                                                 style="z-index: 5;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/cloud-2.png')); ?>"
                                                                        alt="" width="506" height="384" data-ww="506px"
                                                                        data-hh="384px" data-no-retina></div>

                                                            <!-- LAYER NR. 2 -->
                                                            <div class="tp-caption   tp-resizeme"
                                                                 id="slide-19-layer-18"
                                                                 data-x="360"
                                                                 data-y="-2"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:bottom;s:900;e:Power2.easeInOut;"
                                                                 data-transform_out="y:top;s:400;e:Power2.easeIn;"
                                                                 data-start="0"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 6;"><img
                                                                        src="<?php echo e(asset('img/home/section1/'.$val->img_name)); ?>"
                                                                        alt="" width="829" height="850" data-ww="829px"
                                                                        data-hh="850px" data-no-retina></div>

                                                            <!-- LAYER NR. 3 -->
                                                            <div class="tp-caption   tp-resizeme  Bubble-text rs-parallaxlevel-1"
                                                                 id="slide-19-layer-6"
                                                                 data-x="1050"
                                                                 data-y="243"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:50px;opacity:0;s:800;e:Power4.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="1400"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 7;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/main-slider-bubble-3.png')); ?>"
                                                                        alt="" width="500" height="330" data-ww="500px"
                                                                        data-hh="330px" data-no-retina></div>

                                                            <!-- LAYER NR. 4 -->
                                                            <div class="tp-caption   tp-resizeme  Title-1"
                                                                 id="slide-19-layer-7"
                                                                 data-x="1167"
                                                                 data-y="227"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:700;e:Power3.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="550"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 8; white-space: nowrap; font-size: 99px; line-height: 90px; font-weight: 700; color: rgba(98, 42, 20, 1.00);font-family:Amatic SC;">
                                                                <?php echo e($val->name_am); ?>

                                                            </div>

                                                            <!-- LAYER NR. 5 -->
                                                            <div class="tp-caption   tp-resizeme  Title-1"
                                                                 id="slide-19-layer-8"
                                                                 data-x="1338"
                                                                 data-y="213"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:700;e:Power3.easeInOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="750"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 9; white-space: nowrap; font-size: 99px; line-height: 120px; font-weight: 700; color: rgba(255, 175, 28, 1.00);font-family:Amatic SC;">
                                                            </div>

                                                            <!-- LAYER NR. 6 -->
                                                            <div class="tp-caption   tp-resizeme  Bubble-text-content"
                                                                 id="slide-19-layer-9"
                                                                 data-x="1169"
                                                                 data-y="349"
                                                                 data-width="['auto']"
                                                                 data-height="['auto']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:50px;opacity:0;s:800;e:Power4.easeOut;"
                                                                 data-transform_out="opacity:0;s:400;e:Linear.easeNone;"
                                                                 data-start="1400"
                                                                 data-splitin="none"
                                                                 data-splitout="none"
                                                                 data-responsive_offset="on"

                                                                 data-end="9230"

                                                                 style="z-index: 10; white-space: nowrap; font-size: 16px; line-height: 27px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:Noto Serif;">
                                                                <?php echo $val->description_am; ?>

                                                            </div>

                                                            <!-- LAYER NR. 7 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-1"
                                                                 id="slide-19-layer-10"
                                                                 data-x="474"
                                                                 data-y="-35"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:easeInBack;"
                                                                 data-start="2050"
                                                                 data-responsive_offset="on"

                                                                 data-end="7600"

                                                                 style="z-index: 11;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/cloud-4-1.png')); ?>"
                                                                        alt="" width="200" height="211" data-ww="200px"
                                                                        data-hh="211px" data-no-retina></div>

                                                            <!-- LAYER NR. 8 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-4"
                                                                 id="slide-19-layer-11"
                                                                 data-x="142"
                                                                 data-y="-73"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="1850"
                                                                 data-responsive_offset="on"

                                                                 data-end="7400"

                                                                 style="z-index: 12;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/cloud-1-1.png')); ?>"
                                                                        alt="" width="528" height="596" data-ww="528px"
                                                                        data-hh="596px" data-no-retina></div>

                                                            <!-- LAYER NR. 9 -->
                                                            <div class="tp-caption   tp-resizeme rs-parallaxlevel-3"
                                                                 id="slide-19-layer-12"
                                                                 data-x="1372"
                                                                 data-y="-90"
                                                                 data-width="['none','none','none','none']"
                                                                 data-height="['none','none','none','none']"
                                                                 data-transform_idle="o:1;"

                                                                 data-transform_in="y:top;s:400;e:Back.easeOut;"
                                                                 data-transform_out="y:top;s:400;e:Back.easeIn;"
                                                                 data-start="2250"
                                                                 data-responsive_offset="on"

                                                                 data-end="7200"

                                                                 style="z-index: 13;"><img
                                                                        src="<?php echo e(asset('wp-content/uploads/2016/07/cloud-3-1.png')); ?>"
                                                                        alt="" width="506" height="586" data-ww="506px"
                                                                        data-hh="586px" data-no-retina></div>

                                                            <!-- LAYER NR. 10 -->
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            

                                                            
                                                            
                                                            
                                                        </li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <!-- SLIDE  -->

                                                <!-- SLIDE  -->

                                            </ul>

                                            <script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
                                                var htmlDivCss = "";
                                                if (htmlDiv) {
                                                    htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                                } else {
                                                    var htmlDiv = document.createElement("div");
                                                    htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                                                    document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
                                                }
                                            </script>
                                            <div class="tp-bannertimer tp-bottom"
                                                 style="visibility: hidden !important;"></div>

                                        </div>

                                        <script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
                                            var htmlDivCss = "";
                                            if (htmlDiv) {
                                                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                            } else {
                                                var htmlDiv = document.createElement("div");
                                                htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                                                document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
                                            }
                                        </script>
                                        <script type="text/javascript">
                                            /******************************************
                                             -    PREPARE PLACEHOLDER FOR SLIDER    -
                                             ******************************************/

                                            var setREVStartSize = function () {
                                                try {
                                                    var e = new Object, i = jQuery(window).width(), t = 9999, r = 0, n = 0, l = 0, f = 0, s = 0, h = 0;
                                                    e.c = jQuery('#rev_slider_1_1');
                                                    e.gridwidth = [1920];
                                                    e.gridheight = [850];

                                                    e.sliderLayout = "auto";
                                                    if (e.responsiveLevels && (jQuery.each(e.responsiveLevels, function (e, f) {
                                                                f > i && (t = r = f, l = e), i > f && f > r && (r = f, n = e)
                                                            }), t > r && (l = n)), f = e.gridheight[l] || e.gridheight[0] || e.gridheight, s = e.gridwidth[l] || e.gridwidth[0] || e.gridwidth, h = i / s, h = h > 1 ? 1 : h, f = Math.round(h * f), "fullscreen" == e.sliderLayout) {
                                                        var u = (e.c.width(), jQuery(window).height());
                                                        if (void 0 != e.fullScreenOffsetContainer) {
                                                            var c = e.fullScreenOffsetContainer.split(",");
                                                            if (c) jQuery.each(c, function (e, i) {
                                                                u = jQuery(i).length > 0 ? u - jQuery(i).outerHeight(!0) : u
                                                            }), e.fullScreenOffset.split("%").length > 1 && void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 ? u -= jQuery(window).height() * parseInt(e.fullScreenOffset, 0) / 100 : void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 && (u -= parseInt(e.fullScreenOffset, 0))
                                                        }
                                                        f = u
                                                    } else void 0 != e.minHeight && f < e.minHeight && (f = e.minHeight);
                                                    e.c.closest(".rev_slider_wrapper").css({height: f})

                                                } catch (d) {
                                                    console.log("Failure at Presize of Slider:" + d)
                                                }
                                            };

                                            setREVStartSize();

                                            var tpj = jQuery;

                                            var revapi1;
                                            tpj(document).ready(function () {
                                                if (tpj("#rev_slider_1_1").revolution == undefined) {
                                                    revslider_showDoubleJqueryError("#rev_slider_1_1");
                                                } else {
                                                    revapi1 = tpj("#rev_slider_1_1").show().revolution({
                                                        sliderType: "standard",
                                                        jsFileLocation: "//demo.themefuse.com/kindergarten-wordpress-theme/wp-content/plugins/revslider/public/assets/js/",
                                                        sliderLayout: "auto",
                                                        dottedOverlay: "none",
                                                        delay: 9000,
                                                        navigation: {
                                                            keyboardNavigation: "off",
                                                            keyboard_direction: "horizontal",
                                                            mouseScrollNavigation: "off",
                                                            mouseScrollReverse: "default",
                                                            onHoverStop: "off",
                                                            arrows: {
                                                                style: "uranus",
                                                                enable: true,
                                                                hide_onmobile: false,
                                                                hide_onleave: false,
                                                                tmp: '',
                                                                left: {
                                                                    h_align: "left",
                                                                    v_align: "center",
                                                                    h_offset: 20,
                                                                    v_offset: 0
                                                                },
                                                                right: {
                                                                    h_align: "right",
                                                                    v_align: "center",
                                                                    h_offset: 20,
                                                                    v_offset: 0
                                                                }
                                                            }
                                                        },
                                                        visibilityLevels: [1240, 1024, 778, 480],
                                                        gridwidth: 1920,
                                                        gridheight: 850,
                                                        lazyType: "none",
                                                        parallax: {
                                                            type: "mouse",
                                                            origo: "slidercenter",
                                                            speed: 1000,
                                                            levels: [2, 5, 10, 15, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 51, 55],
                                                            type: "mouse",
                                                        },
                                                        shadow: 0,
                                                        spinner: "spinner2",
                                                        stopLoop: "off",
                                                        stopAfterLoops: -1,
                                                        stopAtSlide: -1,
                                                        shuffle: "off",
                                                        autoHeight: "on",
                                                        disableProgressBar: "on",
                                                        hideThumbsOnMobile: "off",
                                                        hideSliderAtLimit: 0,
                                                        hideCaptionAtLimit: 0,
                                                        hideAllCaptionAtLilmit: 0,
                                                        debugMode: false,
                                                        fallbacks: {
                                                            simplifyAll: "off",
                                                            nextSlideOnWindowFocus: "off",
                                                            disableFocusListener: false,
                                                        }
                                                    });
                                                }
                                            });
                                            /*ready*/
                                        </script>
                                        <script>
                                            var htmlDivCss = ' #rev_slider_1_1_wrapper .tp-loader.spinner2{ background-color: #FFFFFF !important; } ';
                                            var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
                                            if (htmlDiv) {
                                                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                            }
                                            else {
                                                var htmlDiv = document.createElement('div');
                                                htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                                                document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
                                            }
                                        </script>
                                        <script>
                                            var htmlDivCss = unescape("%40media%28max-width%3A1400px%29%7B%0A.Button-brown-link%7Bpadding-left%3A23px%20%21important%3B%7D%0A%7D%0A%0A%40media%28max-width%3A1024px%29%7B%0A.Bubble-text-content%7Bfont-size%3A10px%20%21important%3B%7D%0A.Bubble-text%20img%7Bwidth%3A290px%20%21important%3B%20height%3A190px%20%21important%3B%20margin-top%3A-30px%20%21important%3B%7D%0A.Button-brown-link%7Bpadding-left%3A23px%20%21important%3B%7D%0A%7D%0A%0A%40media%28max-width%3A780px%29%7B%0A.Bubble-text%7Bdisplay%3Anone%20%21important%3B%7D%0A.Bubble-text-content%7Bdisplay%3Anone%20%21important%3B%7D%0A.Title-1%7Bfont-size%3A34px%20%21important%3B%7D%0A.Title-2%7Bfont-size%3A34px%20%21important%3B%0A%20%20%20%20%20%20%20%20%20margin-top%3A20px%20%21important%3B%7D%0A.Button-brown-bg%7B%7D%0A.Button-brown-link%7Bpadding-left%3A23px%20%21important%3B%7D%0A%7D");
                                            var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
                                            if (htmlDiv) {
                                                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                            }
                                            else {
                                                var htmlDiv = document.createElement('div');
                                                htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                                                document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
                                            }
                                        </script>
                                        <script>
                                            var htmlDivCss = unescape("%23rev_slider_1_1%20.uranus.tparrows%20%7B%0A%20%20width%3A50px%3B%0A%20%20height%3A50px%3B%0A%20%20background%3Argba%28255%2C255%2C255%2C0%29%3B%0A%20%7D%0A%20%23rev_slider_1_1%20.uranus.tparrows%3Abefore%20%7B%0A%20width%3A50px%3B%0A%20height%3A50px%3B%0A%20line-height%3A50px%3B%0A%20font-size%3A40px%3B%0A%20transition%3Aall%200.3s%3B%0A-webkit-transition%3Aall%200.3s%3B%0A%20%7D%0A%20%0A%20%20%23rev_slider_1_1%20.uranus.tparrows%3Ahover%3Abefore%20%7B%0A%20%20%20%20opacity%3A0.75%3B%0A%20%20%7D%0A");
                                            var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
                                            if (htmlDiv) {
                                                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                            }
                                            else {
                                                var htmlDiv = document.createElement('div');
                                                htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                                                document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
                                            }
                                        </script>
                                        <span class="my-update update-rigth">
                                        <i class="fa fa-pencil-square-o fa-3x"
                                           aria-hidden="true"
                                           data-toggle="modal"
                                           data-target="#myModal" data-id=""></i>
                                    </span>
                                    </div><!-- END REVOLUTION SLIDER -->    </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d051819b"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-872f3fd6e2ebb934279c377f370408a6 "
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/imagine-bg-img.png')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 550px;">
                    <div class="fw-container">
                        <div class="fw-row">
                         <span class="my-update update-rigth">
                            <i class="fa fa-pencil-square-o fa-3x"
                               aria-hidden="true"
                               data-toggle="modal"
                               data-target="#myModal_section2" data-id=""></i>
                         </span>
                            <div id="column-7908bf255716dde1c1cb3b71448c5b64"
                                 class="fw-col-sm-4 fw-col-md-6 tf-sh-7908bf255716dde1c1cb3b71448c5b64">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">


                                    <div class="fw-block-image-parent  fw-block-image-center" style="width: 395px; ">
        <span class="fw-block-image-child fw-noratio fw-ratio-container">
            <noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                        src="<?php echo e(asset('wp-content/uploads/2016/06/imagine-img.png')); ?>" alt="imagine-img"
                        data-maxdpr="1.7" width="395" class="lazyload"/><meta itemprop="url"
                                                                              content="<?php echo e(asset('wp-content/uploads/2016/06/imagine-img.png')); ?>"><meta
                        itemprop="width" content="395"><meta itemprop="height" content="554"></noscript><img
                    src="<?php echo e(asset('img/home/section2/'.$section2->img_name_1)); ?>"
                    data-sizes="auto"
                    data-srcset="<?php echo e(asset('img/home/section2/'.$section2->img_name_1)); ?>"
                    alt="imagine-img" data-maxdpr="1.7" width="395" class="lazyload"/><span
                    class="fw-after-no-ratio" style="padding-bottom: 140.25316455696%"></span>							</span>
                                    </div>


                                </div>
                            </div>
                            <div id="column-40797bfb2bfef5b6921b817dd800a441"
                                 class="fw-col-sm-8 fw-col-md-6 tf-sh-40797bfb2bfef5b6921b817dd800a441">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-tablet-hide-element fw-mobile-hide-element clearfix"
                                         style="height:120px;"></div>
                                    <div class="fw-divider-space  fw-custom-space  fw-desktop-hide-element fw-tablet-landscape-hide-element fw-mobile-hide-element clearfix"
                                         style="height:50px;"></div>
                                    <div class="fw-heading fw-heading-left  fw-animated-element tf-sh-ba33839c5cc4d541309d64e74fb774be"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h3 class="fw-special-title"><span
                                                    style="color:#ed3f27;"><?php echo e($section2->name_am); ?></span>
                                        </h3>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:15px;"></div>
                                    <div class="fw-text-box tf-sh-0351c8449b6140d77cead58e01ab2e55  fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <div class="fw-text-inner">
                                            <p><?php echo $section2->description_am; ?></p>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:35px;"></div>
                                    <div class="text-left"><a href="/admin/about" target="_self"
                                                              class="fw-btn tf-sh-82e7d97c08f503a997c0ad82cb159425    button-with-bg fw-animated-element fw-btn-4"
                                                              data-animation-type="bounceInUp"
                                                              data-animation-delay="300"
                                                              style="width:135px; height:53px; line-height:53px;">
    <span style="top:0;">
        Find Out More		</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d051a3df"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-4bd18a9dd18653211fe16687c491f999 "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-b10e87dcfdbff73bb53c6cdc861ebf99"
                                 class="fw-col-sm-12 tf-sh-b10e87dcfdbff73bb53c6cdc861ebf99">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:50px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-241ee49342fa677eb1534fe0b1de4e64"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h3 class="fw-special-title"><?php echo e(__('home.here')); ?> <img alt=""
                                                                                              src="<?php echo e(asset('wp-content/uploads/2016/06/arrow.png')); ?>"/>
                                        </h3>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:50px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-e2b0c0d50aa2f7641d7dccb79d0f610b"
                                 class="fw-col-sm-6 tf-sh-e2b0c0d50aa2f7641d7dccb79d0f610b">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-iconbox clearfix tf-sh-e2c8f8b27bf49b2821e2c8f6a32cd8e1 fw-iconbox-2  fw-iconbox-image-type    fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <div class="fw-iconbox-image " style="">
                                            <img src="<?php echo e(asset('wp-content/uploads/2016/06/clock-icon.png')); ?>" alt=""/>
                                        </div>

                                        <div class="fw-iconbox-aside">
                                            <div class="fw-iconbox-title">
                                                <h4><?php if(session('locale')=="en"): ?><?php echo e($services[0]->title_en); ?><?php elseif(session('locale')=="ru"): ?><?php echo e($services[0]->title_ru); ?><?php else: ?><?php echo e($services[0]->title_am); ?><?php endif; ?></h4>
                                            </div>

                                            <div class="fw-iconbox-text">
                                                <p><?php echo $services[0]->description_am; ?></p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="column-65992d769bf2eecce265b9e25dc6f109"
                                 class="fw-col-sm-6 tf-sh-65992d769bf2eecce265b9e25dc6f109">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-iconbox clearfix tf-sh-a122feea0fe190d157efe4e220465d44 fw-iconbox-2  fw-iconbox-image-type    fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="500">
                                        <div class="fw-iconbox-image " style="">
                                            <img src="<?php echo e(asset('wp-content/uploads/2016/06/plane-icon.png')); ?>" alt=""/>
                                        </div>

                                        <div class="fw-iconbox-aside">
                                            <div class="fw-iconbox-title">
                                                <h4><?php if(session('locale')=="en"): ?><?php echo e($services[1]->title_en); ?><?php elseif(session('locale')=="ru"): ?><?php echo e($services[1]->title_ru); ?><?php else: ?><?php echo e($services[1]->title_am); ?><?php endif; ?></h4>
                                            </div>

                                            <div class="fw-iconbox-text">
                                                <p><?php echo $services[1]->description_am; ?></p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-6671d9a35585cd128e9d7eeffb4d3912"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-6671d9a35585cd128e9d7eeffb4d3912">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:60px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-1b4ea3a2ec69327cde2089b60dab4284"
                                 class="fw-col-sm-6 tf-sh-1b4ea3a2ec69327cde2089b60dab4284">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-iconbox clearfix tf-sh-2a204e89a72018d024828746b63b5409 fw-iconbox-2  fw-iconbox-image-type    fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <div class="fw-iconbox-image " style="">
                                            <img src="<?php echo e(asset('wp-content/uploads/2016/06/toddler-icon.png')); ?>" alt=""/>
                                        </div>

                                        <div class="fw-iconbox-aside">
                                            <div class="fw-iconbox-title">
                                                <h4><?php echo e($services[2]->title_am); ?></h4>
                                            </div>

                                            <div class="fw-iconbox-text">
                                                <p><?php echo $services[2]->description_am; ?></p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="column-428d1d14235f60f8e1bb098da92c77c0"
                                 class="fw-col-sm-6 tf-sh-428d1d14235f60f8e1bb098da92c77c0">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-iconbox clearfix tf-sh-0394da1dafd08db3c3d103bfb95d47c5 fw-iconbox-2  fw-iconbox-image-type    fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="500">
                                        <div class="fw-iconbox-image " style="">
                                            <img src="<?php echo e(asset('wp-content/uploads/2016/06/tent-icon.png')); ?>" alt=""/>
                                        </div>

                                        <div class="fw-iconbox-aside">
                                            <div class="fw-iconbox-title">
                                                <h4><?php echo e($services[3]->title_am); ?></h4>
                                            </div>

                                            <div class="fw-iconbox-text">
                                                <p><?php echo $services[3]->description_am; ?></p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-3ea464f56f654457005794b271ef8ac1"
                                 class="fw-col-sm-12 tf-sh-3ea464f56f654457005794b271ef8ac1">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:60px;"></div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:110px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d051de50"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  tf-sh-3eff26ae2ca1aa5a5b16d2b80b3309bd "
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/team-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-ae6bfb9396c1a9de97d988fbdd5c789b"
                                 class="fw-col-sm-12 tf-sh-ae6bfb9396c1a9de97d988fbdd5c789b">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:85px;"></div>
                                    <div class="fw-divider-space  fw-custom-space  fw-desktop-hide-element fw-tablet-landscape-hide-element fw-tablet-hide-element clearfix"
                                         style="height:35px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-heading-with-subtitle fw-animated-element tf-sh-60c0bad52522f559fa151a955b3c19f6"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h3 class="fw-special-title"><img alt=""
                                                                          src="<?php echo e(asset('wp-content/uploads/2016/06/arrow-left.png')); ?>"/>Ivy
                                            League Educators</h3>


                                        <div class="fw-special-subtitle">THE BEST POSSIBLE START</div>
                                        <h3 data-toggle="modal"
                                            data-target="#myModal_section3" data-id="" class="my-create"><i
                                                    class="fa fa-plus" aria-hidden="true"></i>
                                        </h3>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:25px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row owl-carousel" id="owl-demo">
                            <?php $__currentLoopData = $section3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="column-fb245a3da36cf1ea31f6b5eb48ed6f1f"
                                     class="fw-col-sm-6 fw-col-md-4 tf-sh-fb245a3da36cf1ea31f6b5eb48ed6f1f item for-owl-carusel">
                                <span class="my-update update-left ">
                                    <i class="fa fa-pencil-square-o fa-3x section3-update"
                                       aria-hidden="true"
                                       data-toggle="modal"
                                       data-target="#myModal_section3" data-id="<?php echo e($val->id); ?>"></i>
                                </span>
                                    <span class="delete_update_image delete_section3"
                                          href='/admin/home/delete_section3/<?php echo e($val->id); ?>'
                                          data-toggle="modal" data-target="#Modal"><i
                                                class="fa fa-trash-o fa-3x" aria-hidden="true"></i></span>
                                    <div class="fw-main-row-overlay"></div>
                                    <div class="fw-col-inner">
                                        <div class="fw-team tf-sh-0c69f41db7d4544a2a801cc8660b8855  fw-content-align-center fw-animated-element fw-team-member-type-1"
                                             data-animation-type="bounceInUp" data-animation-delay="500">

                                            <div style="width: 222px;"
                                                 class="fw-team-image fw-block-image-parent fw-block-image-circle">
                                                <div class="fw-block-image-child fw-ratio-1 fw-ratio-container">
                                                    <noscript itemscope itemtype="http://schema.org/ImageObject"
                                                              itemprop="image"><img
                                                                src="<?php echo e(asset('img/home/section3/'.$val->img_name)); ?>"
                                                                alt="elsa" data-maxdpr="1.7" width="222"
                                                                class="lazyload"/>
                                                        <meta itemprop="url"
                                                              content="wp-content/uploads/2016/06/elsa.png">
                                                        <meta itemprop="width" content="222">
                                                        <meta itemprop="height" content="222">
                                                    </noscript>
                                                    <img src="<?php echo e(asset('img/home/section3/'.$val->img_name)); ?>"
                                                         data-sizes="auto"
                                                         data-srcset="<?php echo e(asset('img/home/section3/'.$val->img_name)); ?>"
                                                         alt="elsa" data-maxdpr="1.7" width="222" class="lazyload"/>
                                                </div>
                                            </div>

                                            <div class="fw-team-inner" style="padding-left:10px;padding-right:10px;">
                                                <div class="fw-team-name">
                                                    <h6><?php echo e($val->name_am); ?></h6>
                                                    <span><?php echo e($val->staff_am); ?></span>
                                                </div>

                                                <div class="fw-team-text"><p
                                                            style="text-align: center;"><?php echo $val->description_am; ?></p>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            

                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            

                            
                            
                            

                            
                            
                            
                            
                        </div>

                        <div class="fw-row">
                            <div id="column-2f1c41d3d437fcd950d3540f2d14f944"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-2f1c41d3d437fcd950d3540f2d14f944">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:60px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d05215c3"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-ef2831e7d7e4cc8a54ddfd40d2b7c67b "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-21b52f8376bafacd44f774d9b71b5e1e"
                                 class="fw-col-sm-12 tf-sh-21b52f8376bafacd44f774d9b71b5e1e">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:50px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-fa3517060d1ca694e2eb5c93ddbbeba3"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h3 class="fw-special-title"><?php echo e(__('home.photo')); ?> <img
                                                    src="<?php echo e(asset('wp-content/uploads/2016/06/arrow.png')); ?>" alt=""/>
                                        </h3>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:50px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-3af2bd89724cb03902d9df16bfa70545"
                                 class="fw-col-sm-12 tf-sh-3af2bd89724cb03902d9df16bfa70545  fw-col-no-padding">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-gallery clearfix tf-sh-1d33593517b1b180d4918e53ce01a39a fw-gallery-type2  fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <div class="fw-gallery-col fw-col-width1">
                                            <div class="fw-gallery-image fw-height-md fw-block-image-parent fw-overlay-4 overlay_color_1">
                                                <a href="<?php echo e(asset('img/gallaryimage/'.$gallery[0]->img_name)); ?>"
                                                   data-rel="prettyPhoto[fw-gallery-1d33593517b1b180d4918e53ce01a39a]"
                                                   class="fw-block-image-child fw-ratio-container fw-ratio-3-2 ">
                                                    <noscript itemscope itemtype="http://schema.org/ImageObject"
                                                              itemprop="image"><img
                                                                src="<?php echo e(asset('img/gallaryimage/'.$gallery[0]->img_name)); ?>"
                                                                alt="gallery-img-1" data-maxdpr="1.7"
                                                                class="attachment-post-thumbnail lazyload"/>
                                                        <meta itemprop="url"
                                                              content="<?php echo e(asset('img/gallaryimage/'.$gallery[0]->img_name)); ?>">
                                                        <meta itemprop="width" content="570">
                                                        <meta itemprop="height" content="380">
                                                    </noscript>
                                                    <img src="<?php echo e(asset('img/gallaryimage/'.$gallery[0]->img_name)); ?>">
                                                    <div class="fw-block-image-overlay">
                                                        <div class="fw-itable">
                                                            <div class="fw-icell">
                                                                <i class="fw-icon-zoom"></i>
                                                                <h5 class="fw-overlay-title"><?php echo e($gallery[0]->name_am); ?></h5>
                                                                <p class="fw-overlay-description"><?php echo $gallery[0]->description_am; ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="fw-gallery-image fw-height-sm fw-block-image-parent fw-overlay-4 overlay_color_1">
                                                <a href="<?php echo e(asset('img/gallaryimage/'.$gallery[1]->img_name)); ?>"
                                                   data-rel="prettyPhoto[fw-gallery-1d33593517b1b180d4918e53ce01a39a]"
                                                   class="fw-block-image-child fw-ratio-container fw-ratio-16-9 ">
                                                    <noscript itemscope itemtype="http://schema.org/ImageObject"
                                                              itemprop="image"><img
                                                                src="<?php echo e(asset('img/gallaryimage/'.$gallery[1]->img_name)); ?>"
                                                                alt="gallery-img-3" data-maxdpr="1.7"
                                                                class="attachment-post-thumbnail lazyload"/>
                                                        <meta itemprop="url"
                                                              content="<?php echo e(asset('img/gallaryimage/'.$gallery[1]->img_name)); ?>">
                                                        <meta itemprop="width" content="581">
                                                        <meta itemprop="height" content="288">
                                                    </noscript>
                                                    <img src="<?php echo e(asset('img/gallaryimage/'.$gallery[1]->img_name)); ?>"
                                                         data-sizes="auto"
                                                         data-srcset="<?php echo e(asset('img/gallaryimage/'.$gallery[1]->img_name)); ?>"
                                                         alt="gallery-img-3" data-maxdpr="1.7"
                                                         class="attachment-post-thumbnail lazyload"/>
                                                    <div class="fw-block-image-overlay">
                                                        <div class="fw-itable">
                                                            <div class="fw-icell">
                                                                <i class="fw-icon-zoom"></i>
                                                                <h5 class="fw-overlay-title"><?php echo e($gallery[1]->name_am); ?></h5>
                                                                <p class="fw-overlay-description"><?php echo $gallery[1]->description_am; ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="fw-gallery-col fw-col-width1">
                                            <div class="fw-gallery-col fw-col-width2">
                                                <div class="fw-gallery-image fw-height-sm fw-block-image-parent fw-overlay-4 overlay_color_1">
                                                    <a href="<?php echo e(asset('img/gallaryimage/'.$gallery[2]->img_name)); ?>"
                                                       data-rel="prettyPhoto[fw-gallery-1d33593517b1b180d4918e53ce01a39a]"
                                                       class="fw-block-image-child fw-ratio-container fw-ratio-1 ">
                                                        <noscript itemscope itemtype="http://schema.org/ImageObject"
                                                                  itemprop="image"><img
                                                                    src="<?php echo e(asset('img/gallaryimage/'.$gallery[2]->img_name)); ?>"
                                                                    alt="gallery-img-4" data-maxdpr="1.7"
                                                                    class="attachment-post-thumbnail lazyload"/>
                                                            <meta itemprop="url"
                                                                  content="<?php echo e(asset('img/gallaryimage/'.$gallery[2]->img_name)); ?>}">
                                                            <meta itemprop="width" content="288">
                                                            <meta itemprop="height" content="288">
                                                        </noscript>
                                                        <img src="<?php echo e(asset('img/gallaryimage/'.$gallery[2]->img_name)); ?>"
                                                             data-sizes="auto"
                                                             data-srcset="<?php echo e(asset('img/gallaryimage/'.$gallery[2]->img_name)); ?>"
                                                             alt="gallery-img-4" data-maxdpr="1.7"
                                                             class="attachment-post-thumbnail lazyload"/>
                                                        <div class="fw-block-image-overlay">
                                                            <div class="fw-itable">
                                                                <div class="fw-icell">
                                                                    <i class="fw-icon-zoom"></i>
                                                                    <h5 class="fw-overlay-title"><?php echo e($gallery[2]->name_am); ?></h5>
                                                                    <p class="fw-overlay-description"><?php echo $gallery[2]->description_am; ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="fw-gallery-col fw-col-width2">
                                                <div class="fw-gallery-image fw-height-sm fw-block-image-parent fw-overlay-4 overlay_color_1">
                                                    <a href="<?php echo e(asset('img/gallaryimage/'.$gallery[3]->img_name)); ?>"
                                                       data-rel="prettyPhoto[fw-gallery-1d33593517b1b180d4918e53ce01a39a]"
                                                       class="fw-block-image-child fw-ratio-container fw-ratio-1 ">
                                                        <noscript itemscope itemtype="http://schema.org/ImageObject"
                                                                  itemprop="image"><img
                                                                    src="<?php echo e(asset('img/gallaryimage/'.$gallery[3]->img_name)); ?>"
                                                                    alt="gallery-img-5" data-maxdpr="1.7"
                                                                    class="attachment-post-thumbnail lazyload"/>
                                                            <meta itemprop="url"
                                                                  content="<?php echo e(asset('img/gallaryimage/'.$gallery[3]->img_name)); ?>">
                                                            <meta itemprop="width" content="288">
                                                            <meta itemprop="height" content="288">
                                                        </noscript>
                                                        <img src="<?php echo e(asset('img/gallaryimage/'.$gallery[3]->img_name)); ?>"
                                                             data-sizes="auto"
                                                             data-srcset="<?php echo e(asset('img/gallaryimage/'.$gallery[3]->img_name)); ?>"
                                                             alt="gallery-img-5" data-maxdpr="1.7"
                                                             class="attachment-post-thumbnail lazyload"/>
                                                        <div class="fw-block-image-overlay">
                                                            <div class="fw-itable">
                                                                <div class="fw-icell">
                                                                    <i class="fw-icon-zoom"></i>
                                                                    <h5 class="fw-overlay-title"><?php echo e($gallery[3]->name_am); ?></h5>
                                                                    <p class="fw-overlay-description"><?php echo $gallery[3]->description_am; ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="fw-gallery-image fw-height-md fw-block-image-parent fw-overlay-4 overlay_color_1">
                                                <a href="<?php echo e(asset('img/gallaryimage/'.$gallery[4]->img_name)); ?>"
                                                   data-rel="prettyPhoto[fw-gallery-1d33593517b1b180d4918e53ce01a39a]"
                                                   class="fw-block-image-child fw-ratio-container fw-ratio-3-2 ">
                                                    <noscript itemscope itemtype="http://schema.org/ImageObject"
                                                              itemprop="image"><img
                                                                src="<?php echo e(asset('img/gallaryimage/'.$gallery[4]->img_name)); ?>"
                                                                alt="gallery-img-2" data-maxdpr="1.7"
                                                                class="attachment-post-thumbnail lazyload"/>
                                                        <meta itemprop="url"
                                                              content="<?php echo e(asset('img/gallaryimage/'.$gallery[4]->img_name)); ?>">
                                                        <meta itemprop="width" content="570">
                                                        <meta itemprop="height" content="380">
                                                    </noscript>
                                                    <img src="<?php echo e(asset('img/gallaryimage/'.$gallery[4]->img_name)); ?>"
                                                         data-sizes="auto"
                                                         data-srcset="<?php echo e(asset('img/gallaryimage/'.$gallery[4]->img_name)); ?>"
                                                         alt="gallery-img-2" data-maxdpr="1.7"
                                                         class="attachment-post-thumbnail lazyload"/>
                                                    <div class="fw-block-image-overlay">
                                                        <div class="fw-itable">
                                                            <div class="fw-icell">
                                                                <i class="fw-icon-zoom"></i>
                                                                <h5 class="fw-overlay-title"><?php echo e($gallery[4]->name_am); ?></h5>
                                                                <p class="fw-overlay-description"><?php echo $gallery[4]->description_am; ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-a66e76d6c02dadce57d49ae652cc4cf7"
                                 class="fw-col-sm-12 tf-sh-a66e76d6c02dadce57d49ae652cc4cf7">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:60px;"></div>
                                    <div class="text-center"><a href="/admin/gallery" target="_self"
                                                                class="fw-btn tf-sh-3f43835a9ff5b105713c2f4586bcecd6    button-with-bg fw-animated-element fw-btn-4"
                                                                data-animation-type="bounceInUp"
                                                                data-animation-delay="300"
                                                                style="width:135px; height:53px; line-height:53px;">
    <span style="top:0;">
        Find Out More		</span>
                                        </a>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:110px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d05247ef"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  tf-sh-e0a9828e970095ae94f1b8bdd07c4c47 "
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/healthy-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-dac19ac4b9d52f04ca5779a2d02007f4"
                                 class="fw-col-sm-6 tf-sh-dac19ac4b9d52f04ca5779a2d02007f4  fw-animated-element"
                                 data-animation-type="bounceInLeft" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                <span class="my-update update-rigth">
                                    <i class="fa fa-pencil-square-o fa-3x"
                                       aria-hidden="true"
                                       data-toggle="modal"
                                       data-target="#myModal_section4" data-id=""></i>
                                </span>
                                    <div class="fw-divider-space  fw-custom-space  fw-tablet-hide-element clearfix"
                                         style="height:75px;"></div>
                                    <div class="fw-divider-space  fw-custom-space  fw-desktop-hide-element fw-tablet-landscape-hide-element fw-mobile-hide-element clearfix"
                                         style="height:15px;"></div>
                                    <div class="fw-heading fw-heading-left  tf-sh-7be035626b09ca86702be7d5e0cb391f">
                                        <h3 class="fw-special-title"><?php if(session('locale') == 'en'): ?><?php echo e($section4->name_en); ?><?php elseif(session('locale') == 'ru'): ?><?php echo e($section4->name_ru); ?><?php else: ?><?php echo e($section4->name_am); ?><?php endif; ?></h3>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:15px;"></div>
                                    <div class="fw-text-box tf-sh-7a9c9d039fa7ad7be5033804210798b2 ">
                                        <div class="fw-text-inner">
                                            <p><?php echo $section4->description_am; ?></p>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;"></div>
                                    <div class="text-left"><a href="/admin/about" target="_self"
                                                              class="fw-btn tf-sh-aebf947af81a809ce4e96b5a0b0fb78f    button-with-bg fw-btn-4"
                                                              style="width:135px; height:53px; line-height:53px;">
    <span style="top:0;">
        Find Out More		</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div id="column-94f0240640081bc3bb9ffe8d69d13cf9"
                                 class="fw-col-sm-6 tf-sh-94f0240640081bc3bb9ffe8d69d13cf9  fw-animated-element"
                                 data-animation-type="bounceInRight" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:70px;"></div>

                                    <div class="fw-block-image-parent  fw-animated-element fw-block-image-right"
                                         data-animation-type="bounceInUp" data-animation-delay="500"
                                         style="width: 359px; border-style: solid; border-width: 12px; border-color: #ffffff;">
        <span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
            <noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                        src="<?php echo e(asset('wp-content/uploads/2016/06/healthy-img-1.jpg')); ?>" alt="healthy-img-1"
                        data-maxdpr="1.7" width="359" class="lazyload"/><meta itemprop="url"
                                                                              content="<?php echo e(asset('wp-content/uploads/2016/06/healthy-img-1.jpg')); ?>"><meta
                        itemprop="width" content="359"><meta itemprop="height" content="269"></noscript><img
                    src="<?php echo e(asset('img/home/section4/'.$section4->img_name_1)); ?>"
                    data-sizes="auto"
                    data-srcset="<?php echo e(asset('img/home/section4/'.$section4->img_name_1)); ?>"
                    alt="healthy-img-1" data-maxdpr="1.7" width="359"
                    class="lazyload"/>							</span>
                                    </div>


                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-021bc4d3b4209a5b14122aec353e39ce"
                                 class="fw-col-sm-4 fw-mobile-hide-element tf-sh-021bc4d3b4209a5b14122aec353e39ce">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                            <div id="column-b042c1f6c86a29680d6006c82e61321e"
                                 class="fw-col-sm-4 tf-sh-b042c1f6c86a29680d6006c82e61321e">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:30px;"></div>

                                    <div class="fw-block-image-parent image-shadow fw-animated-element fw-block-image-right"
                                         data-animation-type="bounceInUp" data-animation-delay="300"
                                         style="width: 359px; border-style: solid; border-width: 12px; border-color: #ffffff;">
        <span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
            <noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                        src="<?php echo e(asset('wp-content/uploads/2016/06/healthy-img-2.jpg')); ?>" alt="healthy-img-2"
                        data-maxdpr="1.7" width="359" class="lazyload"/><meta itemprop="url"
                                                                              content="<?php echo e(asset('wp-content/uploads/2016/06/healthy-img-2.jpg')); ?>"><meta
                        itemprop="width" content="359"><meta itemprop="height" content="269"></noscript><img
                    src="<?php echo e(asset('img/home/section4/'.$section4->img_name_2)); ?>"
                    data-sizes="auto"
                    data-srcset="<?php echo e(asset('img/home/section4/'.$section4->img_name_2)); ?>"
                    alt="healthy-img-2" data-maxdpr="1.7" width="359"
                    class="lazyload"/>							</span>
                                    </div>


                                </div>
                            </div>
                            <div id="column-f8e57f4698805d8a10a0bd3ea13b637d"
                                 class="fw-col-sm-4 tf-sh-f8e57f4698805d8a10a0bd3ea13b637d">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:30px;"></div>

                                    <div class="fw-block-image-parent image-shadow fw-animated-element fw-block-image-right"
                                         data-animation-type="bounceInUp" data-animation-delay="500"
                                         style="width: 270px; border-style: solid; border-width: 12px; border-color: #ffffff;">
        <span class="fw-block-image-child fw-ratio-4-3 fw-ratio-container">
            <noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                        src="<?php echo e(asset('wp-content/uploads/2016/06/healthy-img-3.jpg')); ?>" alt="healthy-img-3"
                        data-maxdpr="1.7" width="270" class="lazyload"/><meta itemprop="url"
                                                                              content="<?php echo e(asset('wp-content/uploads/2016/06/healthy-img-3.jpg')); ?>"><meta
                        itemprop="width" content="270"><meta itemprop="height" content="202"></noscript><img
                    src="<?php echo e(asset('img/home/section4/'.$section4->img_name_3)); ?>"
                    data-sizes="auto"
                    data-srcset="<?php echo e(asset('img/home/section4/'.$section4->img_name_3)); ?>"
                    alt="healthy-img-3" data-maxdpr="1.7" width="270"
                    class="lazyload"/>							</span>
                                    </div>


                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-ae77e5e08b40a86bc995890ad40ddb27"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-ae77e5e08b40a86bc995890ad40ddb27">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:100px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d05284df"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-0aeea98cd09ee1ef86e69444722a1592 "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                        <span class="my-update">
                                        <i class="fa fa-pencil-square-o fa-3x"
                                           aria-hidden="true"
                                           data-toggle="modal"
                                           data-target="#myModal_section5" data-id=""></i>
                                    </span>
                            <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="column-032e8d7e9ee1c9010631d0f02776344c"
                                     class="fw-col-sm-6 fw-col-md-4 tf-sh-032e8d7e9ee1c9010631d0f02776344c">
                                    <div class="fw-main-row-overlay"></div>
                                    <div class="fw-col-inner">

                                        <div class="fw-iconbox clearfix tf-sh-f40c78660d2639c9794c7cc5f7cfb517 fw-iconbox-2  fw-iconbox-image-type    fw-animated-element"
                                             data-animation-type="bounceInUp" data-animation-delay="300">
                                            <div class="fw-iconbox-image " style="">
                                                <img src="<?php if($val->id == 1): ?><?php echo e(asset('wp-content/uploads/2016/06/apple-icon.png')); ?><?php elseif($val->id == 2): ?><?php echo e(asset('wp-content/uploads/2016/06/cart-icon.png')); ?><?php else: ?><?php echo e(asset('wp-content/uploads/2016/06/cake-icon.png')); ?><?php endif; ?>"
                                                     alt=""/>
                                            </div>

                                            <div class="fw-iconbox-aside">
                                                <div class="fw-iconbox-title">
                                                    <h4><?php echo e($val->name_am); ?></h4>
                                                </div>

                                                <div class="fw-iconbox-text">
                                                    <p><?php echo $val->description_am; ?></p></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            

                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            

                            
                            
                            

                            
                            
                            
                            
                        </div>

                        <div class="fw-row">
                            <div id="column-5a823b963d39c555dfde006f36576b9d"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-5a823b963d39c555dfde006f36576b9d">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:110px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d052a4b7"
                         class=" fw-main-row-custom fw-section-no-padding  auto  fw-mobile-hide-element tf-sh-cf236e5a50277b368b8ca2853d20fa0c "
                         style="   ">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-8fdc7b5ec21e901c4c0dd0778c64d093"
                                 class="fw-col-sm-12 tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093  fw-column-height-custom"
                                 style="height: 5px;">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>
        </div>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
        <!-- /.site-main -->
        <?php echo $__env->make('admin.modal.homesection1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.homesection2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.homesection3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.homesection4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.homesection5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#page"><img
                src="<?php echo e(asset('wp-content/uploads/2016/07/to-top.png')); ?>" alt="to top button"/></a>



    <!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:52:34 GMT -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>