<header class="fw-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
    <div class="fw-header-main">
        <div class="fw-container">
            <div class="fw-wrap-logo">

                <a href="/" class="fw-site-logo">
                    <img src="<?php echo e(asset('wp-content/uploads/2016/07/Logo-2.png')); ?>"
                         alt="Kindergarten WordPress Theme Demo"/>
                </a>

            </div>
            <div class="fw-nav-wrap" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement"
                 role="navigation">
                <nav id="fw-menu-primary" class="fw-site-navigation primary-navigation">
                    <ul id="menu-header-menu" class="fw-nav-menu">
                        <li id="menu-item-438"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-438"><a
                                    href="/"><?php echo e(__('header.home')); ?></a></li>
                        <li id="menu-item-442"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442"><a
                                    href="#0"><?php echo e(__('header.services')); ?></a>
                            <ul class="mega-menu">
                                <?php ($i=0); ?>
                                <?php $__currentLoopData = $ses_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="/services/<?php echo e($url_ser[$i]); ?>"><?php if(session('locale') =='en'): ?><?php echo e($val->name_en); ?><?php elseif(session('locale') =='ru'): ?><?php echo e($val->name_ru); ?><?php else: ?><?php echo e($val->name_am); ?><?php endif; ?></a>
                                    </li>
                                    <?php ($i++); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li id="menu-item-440"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-440"><a
                                    href="/gallery"><?php echo e(__('header.gallery')); ?></a></li>
                        <li id="menu-item-441"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-441"><a
                                    href="/about"><?php echo e(__('header.about')); ?></a></li>
                        <li id="menu-item-439"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-439"><a
                                    href="/contact"><?php echo e(__('header.contact')); ?></a>
                        </li>
                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442">
                            <a href="#0" class=" my-menu"><?php echo e($locale); ?></a>
                            <ul class="dropdown-menu my-dropdown">

                                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-442">
                                        <a rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                           href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                            <?php echo e($properties['native']); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    </ul>

                </nav>


            </div>
        </div>
    </div>
</header>
<style>
    .header-1 .primary-navigation > ul > li > a{
        margin-left: 25px !important;
    }
    .my-menu{
        text-transform: uppercase;
    }
    .my-dropdown{
        position: absolute !important;
        left: 40% !important;
        top: 55% !important;
        margin-top: 10px;
        width: 0px !important;
    }
</style>