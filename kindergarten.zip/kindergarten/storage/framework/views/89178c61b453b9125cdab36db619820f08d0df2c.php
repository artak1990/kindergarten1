<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <form action="/admin/home/update/<?php echo e($val->id); ?>" method="post" enctype="multipart/form-data" id="service_update">
                                <?php echo e(csrf_field()); ?>

                                <input type="file" name="image" id="" data-name="c" class="image"
                                       multiple="multiple"/>
                                <input type="text" name="name_am" id="name_am"  value="<?php echo e($val->name_am); ?>" class="form-control" placeholder="name_am">

                                <input type="text" name="name_en" id="update_name_en" value="<?php echo e($val->name_en); ?>" class="form-control" placeholder="name_en">
                                <input type="text" name="name_ru" id="update_name_ru" value="<?php echo e($val->name_ru); ?>" class="form-control" placeholder="name_ru">
                                <textarea type="text" name="description_am" id="update_description_am" class="form-control"><?php echo $val->description_am; ?></textarea>
                                <textarea type="text" name="description_en" id="update_description_en" class="form-control"><?php echo $val->description_en; ?></textarea>
                                <textarea type="text" name="description_ru" id="update_description_ru" class="form-control"><?php echo $val->description_ru; ?></textarea>
                                <input type="submit">
                            </form>
                        </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

</div>
