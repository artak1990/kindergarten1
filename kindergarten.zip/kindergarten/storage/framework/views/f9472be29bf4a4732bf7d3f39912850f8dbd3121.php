<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="ServiceCategoryModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <div class="modal-body">
                    <form action="admin/serviceCategory/update/" method="post" enctype="multipart/form-data" id="service_update">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="text" name="name" id="update_title">
                        <input type="submit">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

</div>