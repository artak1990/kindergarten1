<?php $__env->startSection('content'); ?>
    <div id="page" class="hfeed site">
        <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($errors->has('description_en') || $errors->has('description_am') || $errors->has('description_ru') || $errors->has('name_am') || $errors->has('name_ru') || $errors->has('name_en')): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Լրացրեք պարտադիր դաշտերը</strong><br>
                    <i class="fa fa-frown-o fa-3x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errors->has('image')): ?>
            <div class="my-all">
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Խնդրում ենք բեռնեք նկարը հետևյալ ֆորմմատներից մեկով
                         jpeg, JPEG, png, PNG, jpg, JPG, gif, svg</strong><br>
                    <i class="fa fa-frown-o fa-3x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
            <div class="my-all">
                <div class="alert alert-success">
                    <a href="#0" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <?php echo e(session()->get('message')); ?><br>
                    <i class="fa fa-smile-o fa-3x" aria-hidden="true"></i>
                </div>
            </div>
        <?php endif; ?>
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d1d92db4"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-913f07399ee5493036a7e6da7a960af9 header-animation-speed"
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/07/page-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-2d172d9318c24a51d826b52791797776"
                                 class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element"
                                 data-animation-type="fadeInUp" data-animation-delay="400">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:180px;"></div>
                                    <span class="my-update">
                                                                <i class="fa fa-pencil-square-o fa-3x my-update"
                                                                   aria-hidden="true"
                                                                   data-toggle="modal"
                                                                   data-target="#hedermodal"></i>
                                                                    </span>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"
                                         data-animation-type="bounceInDown" data-animation-delay="400">
                                        <h2 class="fw-special-title">Gallery</h2>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:240px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1d94431"
                         class=" fw-main-row-custom fw-section-no-padding fw-content-overlay-custom fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-fc6af57adb99b2eefdf30c23f1436531 filter-bg"
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/healthy-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto; margin-bottom:-120px; height: 160px;">
                    <div class="fw-container">
                    </div>
                </section>
                <section id="section-59268d1d961d6"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-0dd7a2a43da99da19f6405ed3c37836e "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-81ac8383a95ad859213f7856e174e038"
                                 class="fw-col-sm-12 tf-sh-81ac8383a95ad859213f7856e174e038 portfolio">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-col-inner">
                                        <div class="tf-sh-7f923af5b4c7841305d2129e26f4357b fw-portfolio fw-portfolio-1 fw-portfolio-cols-3 fw-portfolio-content-position-middle fw-portfolio-content-align-center  fw-portfolio-landscape">
                                            <div class="fw-portfolio-filter">
                                                <ul id="fw-portfolio-filter-59268d1d9954d" class="portfolio_filter"
                                                    data-isotope="1" data-list-id="fw-portfolio-list-59268d1d9954d">
                                                    <li class="categories-item active" data-category="kindergarten"><a
                                                                href="#">Kindergarten</a></li>
                                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="categories-item" data-category="<?php echo e($val->name_en); ?>"><a
                                                                    href="#"><?php if(session('locale')=="en"): ?><?php echo e($val->name_en); ?><?php elseif(session('locale')=="ru"): ?><?php echo e($val->name_ru); ?><?php else: ?><?php echo e($val->name_ru); ?><?php endif; ?></a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                </ul>
                                                <a class="prev" id="fw-portfolio-filter-59268d1d9954d-prev" href="#"><i
                                                            class="fa"></i></a>
                                                <a class="next" id="fw-portfolio-filter-59268d1d9954d-next" href="#"><i
                                                            class="fa"></i></a>
                                            </div>
                                            <div class="row fw-portfolio-wrapper">
                                                <div class="my_div_for_button">
                                                    <button type="button" class="btn btn-info btn-lg"
                                                            data-toggle="modal" data-target="#myModal">Create Gallery
                                                    </button>
                                                </div>
                                                <ul id="fw-portfolio-list-59268d1d9954d"
                                                    class="fw-portfolio-list clearfix" data-columns-number="3">
                                                    <?php $__currentLoopData = $gallary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li data-category="kindergarten,<?php echo e($val->categores->first()['name_en']); ?>">
                                                            <div class="fw-block-image-parent fw-portfolio-image fw-overlay-3">                             <span
                                                                        class="my-update">
                                                                <i class="fa fa-pencil-square-o fa-3x my-update"
                                                                   aria-hidden="true"
                                                                   data-toggle="modal"
                                                                   data-target="#myModal" data-id="<?php echo e($val->id); ?>"></i>
                                                                    </span>
                                                                <span class="delete_update_image delete_section3"
                                                                      href='/admin/gallery/delete/<?php echo e($val->id); ?>'
                                                                      data-toggle="modal" data-target="#Modal">
                                                    <i class="fa fa-trash-o fa-3x"
                                                       aria-hidden="true"></i>
                                                    </span>
                                                                <a class="fw-block-image-child fw-ratio-container fw-ratio-16-9"
                                                                   href="#">
                                                                    <noscript itemscope
                                                                              itemtype="http://schema.org/ImageObject"
                                                                              itemprop="image">
                                                                        <img
                                                                                src="<?php echo e(asset("img/gallaryimage/".$val->img_name)); ?>"
                                                                                alt="portfolio-img-12" data-maxdpr="1.7"
                                                                                class="attachment-post-thumbnail lazyload"/>
                                                                        <meta itemprop="url"
                                                                              content="<?php echo e(asset("wp-content/uploads/2016/06/portfolio-img-12.jpg")); ?>">
                                                                        <meta itemprop="width" content="358">
                                                                        <meta itemprop="height" content="201">
                                                                    </noscript>
                                                                    <img src="<?php echo e(asset('img/gallaryimage/'.$val->img_name)); ?>"
                                                                         data-sizes="auto"
                                                                         data-srcset=""
                                                                         alt="portfolio-img-12" data-maxdpr="1.7"
                                                                         class="attachment-post-thumbnail lazyload"/>
                                                                    <div class="fw-block-image-overlay">
                                                                        <div class="fw-itable">
                                                                            <div class="fw-icell">
                                                                                <div class="fw-overlay-title">
                                                                                    <?php echo e($val->name_am); ?>

                                                                                </div>
                                                                                <input type="hidden" name="_token"
                                                                                       value="<?php echo e(csrf_token()); ?>"
                                                                                       id="token">
                                                                                <div class="fw-overlay-description">
                                                                                    <p><?php echo e($val->description_am); ?></p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                </ul>
                                            </div>
                                        </div><!-- /.fw-portfolio -->
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1db6627"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-190ab61181daf7838041d78d2a2a516a "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-e2196addbd6e0deecf4cf0271b021127"
                                 class="fw-col-sm-12 tf-sh-e2196addbd6e0deecf4cf0271b021127">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:100px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1db98f1"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  tf-sh-6c25df1596a68a41a889f6b6f1f0379a "
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/team-background.jpg')); ?>); background-repeat: no-repeat; background-position: left top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-efbdbe37c0b7b90af8ede6bcf5e57023"
                                 class="fw-col-sm-12 tf-sh-efbdbe37c0b7b90af8ede6bcf5e57023">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:75px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-heading-with-subtitle fw-animated-element tf-sh-826086d450887f165de1eec3f9819135"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h3 class="fw-special-title">Smart Call to Action Title</h3>


                                        <div class="fw-special-subtitle">You can add a subtitle as well</div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;"></div>
                                    <div class="text-center"><a href="/admin/about"
                                                                target="_self"
                                                                class="fw-btn tf-sh-05ca927d3e1ff7faf5172da26129f61d    button-with-bg fw-animated-element fw-btn-4"
                                                                data-animation-type="bounceInUp"
                                                                data-animation-delay="300"
                                                                style="width:178px; height:71px; line-height:71px;">
		<span style="top:0;">
			Don't Miss Out		</span>
                                        </a>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:85px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>


        </div><!-- /.site-main -->
        <?php echo $__env->make('admin.modal.gellary', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.galleryheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin.modal.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Footer -->
        <?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#pa" src="
       <?php echo e(asset("wp-content/uploads/2016/07/to-top.png")); ?>" alt="to top button"/></a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <script>
        $('.my-update').click(function () {
            var id = $(this).attr('data-id')
            var token = $('#token').val()
            $('.modal-title').text('Թարմացնել Նկարը')
            $.ajax
            ({
                url: '/admin/gallery/edit',
                data: {
                    "id": id,
                    '_token': token,
                },
                type: 'post',
                success: function (result) {
                    console.log(result)
                    var url = '/admin/gallery/update/' + result['id']
                    var src = "<?php echo e(asset('img/gallaryimage/')); ?>" + "/" + result['img_name'];
                    $('.my-submit').val('Թարմացնել')
                    $('#service_update').attr('action', url)
                    $('#update_name_am').val(result['name_am'])
                    $('#update_name_en').val(result['name_en'])
                    $('#update_name_ru').val(result['name_ru'])
                    $('#update_description_am').val(result['description_am'])
                    $('#update_description_en').val(result['description_en'])
                    $('#update_description_ru').val(result['description_ru'])
                    $('.category_class').each(function (e) {
                        if ($(this).val() == result['cat_id']) {
                            $(this).attr('selected', true)
                        }
                    })
                    $('#gallery_img').attr('src', src)
                }
            });
        })

        $('.anchor').click(function () {
            $('#service_update').attr('action', '/admin/service/create');
        })
    </script>
    <style>
        .delete_update_image {
            color: red;
            cursor: pointer;
            position: absolute;
            left: 15%;
            z-index: 99999 !important;
            background: #ffffff;
        }

        .my-update {
            z-index: 99999 !important;
            cursor: pointer !important;
            position: absolute !important;
            color: #ffffff !important;
            background: red;
            text-align: center;
        }

        .alert {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            margin: auto;
            z-index: 9999999999999;
            width: 50%;
            height: 150px;
            text-align: center;
        }

        .my-all {
            position: fixed;
            width: 100%;
            height: 100%;
            z-index: 999999999999999999999999999999999999999999999999999999999;
            background: rgba(0,0,0,0.5);
        }


    </style>
    <script>
        $(document).ready(function () {
            $('.delete_update_image').click(function () {
                var href = $(this).attr('href');
                $('#delete_yes').attr('href', href);
            })
            $('.close').click(function () {
                $('.my-all').hide()
            })
        });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.galleryapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>