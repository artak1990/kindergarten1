<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal_section2" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Երկրորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/home/update_section2/1" method="post" enctype="multipart/form-data"
                                  id="service_update">
                                <?php echo e(csrf_field()); ?>

                                <div class="col-md-12">
                                    <input type="file" name="image" id="file" class="input-file oneImageFile" data-image="image5">
                                    <label for="file" class="btn btn-tertiary js-labelFile">
                                        <i class="icon fa fa-check"></i>
                                        <span class="js-fileName">Choose a Image</span>
                                    </label>
                                    <img id="blah" src="<?php echo e(asset('img/home/section2/'.$section2->img_name_1)); ?>" alt="avetis" class="img-rounded display_none" width="100px" data-image="image5" />
                                </div>

                                <div class="col-md-12 section2-div-update">
                                    <label for="">Անուն Հայ*</label>
                                    <input type="text" name="name_am" id="name_am" value="<?php echo e($section2->name_am); ?>"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section2-div-update">
                                    <label for="">Անուն Անգ*</label>
                                    <input type="text" name="name_en" id="update_name_en" value="<?php echo e($section2->name_en); ?>"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section2-div-update">
                                    <label for="">Անուն Ռուս*</label>
                                    <input type="text" name="name_ru" id="update_name_ru" value="<?php echo e($section2->name_ru); ?>"
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section2-div-update">
                                    <label for="">Նկարագրություն Հայ*</label>
                                    <textarea type="text" name="description_am" id="update_description_am"
                                              class="form-control"><?php echo e($section2->description_am); ?></textarea>
                                </div>
                                <div class="col-md-12 section2-div-update">
                                    <label for="">Նկարագրություն Անգ*</label>
                                    <textarea type="text" name="description_en" id="update_description_en"
                                              class="form-control"><?php echo e($section2->description_en); ?></textarea>
                                </div>
                                <div class="col-md-12 section2-div-update">
                                    <label for="">Նկարագրություն Ռուս*</label>
                                    <textarea type="text" name="description_ru" id="update_description_ru"
                                              class="form-control"><?php echo e($section2->description_ru); ?></textarea>
                                </div>
                                <input type="submit" class="form-control" value="Թարմացնել">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>

<style>
    .section2-div-update {
        border: 2px solid;
        padding: 5px;
        margin: 5px;
        border-radius: 5px;
    }
</style>
