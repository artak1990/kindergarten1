<!doctype html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" >

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:52:34 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="xmlrpc.php">
    <meta name="viewport" content="">
    <title>Kids Play | Kindergarten</title>

    <!-- This site is optimized with the Yoast SEO plugin v4.5 - https://yoast.com/wordpress/plugins/seo/ -->
    <link rel="canonical" href="index.html" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="" content="" />
    <meta property="e" content="" />
    <meta name="" content="" />
    <meta name="" content="" />
    <script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/","name":"Kindergarten WordPress Theme Demo","potentialAction":{"@type":"SearchAction","target":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
    <!-- / Yoast SEO plugin. -->

    <link rel='dns-prefetch' href='http://use.typekit.net/' />
    <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Feed" href="<?php echo e(asset("feed/index.html")); ?>" />
    <link rel="alternate" type="application/rss+xml" title="Kindergarten WordPress Theme Demo &raquo; Comments Feed" href="<?php echo e(asset("comments/feed/index.html")); ?>" />
    <link rel='stylesheet' id='layerslider-css'  href='<?php echo e(asset("wp-content/plugins/LayerSlider/static/css/layerslider6fda.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='ls-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css'  href='<?php echo e(asset("wp-content/plugins/revslider/public/assets/css/settings5223.css")); ?>' type='text/css' media='all' />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">

    <style id='rs-plugin-settings-inline-css' type='text/css'>
        #rs-demo-id {}
    </style>
    <link rel='stylesheet' id='woocommerce-layout-css'  href='<?php echo e(asset("wp-content/plugins/woocommerce/assets/css/woocommerce-layout32bb.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php echo e(asset("wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen32bb.css")); ?>' type='text/css' media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' id='woocommerce-general-css'  href='<?php echo e(asset("wp-content/plugins/woocommerce/assets/css/woocommerce32bb.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='parent-style-css'  href='<?php echo e(asset("wp-content/themes/kids-play-parent/style66f2.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css'  href='<?php echo e(asset("wp-content/plugins/unyson/framework/static/libs/font-awesome/css/font-awesome.min9450.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css'  href='<?php echo e(asset("wp-content/themes/kids-play-parent/css/bootstrap4b68.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-mmenu-css'  href='<?php echo e(asset("wp-content/themes/kids-play-parent/css/jquery.mmenu.all4b68.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='kids-play-style-css'  href='<?php echo e(asset("wp-content/uploads/kids-play-style3494.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-theme-style-css'  href='<?php echo e(asset("wp-content/themes/kids-play-child/style4b68.css")); ?>' type='text/css' media='all' />


    <link rel="stylesheet" href="<?php echo e(asset('css/homestyle.css')); ?>">





    <link rel='stylesheet' id='prettyPhoto-css'  href='<?php echo e(asset("wp-content/themes/kids-play-parent/css/prettyPhoto4b68.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='animate-css'  href='<?php echo e(asset("wp-content/themes/kids-play-parent/css/animate4b68.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='<?php echo e(asset("wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/background66f2.css")); ?>' type='text/css' media='all' />
    
    
    <link rel='stylesheet' id='fw-googleFonts-css'  href='https://fonts.googleapis.com/css?family=Amatic+SC%3A700%7CNoto+Serif%3A700%2Cregular%2Citalic%2C700italic%7CNTR%3Aregular%7CNoto+Sans%3A700%7CMontserrat%3A700%2Cregular%7CQuattrocento+Sans%3A700%7CMerriweather%3A700&amp;subset=latin&amp;ver=4.7.5' type='text/css' media='all' />


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    

    <script type='text/javascript' src='<?php echo e(asset("wp-content/plugins/LayerSlider/static/js/greensockcd11.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-includes/js/jquery/jqueryb8ff.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-includes/js/jquery/jquery-migrate.min330a.js")); ?>'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var LS_Meta = {"v":"5.6.9"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/plugins/LayerSlider/static/js/layerslider.kreaturamedia.jquery6fda.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/plugins/LayerSlider/static/js/layerslider.transitions6fda.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min5223.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min5223.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/themes/kids-play-parent/js/lib/bootstrap.min4b68.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/themes/kids-play-parent/js/jquery.touchSwipe.min4b68.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/themes/kids-play-parent/js/lib/html5shiv4b68.js")); ?>'></script>
    <script type='text/javascript' src='<?php echo e(asset("wp-content/themes/kids-play-parent/js/lib/respond.min4b68.js")); ?>'></script>
    <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
    <meta name="generator" content="Powered by LayerSlider 5.6.9 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
    <!-- LayerSlider updates and docs at: https://kreaturamedia.com/layerslider-responsive-wordpress-slider-plugin/ -->
    <link rel='https://api.w.org/' href='<?php echo e(asset("wp-json/index.htm")); ?>l' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo e(asset("xmlrpc0db0.php?rsd")); ?>" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo e(asset("wp-includes/wlwmanifest.xml")); ?>" />
    <meta name="" content="" />
    <meta name="" content="" />
    <link rel='shortlink' href='index.html' />
    <link rel="alternate" type="application/json+oembed" href="<?php echo e(asset("wp-json/oembed/1.0/embededca.json?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2F")); ?>" />
    <link rel="alternate" type="text/xml+oembed" href="<?php echo e(asset("wp-json/oembed/1.0/embed3eec?url=https%3A%2F%2Fdemo.themefuse.com%2Fkindergarten-wordpress-theme%2F&amp;format=xml")); ?>" />
    <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
    <meta name="generator" content="Powered by Slider Revolution 5.2.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
</head>
<body class="home page-template page-template-visual-builder-template page-template-visual-builder-template-php page page-id-6 fw-full fw-website-align-center fw-section-space-md header-1 fw-top-bar-off fw-absolute-header fw-top-social-right  fw-top-logo-left fw-logo-image fw-logo-retina fw-animation-mobile-off tf-static-ribbon-bar" itemscope="itemscope" itemtype="http://schema.org/WebPage">




<?php echo $__env->yieldContent('content'); ?>






        
        
            
        
    


    
    
    




    
        
    
    
    



    
        
        
                    
                
        
                
        
        
        
    

    
    
    

    
    

    
    



    
        
        
        
        
        
    
    
    
    
        
            
        
    



    
        
                
        
        
        
        
        
        
        
        
        
        
        
        
            
            
            
        
    



    
        
    




    
            
        
        
            
    
    
    
        
        
    






<script type="text/javascript">
    function revslider_showDoubleJqueryError(sliderID) {
        var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
        errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
        errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
        errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
        errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
        jQuery(sliderID).show().html(errorMessage);
    }
</script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var wc_add_to_cart_params = {"ajax_url":"\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kindergarten-wordpress-theme\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme","is_cart":"","cart_redirect_after_add":"no"};
    /* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min32bb.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js')); ?>'></script>

    
    
    

<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min32bb.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js')); ?>'></script>

    
    
    

<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min32bb.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lib/modernizr.min4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.carouFredSel-6.2.1-packed4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.prettyPhoto4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.customInput4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/scrollTo.min4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.mmenu.min.all4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/selectize.min4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/jquery.parallax4b68.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-includes/js/jquery/ui/effect.mine899.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/lazysizes.min4b68.js')); ?>'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var FwPhpVars = {"ajax_url":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-admin\/admin-ajax.php","template_directory":"https:\/\/demo.themefuse.com\/kindergarten-wordpress-theme\/wp-content\/themes\/kids-play-parent","previous":"Previous","next":"Next","smartphone_animations":"no","header_5_position":"left","header_6_position":"left","effect_panels":"","effect_listitems_slide":"","fail_form_error":"Sorry you are an error in ajax, please contact the administrator of the website","socials":""};
    /* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/themes/kids-play-parent/js/general4b68.js?ver=1.0.4')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core66f2.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition66f2.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background66f2.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init66f2.js')); ?>'></script>






<script type='text/javascript' src='<?php echo e(asset('wp-includes/js/wp-embed.min66f2.js')); ?>'></script>
<style>
    .for-owl-carusel{
        width: 100% !important;
    }
    .section1-update {
        top: 25% !important;
        right: 5% !important;
        z-index: 99999 !important;
        cursor: pointer !important;
        position: absolute !important;
        color: #ffffff !important;
    }

    .my-update {
        z-index: 99999 !important;
        cursor: pointer !important;
        position: absolute !important;
        color: #ffffff !important;
        background: red;
        text-align: center;
    }

    .update-rigth{
        top: 30% !important;
        right: 3% !important;
    }
    .update-left{
        top: 10% !important;
        left: 25% !important;
    }
    .my-all {
        position: fixed;
        width: 100%;
        height: 100%;
        z-index: 999999999999999999999999999999999999999999999999999999999;
        background: rgba(0,0,0,0.5);
    }



    .delete_section3 {
        top: 10% !important;
        left: 65% !important;
        z-index: 99999 !important;
        cursor: pointer !important;
        position: absolute !important;
        color: red !important;
        background: #FFFFFF;
    }
    .my-create {
        cursor: pointer;
        color: #ffffff;
        text-decoration: underline;
    }

    .owl-prev{
        position: absolute;
        top: 25%;
        color: red;
        text-transform: capitalize;
    }
    .owl-next{
        position: absolute;
        top: 25%;
        right: 0;
        color: red;
        text-transform: capitalize;
    }
     .alert{
         position: fixed;
         top:0;
         left:0;
         right: 0;
         bottom:0;
         margin: auto;
         z-index: 9999999999999;
         width: 50%;
         height: 150px;
         text-align: center;
     }

</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>

<script>
    $('.section3-update').click(function () {
        var id = $(this).attr('data-id')
        var token = $('#token').val()
        $('.modal-title').text('Թարմացնել Աշխատակցին')
        $.ajax
        ({
            url: '/admin/home/edit_section3',
            data: {
                "id": id,
                '_token': token,
            },
            type: 'post',
            success: function (result) {
                console.log(result['name_am'])
                var url = '/admin/home/update_section3/' + result['id']
                var src = "<?php echo e(asset('img/home/section3')); ?>"+"/"+result['img_name'];
                $('.my-submit').val('Թարմացնել')
                $('#home_update').attr('action', url)
                $('#section3_name_am').val(result['name_am'])
                $('#section3_name_en').val(result['name_en'])
                $('#section3_name_ru').val(result['name_ru'])
                $('#section3_description_am').val(result['description_am'])
                $('#section3_description_en').val(result['description_en'])
                $('#section3_description_ru').val(result['description_ru'])
                $('#section3_staff_am').val(result['staff_am'])
                $('#section3_staff_en').val(result['staff_en'])
                $('#section3_staff_ru').val(result['staff_ru'])
                $('#img_section3').attr('src', src)
            }
        });
    });

    $('.my-create').click(function () {
        $('#home_update').attr('action', '/admin/home/create_section3')
        $('#section3_name_am').val('')
        $('#section3_name_en').val('')
        $('#section3_name_ru').val('')
        $('#section3_description_am').val('')
        $('#section3_description_en').val('')
        $('#section3_description_ru').val('')
        $('#section3_staff_am').val('')
        $('#section3_staff_en').val('')
        $('#section3_staff_ru').val('')
    })

    $(document).ready(function() {

        $("#owl-demo").owlCarousel({
            items : 3,
            lazyLoad : true,
            navigation : true
        });
        $('.close').click(function () {
            $('.my-all').hide()
        })

    });
</script>
<script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<script src="<?php echo e(asset('js/init.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<script>
    $(document).ready(function () {
        $('.delete_update_image').click(function () {
            var href = $(this).attr('href');
            $('#delete_yes').attr('href', href);
        })
    });
</script>
</body>

<!-- Mirrored from demo.themefuse.com/kindergarten-wordpress-theme/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 May 2017 07:52:34 GMT -->
</html>