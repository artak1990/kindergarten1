<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal_section5" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Հինգերորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/home/update_section5" method="post" enctype="multipart/form-data"
                                  id="service_update">
                                <?php echo e(csrf_field()); ?>

                                <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <label for="">Անուն Հայ*</label>
                                    <input type="text" name="name_am[]" id="name_am" value="<?php echo e($val->name_am); ?>"
                                           class="form-control" >
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <label for="">Անուն Անգ*</label>
                                    <input type="text" name="name_en[]" id="update_name_en" value="<?php echo e($val->name_en); ?>"
                                           class="form-control" >
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <label for="">Անուն Ռուս*</label>
                                    <input type="text" name="name_ru[]" id="update_name_ru" value="<?php echo e($val->name_ru); ?>"
                                           class="form-control" >
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <label for="">Նկարագրություն Հայ*</label>
                                    <textarea type="text" name="description_am[]" id="update_description_am"
                                              class="form-control"><?php echo $val->description_am; ?></textarea>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <label for="">Նկարագրություն Անգ*</label>
                                    <textarea type="text" name="description_en[]" id="update_description_en"
                                              class="form-control"><?php echo $val->description_en; ?></textarea>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $section5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <label for="">Նկարագրություն Ռուս*</label>
                                    <textarea type="text" name="description_ru[]" id="update_description_ru"
                                              class="form-control"><?php echo $val->description_ru; ?></textarea>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="submit" class="form-control" value="Թարմացնել">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>