<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal_section3" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Ավելացնել աշխատակից</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/home/create_section3" method="post" enctype="multipart/form-data"
                                  id="home_update">
                                <?php echo e(csrf_field()); ?>

                                <div class="col-md-12">
                                    <input type="file" name="image" id="file6" class="input-file oneImageFile" data-image="image6">
                                    <label for="file6" class="btn btn-tertiary js-labelFile">
                                        <i class="icon fa fa-check"></i>
                                        <span class="js-fileName">Choose a Image</span>
                                    </label>
                                    <img id="img_section3" src="" alt="avetis" class="img-rounded display_none" width="100px" data-image="image6" />
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Անուն Հայ*</label>
                                    <input type="text" name="name_am" id="section3_name_am" value=""
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Անուն Անգ*</label>
                                    <input type="text" name="name_en" id="section3_name_en" value=""
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Անուն Ռուս*</label>
                                    <input type="text" name="name_ru" id="section3_name_ru" value=""
                                           class="form-control" >
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Պաշտոն Հայ*</label>
                                    <input type="text" name="staff_am" id="section3_staff_am" class="form-control"
                                           >
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Պաշտոն Անգ*</label>
                                    <input type="text" name="staff_en" id="section3_staff_en" class="form-control"
                                          >
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Պաշտոն Ռուս*</label>
                                    <input type="text" name="staff_ru" id="section3_staff_ru" class="form-control"
                                          >
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Նկարագրություն Հայ*</label>
                                    <textarea type="text" name="description_am" id="section3_description_am"
                                              class="form-control"></textarea>
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Նկարագրություն Անգ*</label>
                                    <textarea type="text" name="description_en" id="section3_description_en"
                                              class="form-control"></textarea>
                                </div>
                                <div class="col-md-12 section3-div-update">
                                    <label for="">Նկարագրություն Ռուս*<Rus></Rus></label>
                                    <textarea type="text" name="description_ru" id="section3_description_ru"
                                              class="form-control"></textarea>
                                </div>
                                <input type="submit" class="form-control my-submit" value="Ավելացնել">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>

<style>
    .section3-div-update {
        border: 2px solid;
        padding: 5px;
        margin: 5px;
        border-radius: 5px;
    }
</style>
