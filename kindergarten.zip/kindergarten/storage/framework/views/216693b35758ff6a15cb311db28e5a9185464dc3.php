<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="section3Modal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Հինգերորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/about/update_section3/1" method="post"  id="service_update">
                                <?php echo e(csrf_field()); ?>

                                <div class="my_div_parent">
                                    <div class="col-md-12 my_div">
                                        <div class="col-md-4">
                                            <label for="title_am">Վերնագիր Հայ*</label>
                                            <input type="text" name="name_am" value='<?php echo e($section3->name_am); ?>' class="form-control" id="title_am">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="title_en">Վերնագիր Անգ*</label>
                                            <input type="text" name="name_en" value='<?php echo e($section3->name_en); ?>' class="form-control" id="title_en">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="title_ru">Վերնագիր Ռուս*</label>
                                            <input type="text" name="name_ru" value='<?php echo e($section3->name_ru); ?>' class="form-control" id="title_ru" >
                                        </div>
                                    </div>
                                    <div class="col-md-12 my_div">
                                        <div class="col-md-4">
                                            <label for="">Ենթավերնագիր Հայ*</label>
                                            <input type="text" name="tour_am" value="<?php echo e($section3->tour_am); ?>" class="form-control" >
                                        </div>
                                        <div class="col-md-4">
                                            <label for="name_en">Ենթավերնագիր Անգ*</label>
                                            <input type="text" name="tour_en" value="<?php echo e($section3->tour_en); ?>" class="form-control" >
                                        </div>
                                        <div class="col-md-4">
                                            <label for="name_ru">Ենթավերնագիր Ռուս*</label>
                                            <input type="text" name="tour_ru" value="<?php echo e($section3->tour_ru); ?>" class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="name_ru">Նկարագրություն Հայ*</label>
                                    <textarea name="description_am" id="" cols="" rows=""><?php echo $section3->description_am; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="name_ru">Նկարագրություն Անգ*</label>
                                    <textarea name="description_en" id="" cols="" rows=""><?php echo $section3->description_en; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Նկարագրություն Ռուս*</label>
                                    <textarea name="description_ru" id="" cols="" rows=""><?php echo $section3->description_ru; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Տեսանյութի հղում*</label>
                                    <input type="text" value="<?php echo e($section3->video_src); ?>" name='video_src' class="form-control">
                                </div>
                                <div class="col-md-12">
                                    <input type="submit" value="Թարմացնել" class="form-control">
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
