<h4>FirstName : <?php echo e($data->firstname); ?></h4>
<h4>LastName : <?php echo e($data->lastname); ?></h4>
<h4>Email Address : <?php echo e($data->email); ?></h4>
<h4>Phone Number : <?php echo e($data->phone); ?></h4>
<h4>Message : <?php echo e($data->message); ?></h4>