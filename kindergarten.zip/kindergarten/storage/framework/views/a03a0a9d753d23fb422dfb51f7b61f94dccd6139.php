<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="section4Modal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Չորորդ բաժնի թարմացում</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="/admin/about/update_section4/1" method="post" id="service_update"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="my_div_parent">
                                    <div class="col-md-12">
                                        <input type="file" name="image" id="file12" class="input-file oneImageFile"
                                               data-image="image">
                                        <label for="file12" class="btn btn-tertiary js-labelFile">
                                            <i class="icon fa fa-check"></i>
                                            <span class="js-fileName">Choose a Image</span>
                                        </label>
                                        <img id="img12" src="<?php echo e(asset('img/about/section4/'.$section4->img_name)); ?>"
                                             alt="avetis" class="img-rounded display_none" width="100px"
                                             data-image="image"/>
                                    </div>
                                    <div class="col-md-12 my_div">
                                        <div class="col-md-4">
                                            <label for="title_am">Վերնագիր Հայ*</label>
                                            <input type="text" name="name_am" value='<?php echo e($section4->name_am); ?>'
                                                   class="form-control" id="title_am">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="title_en">Վերնագիր Անգ*</label>
                                            <input type="text" name="name_en" value='<?php echo e($section4->name_en); ?>'
                                                   class="form-control" id="title_en">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="title_ru">Վերնագիր Ռուս*</label>
                                            <input type="text" name="name_ru" value='<?php echo e($section4->name_ru); ?>'
                                                   class="form-control" id="title_ru">
                                        </div>
                                    </div>
                                    <div class="col-md-12 my_div">
                                        <div class="col-md-4">
                                            <label for="">Աշխատակից Հայ*</label>
                                            <input type="text" name="user_am" value="<?php echo e($section4->user_am); ?>"
                                                   class="form-control">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="name_en">Աշխատակից Անգ*</label>
                                            <input type="text" name="user_en" value="<?php echo e($section4->user_en); ?>"
                                                   class="form-control">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="name_ru">Աշխատակից Ռուս*</label>
                                            <input type="text" name="user_ru" value="<?php echo e($section4->user_ru); ?>"
                                                   class="form-control">
                                        </div>

                                    </div>
                                    <div class="col-md-12 my_div">
                                        <div class="col-md-4">
                                            <label for="">Պաշտոն Հայ*</label>
                                            <input type="text" name="staff_am" value="<?php echo e($section4->staff_am); ?>"
                                                   class="form-control">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="name_en">Պաշտոն Անգ*</label>
                                            <input type="text" name="staff_en" value="<?php echo e($section4->staff_en); ?>"
                                                   class="form-control">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="name_ru">Պաշտոն Ռուս*</label>
                                            <input type="text" name="staff_ru" value="<?php echo e($section4->staff_ru); ?>"
                                                   class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="name_ru">Նկարագրություն Հայ*</label>
                                    <textarea name="description_am" id="" cols=""
                                              rows=""><?php echo $section4->description_am; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="name_ru">Նկարագրություն Անգ*</label>
                                    <textarea name="description_en" id="" cols=""
                                              rows=""><?php echo $section4->description_en; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Նկարագրություն Ռուս*</label>
                                    <textarea name="description_ru" id="" cols=""
                                              rows=""><?php echo $section4->description_ru; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Մեկնաբանություն Հայ*</label>
                                    <textarea name="comment_am" id="" cols=""
                                              rows=""><?php echo $section4->comment_am; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Մեկնաբանություն Անգ*</label>
                                    <textarea name="comment_en" id="" cols=""
                                              rows=""><?php echo $section4->comment_en; ?></textarea>
                                </div>
                                <div class="col-md-12 my_div">
                                    <label for="">Մեկնաբանություն Ռուս*</label>
                                    <textarea name="comment_ru" id="" cols=""
                                              rows=""><?php echo $section4->comment_ru; ?></textarea>
                                </div>

                                <div class="col-md-12">
                                    <input type="submit" value="Թարմացնել" class="form-control">
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">x</button>
                </div>
            </div>

        </div>
    </div>

</div>
