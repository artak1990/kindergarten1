<?php $__env->startSection('content'); ?>
    <div id="page" class="hfeed site">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="main" class="site-main">
            <div class="fw-page-builder-content">
                <section id="section-59268d1baf7ae"
                         class=" fw-main-row-custom fw-main-row-top fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image fw-section-height-custom  tf-sh-05b5a5c1d0129a8a2e9623881c9fbdde header-animation-speed"
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/07/page-background.jpg')); ?>); background-repeat: no-repeat; background-position: center top; background-size: auto;  height: 536px;">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-2d172d9318c24a51d826b52791797776"
                                 class="fw-col-sm-12 tf-sh-2d172d9318c24a51d826b52791797776 remove-on-mobile fw-animated-element"
                                 data-animation-type="fadeInUp" data-animation-delay="400">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:180px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-animated-element tf-sh-f5bee444c0ced6516d9f98afb301ef10"
                                         data-animation-type="bounceInDown" data-animation-delay="400">
                                        <h2 class="fw-special-title"><?php echo e(__('about.about')); ?></h2>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:240px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1ebeb92"
                         class=" fw-main-row-custom fw-section-no-padding  fw_theme_bg_fw-custom fw-section-image auto  fw-mobile-hide-element tf-sh-63e2c55f32cf8f8333d9731bd96e0fb3 "
                         style="  background-image:url(<?php echo e(asset('wp-content/uploads/2016/06/healthy-background.jp')); ?>g); background-repeat: no-repeat; background-position: center top; background-size: auto;  ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-dd4110937ca34c70203a283cfe3290d4"
                                 class="fw-col-sm-8 fw-col-md-6 tf-sh-dd4110937ca34c70203a283cfe3290d4">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-9dd5f5258e41e9e49e9e6e8572ffeb40  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="<?php echo e(asset('wp-content/uploads/2016/07/mail-icon.png')); ?>" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                <?php echo e(__('about.address')); ?> </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-d58472aa7c5dd66cf1c8faf42755eccb"
                                 class="fw-col-sm-4 fw-col-md-3 tf-sh-d58472aa7c5dd66cf1c8faf42755eccb">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-78e8669f6752f2fd02ef70707a9a8630  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="<?php echo e(asset('wp-content/uploads/2016/07/call-icon.png')); ?>" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                +374 10 272272 </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                            <div id="column-52ab08806e8670224e46a34b24da472f"
                                 class="fw-tablet-hide-element fw-col-sm-3 fw-tablet-landscape-hide-element tf-sh-52ab08806e8670224e46a34b24da472f">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                    <div class="fw-icon-title fw-icon-title-left clearfix tf-sh-60db5ea8816ddda26c75e85b31c9e362  fw-content-align-center">
                                        <div class="fw-icon-title-name">
							<span class="fw-icon-title-icon fw-custom-icon-image">
											<img src="<?php echo e(asset('wp-content/uploads/2016/07/around-icon.png')); ?>" alt=""/>									</span>

                                            <h6 class="fw-icon-title-text">
                                                <?php echo e(__('about.email')); ?> </h6>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:55px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1bb5a6d"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-2ed4da5076feb984ba6fb8c8fdc4b6a2 "
                         style="   ">
                    <div class="fw-container">
                        <div class="fw-row">
                            <div id="column-e2756c36a681f1d487527e3c54397127"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-e2756c36a681f1d487527e3c54397127">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:105px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-6f9e00862602620bc77d9cb796f60971"
                                 class="fw-col-sm-6 tf-sh-6f9e00862602620bc77d9cb796f60971  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">


                                    <div class="fw-block-image-parent image-shadow fw-block-image-right"
                                         style="width: 360px; border-style: solid; border-width: 12px; border-color: #ffffff;">
			<span class="fw-block-image-child fw-ratio-3-2 fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                            src="<?php echo e(asset('wp-content/uploads/2016/06/gallery-img-1.jpg')); ?>" alt="gallery-img-1"
                            data-maxdpr="1.7" width="360" class="lazyload"/><meta itemprop="url"
                                                                                  content="<?php echo e(asset('wp-content/uploads/2016/06/gallery-img-1.jpg')); ?>"><meta
                            itemprop="width" content="570"><meta itemprop="height" content="380"></noscript><img
                        src="<?php echo e(asset('img/about/section1/'.$section1->img_name)); ?>"
                        data-sizes="auto"
                        data-srcset="<?php echo e(asset('img/about/section1/'.$section1->img_name)); ?>"
                        alt="gallery-img-1" data-maxdpr="1.7" width="360" class="lazyload"/>							</span>
                                    </div>


                                </div>
                            </div>
                            <div id="column-4913e21794c318781dfcbdc122893e83"
                                 class="fw-col-sm-6 tf-sh-4913e21794c318781dfcbdc122893e83  fw-animated-element fw-col-no-padding"
                                 data-animation-type="bounceInUp" data-animation-delay="500">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:10px;"></div>
                                    <div class="fw-heading fw-heading-left  tf-sh-8b50891d89f5b2a827167faad435c161">
                                        <h3 class="fw-special-title"><?php if(session('locale')=='en'): ?><?php echo e($section1->name_en); ?><?php elseif(session('locale')=='ru'): ?><?php echo e($section1->name_ru); ?><?php else: ?><?php echo e($section1->name_am); ?><?php endif; ?><img
                                                    src="<?php echo e(asset('wp-content/uploads/2016/06/arrow.png')); ?>"></h3>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:15px;"></div>
                                    <div class="fw-text-box tf-sh-0e39766cb8b7ecfcb94a851ba1d97683 ">
                                        <div class="fw-text-inner">
                                            <p><?php if(session('locale')=='en'): ?><?php echo $section1->description_en; ?><?php elseif(session('locale')=='ru'): ?><?php echo $section1->description_ru; ?><?php else: ?><?php echo $section1->description_am; ?><?php endif; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-664e3a73583516370c51537d6e56a304"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-664e3a73583516370c51537d6e56a304">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:105px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-2f51c33ca14d2da5b76f2476bbac05ea"
                                 class="fw-tablet-hide-element fw-col-sm-2 fw-mobile-hide-element tf-sh-2f51c33ca14d2da5b76f2476bbac05ea">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                            <div id="column-536a6fb1d528935ea975b9e94e715f86"
                                 class="fw-col-sm-12 fw-col-md-8 tf-sh-536a6fb1d528935ea975b9e94e715f86  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:58px;"></div>
                                    <div class="fw-heading fw-heading-center  tf-sh-703f4d453435e71e9d60ae33c7e8fe6d">
                                        <h2 class="fw-special-title"><img
                                                    src="<?php echo e(asset('wp-content/uploads/2016/06/arrow-left-yellow.png')); ?>"><?php if(session('locale')=='en'): ?><?php echo e($section2_1->title_en); ?><?php elseif(session('locale')=='ru'): ?><?php echo e($section2_1->title_ru); ?><?php else: ?><?php echo e($section2_1->title_am); ?><?php endif; ?></h2>


                                    </div>
                                    <div class="fw-list upload-icon  tf-sh-5708520161f322f75ebb29f1a07df424 list-padding">
                                        <ul>

                                            <?php $__currentLoopData = $section2_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><img src="<?php echo e(asset('wp-content/uploads/2016/06/list-item-check.png')); ?>"
                                                     style="width:25px;"/>
                                                <a href="#" target="_self"> <?php if(session('locale')=='en'): ?><?php echo e($val->name_en); ?><?php elseif(session('locale')=='ru'): ?><?php echo e($val->name_ru); ?><?php else: ?><?php echo e($val->name_am); ?><?php endif; ?></a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                                     
                                                
                                                    
                                            


                                            
                                                     
                                                
                                                    
                                            


                                            
                                                     
                                                
                                                    
                                            

                                        </ul>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:70px;"></div>
                                </div>
                            </div>
                            <div id="column-e771f7e68a67903335e53553b5e7faec"
                                 class="fw-tablet-hide-element fw-col-sm-2 fw-mobile-hide-element tf-sh-e771f7e68a67903335e53553b5e7faec">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-1671b4dcb6631a12c5f9db624e927fcd"
                                 class="fw-col-sm-12 fw-mobile-hide-element tf-sh-1671b4dcb6631a12c5f9db624e927fcd">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:100px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-c1172f84b057618344938f53799e964b"
                                 class="fw-col-sm-12 fw-col-md-6 tf-sh-c1172f84b057618344938f53799e964b  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-heading fw-heading-left  tf-sh-41e6a95f5b09fba46c076e70d20ab63b">
                                        <h3 class="fw-special-title"><?php if(session('locale')=='en'): ?><?php echo e($section4->name_en); ?><?php elseif(session('locale')=='ru'): ?><?php echo e($section4->name_ru); ?><?php else: ?><?php echo e($section4->name_am); ?><?php endif; ?><img
                                                    src="<?php echo e(asset('wp-content/uploads/2016/06/arrow.png')); ?>"></h3>


                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:30px;"></div>
                                    <div class="fw-text-box tf-sh-f38fceec85bac779f18b3b7b8b6c8f46 ">
                                        <div class="fw-text-inner">
                                            <p><?php if(session('locale')=='en'): ?><?php echo $section4->description_en; ?><?php elseif(session('locale')=='ru'): ?><?php echo $section4->description_ru; ?><?php else: ?><?php echo $section4->description_am; ?><?php endif; ?></p>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:50px;"></div>
                                    
                                                              
                                                              
		
			
                                        
                                    
                                </div>
                            </div>
                            <div id="column-7788bb81096f1deafda8d8ca11250c90"
                                 class="fw-col-sm-12 fw-col-md-6 tf-sh-7788bb81096f1deafda8d8ca11250c90 remove-on-mobile fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="500">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-text-box tf-sh-09d1cc38a4b5113f7b6a7c24d1c6e78a quote-bubble">
                                        <div class="fw-text-inner">
                                            <p style="text-align: center;"><?php if(session('locale')=='en'): ?><?php echo $section4->comment_en; ?><?php elseif(session('locale')=='ru'): ?><?php echo $section4->comment_ru; ?><?php else: ?><?php echo $section4->comment_am; ?><?php endif; ?></p>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:130px;"></div>
                                    <div class="fw-iconbox clearfix tf-sh-912eaf7209500ab3023263f7b239e0a8 fw-iconbox-2  fw-iconbox-image-type   founder-icon-img">
                                        <div class="fw-iconbox-image " style="">
                                            <img src="<?php echo e(asset('img/about/section4/'.$section4->img_name)); ?>" alt=""/>
                                        </div>

                                        <div class="fw-iconbox-aside">
                                            <div class="fw-iconbox-title">
                                                <h5><?php if(session('locale')=='en'): ?><?php echo e($section4->user_en); ?><?php elseif(session('locale')=='ru'): ?><?php echo e($section4->user_ru); ?><?php else: ?><?php echo e($section4->user_am); ?><?php endif; ?></h5>
                                            </div>

                                            <div class="fw-iconbox-text">
                                                <p><?php if(session('locale')=='en'): ?><?php echo e($section4->staff_en); ?><?php elseif(session('locale')=='ru'): ?><?php echo e($section4->staff_ru); ?><?php else: ?><?php echo e($section4->staff_am); ?><?php endif; ?></p></div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-0eae44a465347ef8489a90e66f767f17"
                                 class="fw-col-sm-12 tf-sh-0eae44a465347ef8489a90e66f767f17  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:70px;"></div>

                                    <div class="fw-block-image-parent  fw-block-image-center" style="width: 800px; ">
			<span class="fw-block-image-child fw-noratio fw-ratio-container">
				<noscript itemscope itemtype="http://schema.org/ImageObject" itemprop="image"><img
                            src="<?php echo e(asset('wp-content/uploads/2016/06/separator.png')); ?>" alt="separator"
                            data-maxdpr="1.7" width="800" class="lazyload"/><meta itemprop="url"
                                                                                  content="<?php echo e(asset('wp-content/uploads/2016/06/separator.png')); ?>"><meta
                            itemprop="width" content="800"><meta itemprop="height" content="24"></noscript><img
                        src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-sizes="auto"
                        data-srcset="https://demo.themefuse.com/kindergarten-wordpress-theme/wp-content/uploads/2016/06/separator.png 800w"
                        alt="separator" data-maxdpr="1.7" width="800" class="lazyload"/><span class="fw-after-no-ratio"
                                                                                              style="padding-bottom: 3%"></span>							</span>
                                    </div>


                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:70px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1bc064f"
                         class=" fw-main-row-custom fw-section-no-padding  auto  tf-sh-ab954dd47daca13435c4d4cfe4f7cc13 "
                         style="   ">
                    <div class="fw-container" style="background-color:#272220;">
                        <div class="fw-row">
                            <div id="column-7472f070d1e2cd8514e9a0e9015a5b48"
                                 class="fw-col-sm-12 tf-sh-7472f070d1e2cd8514e9a0e9015a5b48">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:90px;"></div>
                                    <div class="fw-heading fw-heading-center  fw-heading-with-subtitle fw-animated-element tf-sh-e566239ef6971b47ff3dbf8963e86f9c"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <h2 class="fw-special-title"><img
                                                    src="<?php echo e(asset('wp-content/uploads/2016/06/arrow-left.png')); ?>"><?php echo e($section3->name_am); ?>

                                        </h2>


                                        <div class="fw-special-subtitle">    <?php echo e($section3->tour_am); ?></div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:55px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-38adb2eda57f6c7df192927947989625"
                                 class="fw-col-sm-12 tf-sh-38adb2eda57f6c7df192927947989625  fw-animated-element"
                                 data-animation-type="bounceInUp" data-animation-delay="300">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-video tf-sh-fa58468575d67d12ec6a888aefdab56e video-box-shadow">
                                        <div class="fw-wrap-boxed-media fw-wp-embed-shortcode">
                                            <iframe src="<?php echo e($section3->video_src); ?>" width="690"
                                                    height="388" frameborder="0" title="Color Modulation Transmitter"
                                                    webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-aa823c396d6b13a2da892590f311fc1b"
                                 class="fw-col-sm-12 tf-sh-aa823c396d6b13a2da892590f311fc1b">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:45px;"></div>
                                    <div class="fw-text-box tf-sh-49a070880cfdd1c44e8c607e5e89dab8  fw-animated-element"
                                         data-animation-type="bounceInUp" data-animation-delay="300">
                                        <div class="fw-text-inner">
                                            <p style="text-align: center;">Vivamus hendrerit arcu sed erat molestie
                                                vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttit.
                                                Uuin nulla enim. Phasellus molestie magna non est.</p>
                                        </div>
                                    </div>
                                    <div class="fw-divider-space  fw-custom-space  clearfix" style="height:40px;"></div>
                                    
                                                                
                                                                
                                                                
                                                                
		
			
                                        
                                    
                                    <div class="fw-divider-space  fw-custom-space  fw-mobile-hide-element clearfix"
                                         style="height:100px;"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-59268d1bc7b7c"
                         class=" fw-main-row-custom fw-section-no-padding  auto  fw-mobile-hide-element tf-sh-2bbdab2234d563415e07dcfb1ef3f0fc "
                         style="   ">
                    <div class="fw-container-fluid">
                        <div class="fw-row">
                            <div id="column-efbdbe37c0b7b90af8ede6bcf5e57023"
                                 class="fw-col-sm-12 tf-sh-efbdbe37c0b7b90af8ede6bcf5e57023">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                    <div class="fw-divider-space  fw-custom-space  clearfix"
                                         style="height:145px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="fw-row">
                            <div id="column-8fdc7b5ec21e901c4c0dd0778c64d093"
                                 class="fw-col-sm-12 tf-sh-8fdc7b5ec21e901c4c0dd0778c64d093  fw-column-height-custom"
                                 style="height: 5px;">
                                <div class="fw-main-row-overlay"></div>
                                <div class="fw-col-inner">
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>


        </div><!-- /.site-main -->

        <!-- Footer -->
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div><!-- /#page -->
    <a class="scroll-to-top anchor upload-icon" href="#page"><img
                src="<?php echo e(asset('wp-content/uploads/2016/07/to-top.png')); ?>" alt="to top button"/></a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.aboutapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>